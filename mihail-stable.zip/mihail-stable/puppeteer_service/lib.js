const fs = require('fs').promises;
const winston = require('winston');

// Создание логгера
const createLogger = () => {
    return winston.createLogger({
        format: winston.format.combine(
            winston.format.timestamp(),
            winston.format.json()
        ),
        transports: [
            new winston.transports.File({ filename: 'browser.log' }),
            new winston.transports.Console({
                format: winston.format.combine(
                    winston.format.colorize(),
                    winston.format.simple()
                )
            })
        ]
    });
};

// Функция для случайной задержки
const randomDelay = async (min, max) => {
    const delay = Math.floor(Math.random() * (max - min + 1) + min);
    await new Promise(resolve => setTimeout(resolve, delay));
};

// Функция для сохранения в JSON
async function saveToJSON(outputDir, part_number, data) {
    const filename = path.join(outputDir, `${part_number}.json`);
    await fs.writeFile(
        filename,
        JSON.stringify({
            part_number: part_number,
            timestamp: new Date().toISOString(),
            results: data
        }, null, 2),
        'utf-8'
    );
}

// Функция для работы с cookies
async function saveCookies(page, dataFolder) {
    const cookies = await page.cookies();
    await fs.writeFile(`${dataFolder}/cookies.json`, JSON.stringify(cookies, null, 2));
}

async function loadCookies(page, dataFolder) {
    try {
        const cookiesString = await fs.readFile(`${dataFolder}/cookies.json`, 'utf8');
        const cookies = JSON.parse(cookiesString);
        await page.setCookie(...cookies);
    } catch (error) {
        console.error('Error loading cookies:', error);
    }
}

function addDaysToDate(dateString, daysToAdd) {
    const date = new Date(dateString);
    date.setUTCDate(date.getUTCDate() + daysToAdd);
    const month = String(date.getUTCMonth() + 1).padStart(2, '0');
    const day = String(date.getUTCDate()).padStart(2, '0');
    const year = date.getUTCFullYear();
    return `${month}/${day}/${year}`;
}

// // Helper function to save data to CSV
// async function saveToCSV(part_number, data) {
//     const filename = path.join(config.outputDir, `${part_number}.csv`);
//     const csvContent = data.map(row =>
//         Object.values(row).map(value =>
//             `"${String(value).replace(/"/g, '""')}"`
//         ).join(',')
//     ).join('\n');

//     await fs.writeFile(filename, csvContent, 'utf-8');
// }

module.exports = {
    createLogger,
    randomDelay,
    saveToJSON,
    saveCookies,
    loadCookies,
    addDaysToDate
}; 