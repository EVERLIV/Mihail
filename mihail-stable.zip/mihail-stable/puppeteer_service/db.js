const { MongoClient } = require('mongodb');

const url = process.env.MONGODB_URI;
const dbName = process.env.MONGODB_DB_NAME;
const collectionName = process.env.MONGODB_VENDORS_COLLECTION;

async function saveVendorToMongoDB(vendorData) {
    let client;
    try {
        client = await MongoClient.connect(url);
        const db = client.db(dbName);
        const vendorsCollection = db.collection(collectionName);

        const existingVendor = await vendorsCollection.findOne({
            EmailAddress: vendorData.EmailAddress
        });

        if (existingVendor) {
            const result = await vendorsCollection.updateOne(
                { EmailAddress: vendorData.EmailAddress },
                { $set: vendorData }
            );
            //logger.info(`Vendor data updated, matched: ${result.matchedCount}`);
        } else {
            const result = await vendorsCollection.insertOne(vendorData);
            //logger.info(`New vendor data saved with id: ${result.insertedId}`);
        }
    } catch (error) {
        console.error('Error saving to MongoDB:', error);
        throw error;
    } finally {
        if (client) {
            await client.close();
        }
    }
}

async function saveStatistics(part_number, vendor_email, timestamp) {
    let client;
    try {
        client = await MongoClient.connect(url);
        const db = client.db(dbName);
        const statsCollection = db.collection('statistics');

        await statsCollection.insertOne({
            marketplace: "stockmarket.aero",
            part_number,
            vendor_email,
            timestamp,
            created_at: new Date()
        });
    } catch (error) {
        console.error('Error saving statistics:', error);
    } finally {
        if (client) {
            await client.close();
        }
    }
}

async function saveProcessedOrder(order) {
    let client;
    try {
        client = await MongoClient.connect(url);
        const db = client.db(dbName);
        const ordersCollection = db.collection('orders');

        const existingOrder = await ordersCollection.findOne({
            id: order.id,
            part_number: order.part_number
        });

        if (existingOrder) {
            await ordersCollection.updateOne(
                { id: order.id },
                { $set: { ...order, processed: true, marketplace: "stockmarket.aero" } }
            );
        } else {
            await ordersCollection.insertOne({
                ...order,
                marketplace: "stockmarket.aero",
                processed: true,
                processedAt: new Date()
            });
        }
    } catch (error) {
        console.error('Error saving processed order:', error);
        throw error;
    } finally {
        if (client) {
            await client.close();
        }
    }
}

async function getUnprocessedOrders(orders) {
    let client;
    try {
        client = await MongoClient.connect(url);
        const db = client.db(dbName);
        const ordersCollection = db.collection('orders');

        const processedOrders = await ordersCollection.find(
            {
                id: { $in: orders.map(o => o.id) },
                processed: true
            },
            { projection: { id: 1 } }
        ).toArray();

        const processedIds = new Set(processedOrders.map(o => o.id));
        return orders.filter(order => !processedIds.has(order.id));
    } catch (error) {
        console.error('Error getting unprocessed orders:', error);
        throw error;
    } finally {
        if (client) {
            await client.close();
        }
    }
}

module.exports = {
    saveVendorToMongoDB,
    saveStatistics,
    saveProcessedOrder,
    getUnprocessedOrders
}; 