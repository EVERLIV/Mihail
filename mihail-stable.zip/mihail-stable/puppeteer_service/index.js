// const { MongoClient } = require('mongodb');
const {
    saveVendorToMongoDB,
    saveStatistics,
    saveProcessedOrder,
    getUnprocessedOrders
} = require('./db');

const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const express = require('express');
const app = express();
// app.use(bodyParser.json());
app.use(express.json());
const { 
    createLogger,
    randomDelay,
    saveCookies,
    loadCookies,
    addDaysToDate 
} = require('./lib');

// Инициализация логгера
global.logger = createLogger();

require('dotenv').config()

const { hideHeadless } = require('./hideheadless')
puppeteer.use(StealthPlugin());

var STATE = {
    busy: true
}

// Configuration
const config = {
    searchURL: process.env.STOCKMARKETURL,
    username: process.env.STOCKMARKETLOGIN,
    password: process.env.STOCKMARKETPASSWORD,
    outputDir: './output',
    dataFolder: './browsercache', // добавляем папку для данных браузера
    orderNumber: 'xxx', // номер заказа
    defaultQuantity: 3, // стандартное количество для заказа
    // Delay ranges in milliseconds
    proxyServer: "194.156.99.28",
    proxyport: "8000",
    proxyusername: "hkproxy",
    proxypassword: "fh9384hoF",
    delays: {
        typing: { min: 50, max: 100 },
        navigation: { min: 500, max: 2000 },
        clicking: { min: 100, max: 500 }
    }
};


const runserver = async (page, browser) => {
    app.post("/",
        async (request, reply) => {
            logger.info('API', new Date().toLocaleString('ru-RU', { timeZone: "Europe/Moscow" }), request.body);

            // if (request.headers?.authorization != TOKEN) {
            //     reply.send({ ok: false, error: "not_authorized", message: "Not authorized, check your setup.." })
            //     return
            // }
            // Convert the request body to a string and send it to the connected WebSocket client
            switch (request.body.command) {
                case 'close':
                    await browser.close();
                    logger.info('Browser closed')
                    reply.send({ ok: true })
                    break
                case 'parse':
                    if (STATE.busy) {
                        reply.send({ ok: false, error: "browser_busy", message: "Wait until browser finished with previous task" })
                        break
                    } else {
                        STATE.busy = true
                    }
                    if (request.body?.orders?.length) {
                        try {
                            const unprocessedOrders = await getUnprocessedOrders(request.body.orders);

                            if (unprocessedOrders.length === 0) {
                                reply.send({ ok: true, message: "All orders already processed" });
                                STATE.busy = false;
                                // Завершаем процесс после успешного выполнения
                                await browser.close();
                                process.exit(0);
                                break;
                            }

                            const BATCH_SIZE = 6;
                            const ordersPerBatch = Math.ceil(unprocessedOrders.length / BATCH_SIZE);

                            const batches = Array.from({ length: BATCH_SIZE }, (_, i) => {
                                const start = i * ordersPerBatch;
                                return unprocessedOrders.slice(start, start + ordersPerBatch);
                            }).filter(batch => batch.length > 0);

                            logger.info(`Starting processing ${batches.length} batches with ${unprocessedOrders.length} total orders`);
                            reply.send({ ok: true });

                            const promises = batches.map((batch, index) =>
                                retryBatch(batch, browser, index + 1)
                            );

                            await Promise.all(promises);
                            logger.info('All batches completed');
                            STATE.busy = false;
                            
                            // Завершаем процесс после успешного выполнения всех батчей
                            await browser.close();
                            process.exit(0);
                        } catch (error) {
                            console.error('Error processing batches:', error);
                            reply.send({ ok: false, error: "processing_error", message: error.message });
                            STATE.busy = false;
                            
                            // Завершаем процесс с ошибкой
                            await browser.close();
                            process.exit(1);
                        }
                    } else {
                        reply.send({ ok: false, error: "wrong_params", message: "Check params present" });
                        STATE.busy = false;
                    }
                    break;
                case 'goto':
                    if (STATE.busy) {
                        reply.send({ ok: false, error: "browser_busy", message: "Wait until browser finished with previous task or use screenshot command to view the state" })
                        break
                    } else {
                        STATE.busy = true
                    }
                    await page.goto(request.body.url)
                    let newUrl = await page.url()
                    reply.send({ ok: true, message: newUrl }); // Send a response to the API client
                    STATE.busy = false
                    break;
                case 'status':
                    if (STATE.busy) {
                        reply.send({ ok: false, error: "browser_busy", status: STATE, message: "Wait until browser finished with previous task or use screenshot command to view the state" })
                        break
                    }

                    reply.send({ ok: true, url: decodeURI(await page.url()), status: STATE }); // Send a response to the API client

                    break;

                case 'rescue':
                    STATE.busy = false
                    // sample {selector: "input#password", action: "type", text: "mypassword"}
                    // let selector = request.body.selector
                    // let action = request.body.action
                    // let element;
                    // if (selector && action) {
                    //     element = await page.waitForSelector(selector).catch(err => {
                    //         logger.info(selector, 'not found')
                    //         reply.send({ ok: false, error: "elem_not_found", message: err })
                    //     })
                    // }
                    // if (element) {
                    //     if (action && action === 'click') {
                    //         await element.click().then(() => {
                    //             reply.send({ ok: true })
                    //         }).catch(err => {
                    //             reply.send({ ok: false, error: "elem_not_clicked", message: err })

                    //         })

                    //     } else if (action && action === 'type') {
                    //         await element.type(request.body.text).catch(err => {
                    //             reply.send({ ok: false, error: "elem_not_typed", message: err })

                    //         })
                    //     }

                    // }

                    //STATE.busy = false
                    break;

                case 'login':
                    if (STATE.busy) {
                        reply.send({ ok: false, error: "browser_busy", message: "Wait until browser finished with previous task or use screenshot command to view the state" })
                        break
                    } else {
                        STATE.busy = true
                    }
                    await login();
                    reply.send({ ok: true })
                    STATE.busy = false

                    break;
                case 'screenshot':
                    logger.info('-----------------Screenshot------------------')
                    try {

                        await page.screenshot({
                            path: './screenshots/' + new Date().toISOString() + '.png',
                            type: 'png'
                        })
                        reply.send({ ok: true, message: "Screenshot saved" });
                    } catch (err) {
                        reply.send({ ok: false, message: "Screenshot not saved:" + err });

                    }
                    break;
                default:
                    logger.info('No such command')
                    reply.send({ ok: false, message: "No such command" }); // Send a response to the API client
            }
        }
    );



    try {
        app.listen({ port: 3002, host: '0.0.0.0' }, function (err, address) {
            if (err) {
                console.error(err)
            }
            logger.info(`Server listening on 3002`)
        })
    } catch (err) {
        app.log.error(err)
        process.exit(1)
    }
}


// Извлекаемм данные из html таблыцы
async function extractTableData(page, order) {

    const result = await page.evaluate(() => {
        let result = [];
        let currentVendor = null;
        let headers = null;
        const rows = Array.from(document.querySelectorAll('tr'));

        let counter = 0;
        for (let row of rows) {
            // Если это заголовок нового вендора
            if (row.id && row.id.startsWith('grp')) {
                counter = 0

             
                currentVendor = {
                    vendor: {
                        name: row.querySelector('.vendname')?.textContent.trim() || '',
                        location: row.querySelector('td[width="30%"] td[style*="width: 79%"]')?.textContent.trim() || ''
                    }
                };
                headers = null;
                console.log('Processing vendor:', currentVendor.vendor.name);
            }
            // Если это строка с заголовками
            else if (row.classList.length > 0 && row.querySelectorAll('td').length > 0 && !headers) {
                headers = Array.from(row.querySelectorAll('td'))
                    .map(td => td.textContent.trim())
                    .filter(header => header !== 'Send RFQ' && header !== 'Place PO Offer');
            }
            // Если это строка с данными
            else if (row.classList.length > 0 && headers && currentVendor && !row.id && counter === 0) {
                counter = counter + 1
                const cells = row.querySelectorAll('td.cell');
                if (cells.length > 0) {
                    // Находим первую ссылку в первой ячейке
                    const firstLink = cells[0]?.querySelector('a');
                    if (firstLink) {
                        // Сохраняем данные для клика
                        currentVendor.clickSelector = `#${firstLink.id}`;
                        if (currentVendor) {
                            result.push(currentVendor);
                        }
                        // Прерываем цикл после нахождения первой ссылки для этого вендора
                    }
                }
            }
        }



        return result;
    });

    logger.info(result?.length, "предложений поставщика")
    // Теперь обрабатываем результаты вендора

    for (const [index, vendor] of result.entries()) {
        try {
            if (vendor.clickSelector) {
                //logger.info(new Date(), `Clicking link for vendor ${vendor.vendor.name}`);
                await page.click(vendor.clickSelector);
                await randomDelay(1000, 2000);

                // Ждем появления диалога
                let uiDialog = await page.waitForSelector('div.ui-dialog', { timeout: 15000 }).catch(err => logger.info(err));

                // Получаем данные из vd div

                if (uiDialog) {
                    const vdData = await uiDialog.evaluate(async () => {
                        // Кликаем по заголовку Contact Details
                        const contactHeader = await document.querySelector('h3[onclick*="displayVendorDetail"]');
                        if (contactHeader) {
                            await contactHeader.click();
                            await new Promise(resolve => setTimeout(resolve, 1000));
                        }

                        const vendorDiv = document.querySelector('#vendor');
                        if (vendorDiv) {
                            // Собираем все ячейки
                            const cells = Array.from(vendorDiv.querySelectorAll('td'));

                            // Создаем объект с данными
                            const contactData = {};
                            for (let i = 0; i < cells.length; i += 2) {
                                // Убираем двоеточие из ключа и конвертируем в camelCase
                                const key = cells[i].textContent.trim()
                                    .replace(':', '')
                                    .replace(/\s+(.)/g, (_, c) => c.toUpperCase());
                                const value = cells[i + 1]?.textContent.trim() || '';

                                // Добавляем только непустые значения
                                if (value) {
                                    contactData[key] = value;
                                }
                            }

                            return contactData;
                        }
                        return null;
                    });


                    if (vdData) {
                        await saveVendorToMongoDB(vdData);
                        //logger.info(new Date(), 'Detail data:', vdData);
                    } else {
                        return
                    }

                    // Заполняем форму RFQ
                    await page.waitForSelector('#rfqdiv', { timeout: 5000 });
                    const formHeader = await page.waitForSelector('h3#rfqh3', { timeout: 5000 });
                    if (formHeader) {
                        {
                            await formHeader.click()
                        }
                    }
                    await randomDelay(2000, 3000);
                    //очищаем значения             

                    await page.evaluate(({ orderNumber, quantity, needby }) => {
                        const refNumberInput = document.querySelector('input[name="refNumber"]');
                        const quantityInput = document.querySelector('input[name="quanitity"]'); //'#rfqdiv > table > tbody > tr:nth-child(5) > td:nth-child(2) > input'
                        const dateInput = document.querySelector('input#needBy');

                        if (refNumberInput) refNumberInput.value = orderNumber;
                        if (quantityInput) quantityInput.value = quantity; // устанавливаем новое значение
                        if (dateInput) dateInput.value = needby;
                    }, {
                        orderNumber: order.id,
                        quantity: order.qty,
                        needby: addDaysToDate(order.request_date, 21)
                    });


                    // Отправляем форму
                    const submitButton = await page.$('input[type="submit"][value="Submit RFQ"]');
                    if (submitButton) {
                        await randomDelay(1000, 2000);
                        await submitButton.click();
                        //logger.info(new Date(), 'ok - sent');
                        // Сохраняем статистику
                        await saveStatistics(order.part_number, vdData.EmailAddress, new Date());

                        // Сохраняем информацию об обработанном заказе
                        if (index === 0) await saveProcessedOrder(order);
                        await randomDelay(1000, 2000);
                    }

                    // Закрываем диалог
                    const closeButton = await page.$('button.ui-dialog-titlebar-close');
                    if (closeButton) {
                        await closeButton.click();
                        await randomDelay(500, 1000);
                    }

                }
            }

        } catch (err) {
            logger.info(err)
            return
        }
    }
    return result;
}

// Helper function for human-like typing
async function typeHumanLike(element, text) {
    for (const char of text) {
        await element.type(char);
        await randomDelay(config.delays.typing.min, config.delays.typing.max);
    }
}

async function scrapePartDetails(page, ordersBody) {
    let orders = ordersBody.orders

    //проверить что залогинены - иначе не даст данные в табличке
    await page.goto(config.searchURL).catch(err => logger.info(err))
    let loginlink;
    try {
        loginlink = await page.waitForSelector('a#loginid', { timeout: 1000 })
    } catch (err) {
        console.log('Залогинены норм')
    }
    if (loginlink) {
        // Login process
        await login(page);
    }


    for (order of orders) {
        let hasNextPage = true;

        let partNumber = await page.waitForSelector('input#partNumber', { timeout: 5000 })
        await typeHumanLike(partNumber, order.part_number);
        await randomDelay(config.delays.clicking.min, config.delays.clicking.max);
        await page.$eval("input[value='Go']", el => el.click());
        await randomDelay(3000, 5000); // дополнительная пауза для стабильности



        while (hasNextPage) {
            await randomDelay(config.delays.navigation.min, config.delays.navigation.max);

            // Check and click expand button if exists
            try {
                await page.waitForSelector('div#exp_plus', { timeout: 5000 });
                await randomDelay(config.delays.clicking.min, config.delays.clicking.max);
                await page.click('div#exp_plus');
            } catch (error) {
                console.log(new Date(), `No expand button for ${order.part_number}`);
            }

            // Extract data from current page
            await extractTableData(page, order);

            // Check for next page
            let pagerb;
            try {
                pagerb = await page.waitForSelector('#pagerb', { timeout: 5000 });
            } catch (err) {
                //console.log('нет больше страниц')
            }
            if (!pagerb) {
                //logger.info(new Date(), 'no next page')
                hasNextPage = false;
            } else {
                const lastTd = await page.waitForSelector('#pagerb table tbody tr td:last-child', { timeout: 5000 }).catch((err) => logger.info(new Date(), err));

                const textPagerbList = await page.$$eval(
                    "#pagerb", elements => elements.map(e => e.textContent))
                    .catch(err => logger.info(err));
                const textPagerb = textPagerbList.join()
                //logger.info(new Date(), textPagerb)

                if (!lastTd || !textPagerb?.includes('Next')) {
                    // logger.info(new Date(), 'no next page')
                    hasNextPage = false;
                } else {
                    await lastTd.click();
                };
            };

        }

        // Clear the search field for next part
        try {
            await page.$eval('input#partNumber', input => input.value = '');
        } catch (err) {
            logger.info(err)
        }
    }
}


async function login(page) {

    logger.info('Loggin in...')
    await page.goto('https://www.stockmarket.aero/StockMarket/LoadLogin.do');
    await randomDelay(2000, 3000);
    await page.evaluate(({ username, password }) => {
        const usernameField = document.querySelector('input[name="username"]');
        const passwordField = document.querySelector('input[name="password"]');
        const rememberMeCheckbox = document.querySelector('input[name="rememberMe"]');

        if (usernameField && passwordField) {
            usernameField.value = username;
            passwordField.value = password;
            if (rememberMeCheckbox) {
                rememberMeCheckbox.checked = true;
            }
            document.forms['loginForm'].submit();
        } else {
            throw new Error('Login form fields not found');
        }
    }, {
        username: config.username,
        password: config.password
    })
    await saveCookies(page,config.dataFolder); // сохраняем после успешного логина

}

async function retryBatch(orders, browser, batchNumber, maxRetries = 3) {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            await processBatch(orders, browser, batchNumber);
            return;
        } catch (error) {
            console.error(`Batch ${batchNumber} failed on attempt ${attempt}:`, error);

            if (attempt < maxRetries) {
                await new Promise(resolve => setTimeout(resolve, 5000));
            }
        }
    }
}

async function processBatch(orders, browserInstance, batchNumber) {
    logger.info(`Starting batch ${batchNumber} with ${orders.length} orders`);
    const batchPage = await browserInstance.newPage();

    await hideHeadless(batchPage);


    // Перехватываем консольные сообщения страницы
    batchPage.on('console', async e => {
        const args = await Promise.all(e.args().map(a => a.jsonValue()));
        console.log('Batch', batchNumber, ...args);
    });

    batchPage.on('dialog', async dialog => {
        console.log(`Batch ${batchNumber} - Dialog caught: ${dialog.type()} - "${dialog.message()}"`);
        await dialog.accept();
    });

    try {
        await batchPage.goto(config.searchURL);
        // let loginlink = await page.waitForSelector('a#loginid', { timeout: 5000 }).catch(() => null);
        // if (loginlink) {
        //     logger.info(`Batch ${batchNumber} - Logging in...`);
        //     await login(page);
        // }

        for (const order of orders) {
            console.log(`Batch ${batchNumber} - Processing order: ${order.part_number}`);
            await scrapePartDetails(batchPage, { orders: [order] });
            console.log(`Batch ${batchNumber} - Finished processing order: ${order.part_number}`);
        }
    } catch (error) {
        console.error(`Error in batch ${batchNumber}:`, error);
    } finally {
        console.log(`Closing batch ${batchNumber}`);
        await batchPage.close();
    }
}


async function main() {

    // Обработка завершения процесса
    process.on('SIGINT', async () => {
        // await saveCookies(page);
        await browser.close();
        process.exit();
    });

    process.on('SIGTERM', async () => {
        await browser.close();
        process.exit();
    });

    const browser = await puppeteer.launch({
        headless: "new",
        defaultViewport: null,
        executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || "/usr/bin/chromium",
        args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            `--proxy-server=http://${config.proxyServer}:${config.proxyport}`

            //'--user-data-dir=./browsercache'

        ],
        //userDataDir: `./browsercache/`,
        //persistentContext: true
    });

    //const page = await browser.newPage();
    const page = (await browser.pages())[0];
    await page.authenticate({
        username: config.proxyusername,
        password: config.proxypassword,
    }).catch(err => logger.info(new Date().toISOString(), err))


    await loadCookies(page, config.dataFolder);

    // Отлавливаем появление алерта и нажимаем кнопку
    page.on('dialog', async dialog => {
        logger.info(`Пойман диалог: ${dialog.type()} - "${dialog.message()}"`);

        if (dialog.type() === 'confirm') {
            await dialog.accept(); // Нажать "OK"
            // await dialog.dismiss(); // Нажать "Cancel"
        } else {
            await dialog.accept(); // Для alert и prompt просто закрывает
        }
    });


    await hideHeadless(page);
    runserver(page, browser);


    try {

        await page.goto(config.searchURL);
        await randomDelay(config.delays.navigation.min, config.delays.navigation.max);

        logger.info('проверяем нужен-ли login')
        let loginlink;
        try {
            loginlink = await page.waitForSelector('a#loginid', { timeout: 5000 })
        } catch (err) {
            logger.info('Уже залогинен')
            STATE.busy = false

        }
        if (loginlink) {
            // Login process
            await login(page);
            STATE.busy = false

        } else {
            STATE.busy = false
        }


    } catch (error) {
        console.error('An error occurred:', error);
    }
}

main().catch(console.error);
