const dotenv = require('dotenv');
dotenv.config();
require('dotenv').config({ path: '../.env' }); // загружает .env из родительской директории

const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const { hideHeadless } = require('./hideheadless')

puppeteer.use(StealthPlugin());

const cheerio = require('cheerio');
const blacklist = require('./blacklist');


const {
    getUnprocessedOrders,
    saveProcessedOrder,
    saveStatistics,
    getRecentStatistics
} = require('./db');

const ILSMART_USERNAME = process.env.ILSMART_USERNAME;
const ILSMART_PASSWORD = process.env.ILSMART_PASSWORD;
const PROXY_SERVER = process.env.PROXY_SERVER;
const PROXY_PORT = process.env.PROXY_PORT;
const PROXY_USERNAME = process.env.PROXY_USERNAME;
const PROXY_PASSWORD = process.env.PROXY_PASSWORD;


const baseUrl = process.env.PANTHEON_API_URL;
const getOrdersUrl = process.env.GETORDERSURL;
const authToken = process.env.API_AUTH_TOKEN;

console.log(PROXY_SERVER, PROXY_PORT, PROXY_USERNAME, PROXY_PASSWORD);

// Добавляем глобальные переменные для хранения состояния
let browser;
let page;

// Функция для корректного выхода
async function gracefulShutdown() {
    console.log('Выполняется корректное завершение работы...');
    try {
        if (page) {
            await page.evaluate(() => {
                const logoutButton = document.querySelector('#oILSHeader_cmdLogout');
                if (logoutButton) logoutButton.click();
            }).catch(err => console.log('Ошибка при выходе из системы:', err));
            await delay(5000);
        }
        if (browser) {
            await browser.close();
        }
    } catch (error) {
        console.error('Ошибка при завершении работы:', error);
    } finally {
        process.exit(0);
    }
}

// Регистрируем обработчики сигналов
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);
process.on('uncaughtException', async (error) => {
    console.error('Необработанное исключение:', error);
    await gracefulShutdown();
});

async function getOrders() {
    const response = await fetch(baseUrl + getOrdersUrl, {
        headers: {
            'Authorization': `${authToken}`
        }
    });
    const data = await response.json();

    const unprocessedOrders = await getUnprocessedOrders(data);
    // Определяем порядок приоритетов
    const priorityOrder = {
        'AOG': 1,
        'WSP': 2,
        'USR': 3,
        'RTN': 4
    };

    // Сортируем заказы по приоритету
    const sortedOrders = unprocessedOrders.sort((a, b) => {
        const priorityA = priorityOrder[a.priority] || 5; // Если приоритет не определен, ставим в конец
        const priorityB = priorityOrder[b.priority] || 5;
        return priorityA - priorityB;
    });

    // Считаем статистику по приоритетам
    const stats = {
        'AOG': 0,
        'WSP': 0,
        'USR': 0,
        'RTN': 0,
        'OTHER': 0
    };

    sortedOrders.forEach(order => {
        if (order.priority in stats) {
            stats[order.priority]++;
        } else {
            stats.OTHER++;
        }
    });

    // Выводим статистику
    console.log('\nСтатистика заказов по приоритетам:');
    console.log('--------------------------------');
    console.log(`AOG: ${stats.AOG}`);
    console.log(`WSP: ${stats.WSP}`);
    console.log(`USR: ${stats.USR}`);
    console.log(`RTN: ${stats.RTN}`);
    console.log(`Другие приоритеты: ${stats.OTHER}`);
    console.log('--------------------------------\n');

    return sortedOrders.filter(order => order.material_type === 'R');
}



async function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}


async function extractTableData(html, page) {
    const $ = cheerio.load(html);
    const table = $('#oResults');
    const results = [];

    // Проверяем, что таблица существует
    if (!table.length) {
        throw new Error('Таблица с id "oResults" не найдена');
    }

    // Получаем заголовки таблицы (если есть thead)
    const headers = [];
    const rowIds = [];
    table.find('thead tr th').each((i, el) => {
        headers.push($(el).text().trim());
    });

    // Обрабатываем строки таблицы


    let companyName;
    let companyId;
    let secondLine;
    let emailtext;
    let emailLink;
    let email;
    let country;

    table.find('tbody tr').each((i, row) => {
        const rowData = {};

        const rowId = $(row).attr('id');


        if (rowId?.includes('oCompanyRow')) {
            const nameId = rowId.replace('oCompanyRow', 'oCompanyName_btnCompanyName');
            companyName = $(row).find(`#${nameId}`).text().trim();

            const idId = rowId.replace('oCompanyRow', 'lblCAGE');
            companyId = $(row).find(`#${idId}`)?.text().trim();

            const secondLineId = rowId.replace('oCompanyRow', 'lblSecondLine');
            secondLine = $(row).find(`#${secondLineId}`)?.text().trim();
            emailtext = secondLine.toLowerCase().match(/[\w.-]+@[\w.-]+\.\w+/);

            const emailId = rowId.replace('oCompanyRow', 'oCommuntionCell');
            emailLink = $(row).find(`#${emailId}`).text()?.trim();
            emailLink = emailLink.toLowerCase().match(/[\w.-]+@[\w.-]+\.\w+/);

            const countryId = rowId.replace('oCompanyRow', 'imgCountryFlag');
            country = $(row).find(`#${countryId}`).attr('data-original-title')?.trim();


        }

        if (rowId?.includes('oItemRequest')) {
            const selectorId = rowId.replace('oItemRequest', 'chkSupplierItemIsSelected');

            const partNumberId = rowId.replace('oItemRequest', 'lblSupplierPart');
            const partNumber = $(row).find(`#${partNumberId}`)?.text().trim();

            const partQtyId = rowId.replace('oItemRequest', 'lblSupplierQuantity');
            const partQty = $(row).find(`#${partQtyId}`)?.text().trim();

            const conditionId = rowId.replace('oItemRequest', 'lblSupplierCondition');
            const condition = $(row).find(`#${conditionId}`)?.text().trim();

            const partDescriptionId = rowId.replace('oItemRequest', 'lblSupplierDescription');
            const partDescription = $(row).find(`#${partDescriptionId}`)?.text().trim();

            let proposal = {
                VendorName: companyName?.split('(')[0]?.trim(),
                ILSmartID: companyName?.split('(')[1]?.replace(')', '').trim(),
                CAGE: companyId,
                Country: country,
                EmailAddress: (emailtext && emailtext[0]?.toLowerCase()) ||
                    (emailLink && emailLink[0]?.toLowerCase()),
                part: {
                    selector: selectorId,
                    partNumber: partNumber,
                    qty: isNaN(partQty) ? 0 : parseInt(partQty),
                    condition: condition,
                    description: partDescription
                }

            }
            ///console.log(proposal);
            results.push(proposal);
        }

        //   $(row).find('td').each((j, cell) => {
        //     // Используем заголовки для ключей объекта, если они есть
        //     const key = headers[j] || `column_${j}`;
        //     rowData[key] = $(cell).text().trim();

        //     // Если нужно извлечь атрибуты или ссылки:
        //     // rowData[`${key}_href`] = $(cell).find('a').attr('href');
        //   });

        //results.push(rowData);
    });

    // for (const result of results) {
    //     await page.evaluate((selector) => {
    //         const checkbox = document.querySelector(`#${selector}`);
    //         if (checkbox) checkbox.checked = true;
    //     }, result.part.selector);
    // }

    return results;
}


async function getAllPaginationElements(page) {
    const paginationElements = [];
    let index = 0;
    let hasNextPage = true;

    while (hasNextPage) {
        const selector = `#oPaging_rptrPaging_ctl${String(index).padStart(2, '0')}_cmdPage`;
        await page.waitForSelector(selector).catch(err => console.log('No pagination element found'));
        const element = await page.$(selector);

        if (!element) {
            hasNextPage = false;
            break;
        }

        paginationElements.push(selector);
        index++;
    }

    return paginationElements;
}

async function scrapeILSmart() {
    let orders = await getOrders();
    let unprocessedOrders = await getUnprocessedOrders(orders);

    console.log('найдено', unprocessedOrders.length, 'необработанных заказов');
    if (unprocessedOrders.length === 0) {
        console.log('нет необработанных заказов');
        await delay(120000);
        process.exit(0);
    }

    // if (process.env.NODE_ENV === 'development') {
    //     unprocessedOrders = unprocessedOrders.slice(0, 1);
    // }

    browser = await puppeteer.launch({
        headless: process.env.NODE_ENV === 'development' ? false : "new",
        defaultViewport: null,
        userDataDir: './ils_browsercache',
        persistentContext: true,
        args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--window-size=1920,1200',
            '--disable-dev-shm-usage',
            `--proxy-server=${process.env.PROXY_SERVER}:${process.env.PROXY_PORT}`,
            '--disable-web-security',
            '--disable-features=IsolateOrigins,site-per-process',
            '--disable-site-isolation-trials'
        ]
    });

    try {
        page = (await browser.pages())[0];

        // Устанавливаем более реалистичные заголовки браузера
        await page.setExtraHTTPHeaders({
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Cache-Control': 'max-age=0'
        });

        // Устанавливаем таймауты

        await page.authenticate({
            username: PROXY_USERNAME,
            password: PROXY_PASSWORD,
        }).catch(err => console.log('Ошибка при аутентификации прокси:', err));

        // Логин (выполняется только один раз)
        await hideHeadless(page);

        // Добавляем случайную задержку перед первым запросом


        // Теперь переходим на целевой сайт
        await page.goto('https://members.ilsmart.com/', {
            timeout: 120000
        }).catch(async err => {
            console.log(err)
            await browser.close();
            process.exit(0);
        }
        );

        let loginButton = await page.$('a.hs-button').catch(err => console.log('No login button found'));
        if (loginButton) {
            console.log('loginButton is here');
            await page.goto('https://static.ilsmart.com/pages/ilslogin.htm');
            await page.type('#email', ILSMART_USERNAME);
            await page.type('#password', ILSMART_PASSWORD);
            await page.click('#rememberme-box');
            await page.click('button.p-button');
            await page.waitForNavigation();
            let enterNumberButton = await page.waitForSelector('#lnkEnterNumber').catch(err => console.log('No enter number button found'));
            if (enterNumberButton) {
                await page.click('#lnkEnterNumber');
            }
        }

        let pageText = await page.content();
        if (pageText.includes('ILSmart Alert')) {
            console.log('Session is busy');
            let cssSelector = pageText.includes('received payment') ? 'input[name="cmdContinue"]' : 'input[name="btnOK"]';
            console.log('cssSelector:', cssSelector);
            await page.waitForSelector(cssSelector).catch(err => console.log('No btnOK found'));
            await page.click(cssSelector).catch(err => console.log('No btn found'));
            await delay(10000);
        }

        //Our records indicate we have not yet received payment for outstanding invoice(s). Payment must be received within 5 days of the invoice due date, to avoid possible service interruption. Please contact ILS Accounting department(below) regarding payment as soon as possible.
        //<input type="submit" name="cmdContinue" value="Continue" id="cmdContinue" title="Continue" class="btn btn-xs btn-primary col-xs-12">


        if (pageText?.toLowerCase().includes('is already logged in from another computer.')) {
            console.log('Session is logged from another computer - exiting in 60 seconds');
            await delay(60000)
            process.exit(0);
        }

        let phrase = 'your current ils session was inactive'
        if (pageText?.toLowerCase().includes(phrase)) {
            console.log('ILS session is inactive and was taken over - exiting in 60 seconds');
            await delay(60000)
            process.exit(0);
        }


        // Обработка каждого заказа
        for (const order of unprocessedOrders) {
            console.log('Обработка заказа:', order.part_number, 'qty:', order.qty);
            order.qty = order.qty >= 1 ? Math.ceil(order.qty) : 1;
            // Вводим номер детали
            const partNumberField = '#oPartSearchPanelControl_rptrEnterNumbers_ctl01_txtPartNumber';
            const partInput = await page.waitForSelector(partNumberField)
                .catch(async err => {
                    console.log('No part number field found')
                    await page.screenshot({ path: `screenshots/ils_no_pn_field_${order.part_number}.png` })
                        .catch(err => console.log('No screenshot taken'));



                    /*
                    
                    ILSmart Alert
                    ILS ID cnrcu01 is already logged in from another computer.
                    ILS ID: cnrcu01 Last Activity: 4/2/2025 2:59:31 PM
                    
                    If ILS ID cnrcu01 remains inactive for a period of 30 minutes, that ILS ID's session will expire.
                    
                    
                    
                    If you need further assistance, please contact ILS Customer Support:
                    The Americas 1-901-794-5000 Fax 1-901-794-1760 Email custsppt@ilsmart.com
                    Asia Pacific 65-91761185 Email APcss@ilsmart.com
                    */


                });
            const qtyField = '#oPartSearchPanelControl_rptrEnterNumbers_ctl01_txtQty';
            const qtyInput = await page.waitForSelector(qtyField)
                .catch(err => console.log('No qty field found'));

            if (partInput && qtyInput) {
                await partInput.type(order.part_number);
                await qtyInput.type(order.qty.toString());
            }

            // Поиск
            let searchButton = await page.waitForSelector('#oPartSearchPanelControl_cmdSearch')
                .catch(err => console.log('No search button found'));
            if (searchButton) {
                await searchButton.click();
            } else {
                await page.click('#oPartSearchPanelControl_cmdSearch')
                    .catch(async err => {
                        console.log('No search button found')
                        await page.screenshot({ path: `screenshots/ils_no_search_button_${order.part_number}.png` });
                    });
            }
            await delay(10000);
            let resultsTable = await page.waitForSelector('#oResults')
                .catch(err => console.log('No results found'));
            await delay(10000);
            if (resultsTable) {
                console.log('Results found');
            } else {
                await saveProcessedOrder(order);
                await page.screenshot({ path: `screenshots/ils_no_results_${order.part_number}.png` });
                continue;
            }


            // Собираем все результаты
            let allResults = [];

            // Получаем данные с первой страницы
            const html = await page.content();
            const firstPageData = await extractTableData(html, page);
            allResults = allResults.concat(firstPageData);

            // Проверяем наличие пагинации
            const paginationElements = await getAllPaginationElements(page);
            console.log('Найдено страниц:', paginationElements.length + 1);

            // Обрабатываем остальные страницы
            for (const paginationSelector of paginationElements) {
                console.log('Переход на следующую страницу');
                await page.click(paginationSelector);
                await delay(5000); // Ждем загрузки новой страницы
                await page.waitForSelector('#oResults');

                const nextPageHtml = await page.content();
                const nextPageData = await extractTableData(nextPageHtml, page);
                allResults = allResults.concat(nextPageData);
            }

            console.log('Всего результатов для заказа:', allResults.length);
            //console.log('Результаты для заказа:', allResults);

            let filteredResults = allResults.filter(result =>
                !blacklist.some(black =>
                    result.VendorName?.split(' ').join('').trim().toLowerCase()
                        .includes(black)
                    || result.EmailAddress?.toLowerCase()
                        .includes(black)
                )
            );

            // Фильтруем результаты по статистике MongoDB
            const filteredByStatistics = [];
            for (const result of filteredResults) {
                // Используем email или нормализованное название компании
                const searchTerm = result.EmailAddress ||
                    (result.VendorName ? result.VendorName.toLowerCase().replace(/[^a-z0-9]/g, '').trim().substring(0, 10) : null);

                const hasRecentStatistics = await getRecentStatistics(
                    order.part_number,
                    searchTerm
                );
                if (!hasRecentStatistics) {
                    filteredByStatistics.push(result);
                } else {
                    console.log(`Пропущен результат для ${result.EmailAddress || result.VendorName} - найдена недавняя статистика`);
                }
            }

            console.log('Отфильтровано результатов по статистике:', filteredByStatistics.length);
            filteredResults = filteredByStatistics;

            console.log('Отфильтровано результаты для заказа:', filteredResults.length);

            if (filteredResults.length > 0) {

                // Функция для определения приоритета кондиции
                function getConditionPriority(condition) {
                    const priorityMap = {
                        'NE': 1,
                        'NS': 2,
                        'OH': 3,
                        'SV': 4
                    };
                    return priorityMap[condition] || 5; // Все остальные кондиции имеют низший приоритет
                }

                // Группируем результаты по поставщику и номеру детали
                const groupedResults = filteredResults.reduce((acc, result) => {
                    const key = `${result.VendorName}_${result.part.partNumber}`;
                    if (!acc[key]) {
                        acc[key] = [];
                    }
                    acc[key].push(result);
                    return acc;
                }, {});

                // Выбираем лучший результат из каждой группы
                const deduplicatedResults = Object.values(groupedResults).map(group => {
                    return group.reduce((best, current) => {
                        const bestPriority = getConditionPriority(best.part.condition);
                        const currentPriority = getConditionPriority(current.part.condition);
                        return currentPriority < bestPriority ? current : best;
                    });
                });

                console.log('Всего уникальных результатов для заказа:', deduplicatedResults.length);

                for (const result of deduplicatedResults) {
                    await page.evaluate((selector) => {
                        const checkbox = document.querySelector(`#${selector}`);
                        if (checkbox) checkbox.checked = true;
                    }, result.part.selector);
                }


                await page.click('#cmdCreateRFQ');
                await delay(15000);
                // #txtReferenceNo - get its value and save it to the database
                await page.waitForSelector('#txtReferenceNo').catch(async err => {
                    console.log('No txtReferenceNo found')
                    await delay(10000);
                });
                const referenceNo = await page.$eval('#txtReferenceNo', el => el.value);
                console.log('Reference number:', referenceNo);
                // save referenceNo to the database
                await page.click('#cmdSendRFQ2');

                for (const result of deduplicatedResults) {
                    await saveStatistics(order.part_number, result.EmailAddress, result.VendorName, order.id, referenceNo);
                }
                console.log(`Statistics saved for part ${order.part_number}`);


                await delay(10000);

                let rfqResult = await page.waitForSelector('#rfqTitle')
                    .catch(err => console.log('No rfqTitle found'));
                if (rfqResult) {
                    console.log('RFQ Sent Confirmation');
                    await page.click('#cmdNewSearch');
                    await delay(5000);
                } else {
                    console.log('RFQ Not Sent');
                }

            } else {
                console.log('No results found for order:', order.part_number);
                // Теперь переходим на целевой сайт
                await page.goto('https://members.ilsmart.com/', {
                    waitUntil: 'networkidle0',
                    timeout: 60000
                });
            }


            await saveProcessedOrder(order);


        }


        await page.evaluate(() => {
            return document.querySelector('#oILSHeader_cmdLogout').click();
        });
        await delay(10000);
        await browser.close();
        process.exit(0);

    } catch (error) {
        console.error('Ошибка при скрапинге:', error);
        try {
            await page.evaluate(() => {
                return document.querySelector('#oILSHeader_cmdLogout').click();
            });
            await browser.close();
        } catch (error) {
            console.error('Ошибка при выходе из ILS:', error);
        }
        
        await browser.close();
        process.exit(1);

    } finally {
        try {
            await page.evaluate(() => {
                return document.querySelector('#oILSHeader_cmdLogout').click();
            });
            await browser.close();
        } catch (error) {
            console.error('Ошибка при выходе из ILS:', error);
        }
        process.exit(0);
    }
}


// createRFQ     
// input#cmdCreateRFQ , 
// input id=txtReferenceNo (take value from there to save along with quote number to match later), 
// #cmdSendRFQ, #cmdNewSearch





scrapeILSmart()
    .then(results => {
        // Обработка результатов
        console.log('Скрапинг завершен успешно');
    })
    .catch(error => {
        console.error('Ошибка при выполнении скрапинга:', error);
    });



//<input name="btnOK" type="button" id="btnOK" value="OK" class="btn btn-xs btn-primary" onclick="document.location = 'https://static.ilsmart.com/pages/ilslogin.htm';" title="OK"></input>