const fs = require('fs').promises;
const XLSX = require('xlsx');

const parseXLSX = async (buffer) => {
    try {
      const workbook = XLSX.read(buffer, { type: 'buffer' });
      const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
      let rows = XLSX.utils.sheet_to_json(firstSheet);
      rows = rows.filter(row => Object.keys(row).length > 7)
      .filter(row => row['Qty Available'] > 0)
      .filter(row => row['Requested Qty'] < row['Qty Available'])
      
      
      return rows;
    } catch (error) {
      console.error(new Date(), 'Ошибка при чтении файла:', error.message);
      return null;
    }
  }
  
  module.exports = { parseXLSX };


  // const main = async () => {
  //   const buffer = await fs.readFile('./downloads/simplified_partsearchresults_22-05-2025.xlsx');
  //   const rows = await parseXLSX(buffer);
  //   const processedData = rows.map(row => {
  //     const priceBreaks = [];
      
  //     // Парсим Qty Break из отдельных полей
  //     for (let i = 1; i <= 5; i++) {
  //       const qtyBreak = row[`Qty Break ${i}`];
  //       const price = row[`Price ${i}`];
        
  //       if (qtyBreak && price) {
  //         priceBreaks.push({
  //           qty: qtyBreak,
  //           price: parseFloat(price.replace('$', ''))
  //         });
  //       }
  //     }

  //    // console.log(row)
  //     console.log({
  //         part_number: row['Requested Part']?.toString() || '',
  //         quotedPart: row['Quoted Part']?.toString() || '',
  //         description: row['Item Description'],
  //         qty: parseInt(row['Requested Qty']),
  //         quotedQty: parseInt(row['Quoted Qty']),
  //         um: row['Unit'],
  //         price: Math.ceil(parseFloat(row['Unit Price']?.replace('$', ''))),
  //         qtyAvailable: parseInt(row['Qty Available']),
  //         certs: row['CERTS'],
  //         warehouse: row['Warehouse'],
  //         notes: row['Notes'],
  //         dateNextIn: row['Date Next In'],
  //         qtyDueIn: parseInt(row['Qty Due In']),
  //         eccn: row['ECCN'],
  //         manufacturer: row['Manufacturer'],
  //         cureDate: row['Cure Date'],
  //         country: row['Country'],
  //         cageCode: row['Cage Code'],
  //         priceBreaks: priceBreaks
  //             .filter(priceBreak => {
  //                 const qty = parseFloat(priceBreak.qty.split('-')[0] || priceBreak.qty.split('+')[0]);
  //                 return !isNaN(qty) && !isNaN(priceBreak.price) && qty > 0 && priceBreak.price > 0;
  //             }).map(priceBreak => ({
  //               qty: parseInt(priceBreak.qty.split('-')[0] || priceBreak.qty.split('+')[0]),
  //               price: priceBreak.price
  //           }))
  //     });
  //   })

  // }

  // main()