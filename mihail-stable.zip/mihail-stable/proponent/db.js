require('dotenv').config({ path: '../.env' }); // загружает .env из родительской директории

const { MongoClient } = require('mongodb');

// Используем тот же URL, но добавляем параметры подключения
const mongourl = process.env.MONGODB_URL;
const dbName = process.env.MONGO_DB;

// Добавляем опции для повышения надежности подключения
const mongoOptions = {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    serverSelectionTimeoutMS: 10000,
    connectTimeoutMS: 30000,
    socketTimeoutMS: 60000,
    maxPoolSize: 10,
    retryWrites: true,
    w: 'majority'
};

// // Создаем один клиент для всего приложения
// let client = null;
// let db = null;

// // Функция для инициализации подключения
// async function connectToMongo() {
//     if (client && db) return { client, db };
//     try {
//         console.log(new Date(), `Подключение к MongoDB: ${mongourl}`);
//         client = new MongoClient(mongourl, mongoOptions);
//         await client.connect();
//         db = client.db(dbName);
//         console.log(new Date(), 'Успешное подключение к MongoDB');
//         return { client, db };
//     } catch (error) {
//         console.error(new Date(), 'Ошибка подключения к MongoDB:', error.message);
//         throw error;
//     }
// }


async function saveProcessedOrder(order) {
    const client = new MongoClient(mongourl);
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('orders');
        
        // Пытаемся вставить новый документ
        try {
            const orderData = {
                ...order,
                marketplace: "PROPONENT", // Устанавливаем marketplace
                processedAt: new Date(),
            };
            
            //console.log(new Date(), 'Подготовленные данные для сохранения:', JSON.stringify(orderData, null, 2));
            
            const result = await collection.insertOne(orderData);
            
            console.log(new Date(), `Заказ ${order.id} успешно сохранен в MongoDB. ID документа: ${result.insertedId}`);
            
            // Проверяем, что документ действительно сохранен
            const savedOrder = await collection.findOne({ _id: result.insertedId });
            if (savedOrder) {
                // console.log(new Date(), 'Подтверждение сохранения - документ найден:');
            } else {
                console.error(new Date(), 'Ошибка: документ не найден после сохранения');
            }
            
        } catch (error) {
            if (error.code === 11000) { // Код ошибки дубликата в MongoDB
                console.log(new Date(), `Заказ ${order.id} уже существует для marketplace proponent, пропускаем...`);
            } else {
                console.error(new Date(), 'Ошибка при сохранении заказа:', error);
                throw error; // Пробрасываем другие ошибки
            }
        }
    } catch (error) {
        console.error(new Date(), 'Критическая ошибка при работе с MongoDB:', error);
        throw error;
    } finally {
        try {
            await client.close();
            console.log(new Date(), 'Соединение с MongoDB закрыто');
        } catch (closeError) {
            console.error(new Date(), 'Ошибка при закрытии соединения:', closeError);
        }
    }
}

async function getUnprocessedOrders(orders) {
    const client = new MongoClient(mongourl);
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('orders');
        
        // Получаем список уже обработанных заказов для данного вендора
        const processedOrders = await collection.find(
            {
                id: { $in: orders.map(o => o.id) },
                marketplace: "PROPONENT"
            },
            { projection: { id: 1 } }
        ).toArray();
        
        const processedIds = new Set(processedOrders.map(o => o.id));
        
        // Фильтруем только необработанные заказы
        const unprocessedOrders = orders
            .filter(order => !processedIds.has(order.id))
            .filter(order => order.quote_id > 0)
            .filter(order => order.quote_id !== undefined)
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)); // Сортировка по timestamp (новые сначала);
        
        // Ограничиваем количество возвращаемых заказов до 50
        const limitedOrders = unprocessedOrders.slice(0, 50);
        
        console.log(new Date(), `Найдено ${unprocessedOrders.length} необработанных заказов из ${orders.length}, возвращаем ${limitedOrders.length}`);
        return limitedOrders;
    } catch (error) {
        console.error(new Date(), 'Критическая ошибка при работе с MongoDB:', error);
        throw error;
    } finally {
        try {
            await client.close();
            console.log(new Date(), 'Соединение с MongoDB закрыто');
        } catch (closeError) {
            console.error(new Date(), 'Ошибка при закрытии соединения:', closeError);
        }
    }
}

// // Функция для закрытия соединения при завершении работы
// async function closeMongoConnection() {
//     if (client) {
//         try {
//             await client.close();
//             console.log(new Date(), 'Соединение с MongoDB закрыто');
//         } catch (error) {
//             console.error(new Date(), 'Ошибка при закрытии соединения с MongoDB:', error.message);
//         }
//     }
// }

module.exports = {
    saveProcessedOrder,
    getUnprocessedOrders,
};