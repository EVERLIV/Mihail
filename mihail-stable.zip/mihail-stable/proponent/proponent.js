require('dotenv').config();
require('dotenv').config({ path: '../.env' }); // загружает .env из родительской директории

const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const { parseXLSX } = require('./xls');

const { hideHeadless } = require('./hideheadless')
puppeteer.use(StealthPlugin());

const { saveProcessedOrder, getUnprocessedOrders } = require('./db');


const fs = require('fs').promises;


// Configuration
const config = {
    loginURL: process.env.LOGINURL || "https://procart.proponent.com/Login.aspx",
    searchURL: process.env.SEARCHURL || "https://procart.proponent.com/Home.aspx",
    serverURL: process.env.PANTHEON_API_URL || "https://it.pantheon-mro.com/4robot",
    postQuoteUrl: process.env.POSTQUOTEURL || "/ms1api/add_supplier_proposal_query_aor/",
    getOrdersUrl: process.env.GETORDERSURL || "/ms1api/get_orders_tres_1000/",
    findOrder: process.env.FINDORDERSURL || "/ms1api/find_orders",
    authToken: process.env.API_AUTH_TOKEN,
    username: process.env.LOGIN,
    password: process.env.PASSWORD,
    proxyServer: process.env.PROXY_SERVER,
    proxyport: process.env.PROXY_PORT,
    proxyusername: process.env.PROXY_USERNAME,
    proxypassword: process.env.PROXY_PASSWORD,
    MAX_LEAD_TIME: process.env.MAX_LEAD_TIME || 30,
    delays: {
        typing: { min: 50, max: 100 },
        navigation: { min: 500, max: 2000 },
        clicking: { min: 100, max: 500 }
    }
};

console.log(config.serverURL)
console.log(process.env.NODE_ENV)
console.log(config.authToken)

// Добавляем проверку URL перед отправкой
console.log('Полный URL для отправки:', `${config.serverURL}${config.postQuoteUrl}`, config.authToken);

// Добавляем глобальную переменную для хранения заказов
let currentOrders = [];

// Функция получения заказов
async function getOrders() {
    console.log(new Date(), `${config.serverURL}${config.getOrdersUrl}`)
    try {
        const response = await fetch(`${config.serverURL}${config.getOrdersUrl}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': config.authToken
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const orders = await response.json();

        currentOrders = await getUnprocessedOrders(orders.filter(order => order.quote_id > 0)); // Добавляем параметр vendor
        console.log(new Date(), 'Загружено заказов:', orders.length)
        console.log(new Date(), 'В обработку:', currentOrders.length, 'заказов')
        let altParts = [];
        for (let order of currentOrders) {
            if (order.alternatives.length > 0) {
                for (let alt of order.alternatives) {
                    altParts.push(
                        {
                            id: order.id,
                            part_number: alt,
                            qty: order.qty,
                            quote_id: order.quote_id,
                        }
                    );
                }
            }
        }

        currentOrders = currentOrders.concat(altParts);
        console.log(new Date(), 'В обработку с альтернативными номерами:', currentOrders.length, 'заказов')
        // Формируем строку в нужном формате
        return currentOrders.map(order => `${order.part_number} ${order.qty}`).join('\n');


    } catch (error) {
        console.error(new Date(), 'Ошибка при получении заказов:', error.message);
        return null;
    }
}

async function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}



async function sendQuoteData(quoteData) {
    try {
        console.log(new Date(),
            `${config.serverURL}${config.postQuoteUrl}`,
            'Sending')
        console.log(new Date(), 'Данные для отправки:', JSON.stringify(quoteData, null, 2))

        const response = await fetch(`${config.serverURL}${config.postQuoteUrl}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': config.authToken,
                'Accept': 'application/json'
            },
            body: JSON.stringify(quoteData)
        });

        // if (!response.ok) {
        //     const errorText = await response.text();
        //     try {
        //         const errorJson = JSON.parse(errorText);
        //         // if (errorJson.error === 'aor_failed'
        //         //     && errorJson.message[0].ctx.error === 'No this part number in database') {
        //         //     console.log(new Date(), 'Заказ не найден, отправляем альтернативный номер');
        //         //     quoteData.part_number = alternativePartNumber;

        //         //     let altresp = await fetch(`${config.serverURL}${config.postQuoteUrl}`, {
        //         //         method: 'POST',
        //         //         headers: {
        //         //             'Content-Type': 'application/json',
        //         //             'Authorization': config.authToken,
        //         //             'Accept': 'application/json'
        //         //         },
        //         //         body: JSON.stringify(quoteData)
        //         //     });
        //         //     if (!altresp.ok) {
        //         //         throw new Error(`Ошибка при отправке альтернативного номера: ${altresp.status} - ${errorText}`);
        //         //     } else {
        //         //         console.log(new Date(), 'Альтернативный номер отправлен', JSON.stringify(altresp, null, 2));
        //         //     }
        //         //     //TODO send alt partnumber 
        //         // }
        //     } catch (error) {
        //         console.error(new Date(), 'Ошибка при отправке номера:', error);
        //     }
        //     console.error(new Date(), 'Ошибка ответа:', {
        //         status: response.status,
        //         statusText: response.statusText,
        //         body: errorText
        //     });
        //     throw new Error(`Ошибка при отправке данных: ${response.status} - ${errorText}`);
        // }

        try {
            const result = await response.json();
            console.log(new Date(), 'Данные успешно отправлены:', 'quote_id:', quoteData.quote_id, 'Result:', result);
            return result;
        } catch (error) {
            console.error(new Date(), 'Ошибка при разборе JSON ответа:', error);
            const textResponse = await response.text();
            console.log(new Date(), 'Текстовый ответ:', textResponse);
            throw error;
        }

    } catch (error) {
        console.error(new Date(), 'Ошибка при отправке данных:', error.message);
        if (error.stack) {
            console.error(new Date(), 'Stack trace:', error.stack);
        }
        return null;
    }
}

// Добавляем функцию нормализации строк
function normalizeString(str) {
    if (!str) return '';
    return str.replace(/[-/\\]/g, '').trim();
}

//<input id="MainContent_chkResultType_1" type="checkbox" name="ctl00$MainContent$chkResultType$1" value="EXCEL"></input>


async function findOrderInPantheon(partNumber) {
    try {
        console.log(new Date(), 'Поиск заказов в Pantheon', `${config.serverURL}${config.findOrder}?part_number=${partNumber}`);
        let response = await fetch(`${config.serverURL}${config.findOrder}?part_number=${partNumber}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': config.authToken
            }
        }).then(res => res.json());

        if (response.ok && response.data?.length) {
            const thirtyDaysAgo = new Date();
            thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

            let recentOrders = response.data.filter(order => {
                const orderDate = order.request_date ? new Date(order.request_date) : null;
                return orderDate && orderDate >= thirtyDaysAgo;
            });

            // Сортируем заказы по дате запроса в убывающем порядке
            recentOrders.sort((a, b) => {
                const dateA = new Date(a.request_date);
                const dateB = new Date(b.request_date);
                return dateB - dateA;
            });

            console.log(new Date(), `Отфильтровано ${recentOrders.length} заказов за последние 30 дней`);
            return recentOrders;
        }
        return [];
    } catch (error) {
        console.error(new Date(), 'Ошибка при поиске заказов в Pantheon:', error);
        return [];
    }
}

// Основная функция
const main = async () => {

    try {
        await fs.rm('./downloads', { recursive: true, force: true });
        await fs.mkdir('./downloads', { recursive: true });
        console.log(new Date(), 'Папка downloads очищена');
    } catch (error) {
        console.error(new Date(), 'Ошибка при очистке папки downloads:', error);
    }

    let ordersText = await getOrders()
    if (!ordersText) {
        console.log(new Date(), 'No orders found - exiting');
        await delay(60000)
        process.exit(0);
    }

    if (currentOrders.length === 0) {
        console.log(new Date(), 'Все заказы обработаны, завершаем работу');
        await delay(60000)
        process.exit(0);
    }

    console.log(new Date(), 'currentOrders', currentOrders.map(order => order.part_number))

    const browser = await puppeteer.launch({
        headless: "new",//process.env.NODE_ENV === 'production' ? "new" : false,
        defaultViewport: { width: 1920, height: 1200 },
        args: [
            '--window-size=1920,1200',
            //'--start-maximized',
            '--disable-session-crashed-bubble',
            '--no-sandbox',
            '--disable-notifications',
            '--disable-dev-shm-usage'
        ],
        userDataDir: './proponent_browsercache',
        persistentContext: true
    });

    //const page = await browser.newPage();
    const page = (await browser.pages())[0];

    // await page.authenticate({
    //     username: config.proxyusername,
    //     password: config.proxypassword,
    // }).catch(err => console.log(new Date(), err))






    // Устанавливаем дату и время в Гонконге
    // const hongKongDate = new Date().toLocaleString('en-US', { timeZone: 'Asia/Hong_Kong' });
    // const customDate = new Date(hongKongDate).toISOString();

    // // Устанавливаем часовой пояс Гонконга
    // await page.evaluateOnNewDocument(() => {
    //     Object.defineProperty(Intl.DateTimeFormat.prototype, 'resolvedOptions', {
    //         value: function () {
    //             return { timeZone: 'Asia/Hong_Kong' };
    //         }
    //     });

    //     Object.defineProperty(navigator, 'timezone', {
    //         value: 'Asia/Hong_Kong'
    //     });

    //     Object.defineProperty(Intl, 'defaultLocale', {
    //         value: 'zh-Hant-HK'
    //     });
    // });

    // await page.evaluateOnNewDocument((customDate) => {
    //     const originalDate = window.Date;
    //     const offset = new originalDate(customDate).getTime() - originalDate.now();

    //     window.Date = function () {
    //         return new originalDate(Date.now() + offset);
    //     };

    //     window.Date.now = function () {
    //         return originalDate.now() + offset;
    //     };

    //     const originalPerformanceNow = performance.now.bind(performance);
    //     performance.now = function now() {
    //         return originalPerformanceNow() + offset;
    //     };

    //     // Переопределяем методы для получения времени
    //     Intl.DateTimeFormat.prototype.format = function (date) {
    //         if (!(date instanceof Date)) {
    //             date = new Date(date);
    //         }
    //         return new originalDate(date.getTime() + offset).toLocaleString('en-US', { timeZone: 'Asia/Hong_Kong' });
    //     };
    // }, customDate);

    // try {
    //     await page.emulateTimezone('Asia/Hong_Kong');
    // } catch (e) {
    //     console.warn('Timezone setting not supported:', e.message);
    // }


    // Отлавливаем появление алерта и нажимаем кнопку
    page.on('dialog', async dialog => {
        //console.log(`Пойман диалог: ${dialog.type()} - "${dialog.message()}"`);

        if (dialog.type() === 'confirm') {
            await dialog.accept(); // Нажать "OK"
            // await dialog.dismiss(); // Нажать "Cancel"
        } else {
            await dialog.accept(); // Для alert и prompt просто закрывает
        }
    });



    // Добавляем обработку сигналов завершения
    process.on('SIGTERM', async () => {
        console.log(new Date(), 'SIGTERM received. Shutting down gracefully');
        try {
            // Сохраняем все необработанные заказы
            for (const order of currentOrders) {
                await saveProcessedOrder({
                    ...order,
                    processing_status: 'failed',
                    failure_reason: 'process_terminated'
                });
            }
            process.exit(0);
        } catch (error) {
            console.error(new Date(), 'Ошибка при завершении процесса:', error);
            process.exit(1);
        }
    });

    process.on('SIGINT', async () => {
        console.log(new Date(), 'SIGINT received. Shutting down gracefully');
        try {
            // Сохраняем все необработанные заказы
            for (const order of currentOrders) {
                await saveProcessedOrder({
                    ...order,
                    processing_status: 'failed',
                    failure_reason: 'process_interrupted'
                });
            }
            process.exit(0);
        } catch (error) {
            console.error(new Date(), 'Ошибка при завершении процесса:', error);
            process.exit(1);
        }
    });



    await hideHeadless(page);






    try {
        console.log(new Date(), 'goto', config.searchURL)
        await page.goto(config.searchURL)

        await delay(10000)


        let loginButton = await page.waitForSelector('#loginbutton', { timeout: 5000 })
            .catch(err => console.error(new Date(), err.message))
        if (loginButton) {
            console.log(new Date(), 'Login button found')
            await login(page);

            await delay(10000)





        } else {
            console.log(new Date(), 'Login button not found')
            let maintenence = await page.waitForSelector('.maintenance-inner')
            if (maintenence) {
                console.error(new Date(), 'Proponent.com is in Maintenance mode')
            }
        }

        await delay(10000)

        console.log(new Date(), 'Bulk search')

        let bulkSearch = await page.waitForSelector('#MainContent_txtBulkPart')
            .catch(err => console.error(new Date(), err.message))

        console.log(new Date(), 'typing')

        //console.log(new Date(),ordersText)
        if (bulkSearch) { await bulkSearch.type(ordersText) } //TODO

        console.log(new Date(), 'typed')

        let submitSearch = await page.waitForSelector('#MainContent_btnBulkSearch')
            .catch(err => console.error(new Date(), err.message))
        if (submitSearch) { await submitSearch.click() }

        console.log(new Date(), 'submitted')

        await delay(200000)


        // let select100 = await page.waitForSelector('.ui-pg-selbox')
        //         .catch(err => console.error(new Date(), err.message))
        // if (select100) {
        //     await select100.select('100').catch(err => console.error(new Date(), err.message))
        //     console.log(new Date(), 'Установлено количество результатов на странице: 100')
        // }


        // Ждем появления кнопки скачивания
        const downloadButton = await page.waitForSelector('#MainContent_lnkExport')
            .catch(err => console.error(new Date(), err.message));


        if (downloadButton) {
            // Настраиваем обработку скачивания файла
            await page.setRequestInterception(true);

            page.on('request', request => {
                try {
                    if (request.resourceType() === 'image') {
                        request.abort();
                    } else {
                        request.continue();
                    }
                } catch (error) {
                    console.error(new Date(), 'Ошибка при обработке запроса:', error);
                }
            });

            // Создаем директорию для сохранения файла, если её нет
            // await fs.mkdir('./downloads', { recursive: true });

            // Настраиваем путь для сохранения файла
            const client = await page.target().createCDPSession();
            await client.send('Page.setDownloadBehavior', {
                behavior: 'allow',
                downloadPath: './downloads'
            });

            // Кликаем по кнопке скачивания
            await downloadButton.click();
            console.log(new Date(), 'Запущено скачивание XLS файла');

            // Ждем завершения скачивания
            await delay(15000); // Даем время на скачивание файла

            // Получаем список файлов в директории downloads
            const files = await fs.readdir('./downloads');
            const xlsFile = files.find(file => file.endsWith('.xls') || file.endsWith('.xlsx'));
            if (!xlsFile) {
                console.log(new Date(), 'XLS файл не найден в директории downloads');
                for (const order of currentOrders) {
                    await saveProcessedOrder({
                        ...order,
                        processing_status: 'failed',
                        failure_reason: 'no_results_found'
                    });
                }
                await browser.close();
                process.exit(1);
            }
            const buffer = await fs.readFile(`./downloads/${xlsFile}`);
            await delay(1000);

            if (buffer) {
                try {
                    console.log(new Date(), 'XLS файл успешно скачан:', xlsFile);

                    // Читаем файл
                    let jsonData = await parseXLSX(buffer);

                    // Обрабатываем данные

                    console.log(new Date(), jsonData)

                    const processedData = jsonData.map(row => {
                        const priceBreaks = [];

                        // Парсим Qty Break из отдельных полей
                        for (let i = 1; i <= 5; i++) {
                            const qtyBreak = row[`Qty Break ${i}`];
                            const price = row[`Price ${i}`];

                            if (qtyBreak && price) {
                                priceBreaks.push({
                                    qty: qtyBreak,
                                    price: parseFloat(price.replace('$', ''))
                                });
                            }
                        }

                        return {
                            part_number: row['Requested Part']?.toString() || '',
                            quotedPart: row['Quoted Part']?.toString() || '',
                            description: row['Item Description'],
                            qty: parseInt(row['Requested Qty']),
                            quotedQty: parseInt(row['Quoted Qty']),
                            um: row['Unit'],
                            price: Math.ceil(parseFloat(row['Unit Price']?.replace('$', ''))),
                            qtyAvailable: parseInt(row['Qty Available']),
                            certs: row['CERTS'],
                            warehouse: row['Warehouse'],
                            notes: row['Notes'],
                            dateNextIn: row['Date Next In'],
                            qtyDueIn: parseInt(row['Qty Due In']),
                            eccn: row['ECCN'],
                            manufacturer: row['Manufacturer'],
                            cureDate: row['Cure Date'],
                            country: row['Country'],
                            cageCode: row['Cage Code'],
                            priceBreaks: priceBreaks
                                .filter(priceBreak => {
                                    const qty = parseFloat(priceBreak.qty.split('-')[0] || priceBreak.qty.split('+')[0]);
                                    return !isNaN(qty) && !isNaN(priceBreak.price) && qty > 0 && priceBreak.price > 0;
                                })
                                .map(priceBreak => ({
                                    qty: parseInt(priceBreak.qty.split('-')[0] || priceBreak.qty.split('+')[0]),
                                    price: priceBreak.price
                                }))
                        };
                    });



                    let filteredData = processedData.filter(item => (item.price && item.qtyAvailable > 0))
                    console.log(new Date(), 'Данные успешно обработаны:', filteredData, filteredData.priceBreaks);

                    if (filteredData.length === 0) {
                        console.log(new Date(), 'Нет данных для обработки, завершаем работу');
                        for (const order of currentOrders) {
                            await saveProcessedOrder({
                                ...order,
                                processing_status: 'success',
                                processed_at: new Date(),
                                failure_reason: 'no_results_found'
                            });
                        }
                    }

                    // Обрабатываем каждое предложение
                    for (const item of filteredData) {
                        console.log(new Date(), 'Обрабатываем предложение:', {
                            requestedPart: item.part_number,
                            quotedPart: item.quotedPart,
                            qty: item.qty,
                            price: item.price
                        });



                        // Функция для поиска заказа по номеру детали
                        const findMatchingOrder = (partNumber, alt = false) => {
                            return currentOrders.find(order => {
                                let normalizedOrderPart;
                                const normalizedQuotedPart = normalizeString(partNumber);

                                if (alt && order.alternatives) {
                                    for (const alt of order.alternatives) {
                                        normalizedOrderPart = normalizeString(alt);
                                        if (normalizedOrderPart === normalizedQuotedPart) {
                                            return true;
                                        }
                                    }
                                } else {
                                    normalizedOrderPart = normalizeString(order.part_number);

                                }
                                return normalizedOrderPart === normalizedQuotedPart
                            });
                        };

                        // Сначала ищем по quotedPart
                        let matchingOrder = findMatchingOrder(item.quotedPart);


                        // Если не нашли, пробуем по part_number
                        if (!matchingOrder) {
                            matchingOrder = findMatchingOrder(item.part_number);
                        }

                        if (!matchingOrder) {
                            matchingOrder = findMatchingOrder(item.part_number, true);
                        }

                        if (!matchingOrder) {
                            // Проверяем наличие заказов в Pantheon
                            const pantheonOrders = await findOrderInPantheon(item.part_number);
                            if (pantheonOrders.length > 0) {
                                for (const order of pantheonOrders) {
                                    console.log(new Date(), 'Заказ в Pantheon:', order);
                                }
                            }

                            let matchingOrders = pantheonOrders.filter(order => order.quote_id && order.quote_id > 0);
                            if (matchingOrders.length > 0) {
                                matchingOrder = matchingOrders[0];
                            }
                        }

                        // Если все еще не нашли и есть альтернативные номера, пробуем их


                        console.log(new Date(), 'Результат поиска:', matchingOrder ? {
                            found: true,
                            part_number: matchingOrder.part_number,
                            qty: matchingOrder.qty
                        } : {
                            found: false,
                            reason: 'Заказ не найден'
                        });

                        if (matchingOrder) {
                            currentOrders = currentOrders.filter(order =>
                                order.part_number !== matchingOrder.part_number);
                            // Находим подходящий price break
                            let finalPrice = item.price;
                            if (item.priceBreaks.length > 0) {
                                console.log(new Date(), 'Price breaks:', item.priceBreaks);
                                const applicableBreak = item.priceBreaks
                                    .filter(priceBreak => priceBreak.qty <= matchingOrder.qty)
                                    .sort((a, b) => b.qty - a.qty)[0];

                                if (applicableBreak) {
                                    finalPrice = applicableBreak.price;
                                }
                                console.log(new Date(), 'Final price:', finalPrice);
                            }


                            // Добавляем информацию об альтернативной части, если она отличается
                            //let alternativePartNumber = matchingOrder?.alternatives[0];
                            // const alternativePartNote = item.part_number !== item.quotedPart ?
                            // `This is alternative part - ${item.part_number}` : '';

                            item.um = item.um === 'GR' ? 'G' : item.um
                            item.um = item.um === 'RL' ? 'RO' : item.um
                            item.um = item.um === 'LT' ? 'L' : item.um
                            if (!["EA", "FT", "M", "YD", "KG", "LB", "G", "L", "OZ", "RO", "KT", "CA"].includes(item.um)) {
                                item.um = 'EA';
                            }


                            const quoteData = {
                                part_number: item.quotedPart,
                                qty: matchingOrder.qty,
                                delivery_place: item.warehouse === 'Brea, CA' ? 'USA' :
                                    item.warehouse === 'Netherlands' ? 'Netherland' :
                                        item.warehouse === 'Singapore' ? 'Singapore' : 'USA',
                                delivery_condition: 'EXW',
                                item_note: item.certs
                                    .replace("Contact Your Customer Relationship Manager for test report availability", '')
                                    .replace("(no charge if available on file)", '')
                                    .replace(/Proponent CofC/gi, '')
                                    .replace('ATA-106 upon request', ''), //+ ' ' + alternativePartNote,
                                customer_request_id: matchingOrder.id,
                                price: Math.ceil(parseFloat(finalPrice)),
                                supplier: "PROPONENT",
                                quote_id: matchingOrder.quote_id,
                                date: new Date().toISOString().split('T')[0],
                                valid_to: new Date(new Date().getTime() + 21 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                                condition: 'NE',
                                lead_time: 1,
                                time_unit: 'D',
                                currency: 'USD',
                                is_moq: false,
                                um: item.um,
                                email_subject: matchingOrder.id + ' ' + matchingOrder.description
                            };

                            // Добавляем логирование условий
                            console.log(new Date(), 'Проверка условий для', item.part_number, {
                                requestedQty: matchingOrder.qty,
                                availableQty: item.qtyAvailable,
                                leadTime: item.lead_time
                            });

                            // Модифицируем условия проверки
                            const hasEnoughStock = item.qtyAvailable >= matchingOrder.qty;
                            const hasReasonableLeadTime = !item.lead_time || item.lead_time <= config.MAX_LEAD_TIME;

                            if (hasEnoughStock && hasReasonableLeadTime) {
                                console.log(new Date(), 'Отправляем предложение для', item.part_number);
                                console.log(new Date(), quoteData)
                                await sendQuoteData(quoteData);
                                await saveProcessedOrder({
                                    ...matchingOrder,
                                    processing_status: 'success',
                                    processed_at: new Date()
                                });
                            } else {
                                console.log(new Date(), 'Неподходящие условия для', item.part_number, {
                                    reason: !hasEnoughStock ? 'insufficient_stock' : 'lead_time_too_long',
                                    details: {
                                        requestedQty: matchingOrder.qty,
                                        availableQty: item.qtyAvailable,
                                        leadTime: item.lead_time
                                    }
                                });
                                await saveProcessedOrder({
                                    ...matchingOrder,
                                    processing_status: 'failed',
                                    failure_reason: !hasEnoughStock ? 'insufficient_stock' : 'lead_time_too_long'
                                });
                            }
                        }
                    }

                    // Помечаем все оставшиеся заказы как обработанные
                    for (const order of currentOrders) {
                        await saveProcessedOrder({
                            ...order,
                            processing_status: 'success',
                            processed_at: new Date(),
                            failure_reason: 'no_results_found'
                        });
                    }

                    // Удаляем файл после обработки
                    if (process.env.NODE_ENV === 'production') {
                        await fs.unlink(`./downloads/${xlsFile}`);
                    }

                } catch (error) {
                    console.error(new Date(), 'Ошибка при обработке XLS файла:', error.message);
                    // Если ошибка связана с пустым файлом или отсутствием таблицы
                    if (error.message.includes('could not find <table>') || error.message.includes('Invalid HTML')) {
                        console.log(new Date(), 'XLS файл не содержит результатов, помечаем заказы как обработанные');
                        // Помечаем все текущие заказы как обработанные
                        for (const order of currentOrders) {
                            await saveProcessedOrder({
                                ...order,
                                processing_status: 'success',
                                processed_at: new Date(),
                                failure_reason: 'no_results_found'
                            });
                        }
                    }
                } finally {
                    await browser.close();
                    process.exit(0);
                }
            } else {
                console.error(new Date(), 'XLS файл не найден в директории downloads');
                const files = await fs.readdir('./downloads');
                console.log(new Date(), 'Содержимое директории downloads:', files);
                //
                await browser.close();
                process.exit(1);
            }
        } else {
            console.error(new Date(), 'Кнопка скачивания не найдена');
            if (browser) {
                await browser.close();
            }
            process.exit(1);
        }


    } catch (error) {
        console.error('An error occurred:', error.message);
        await browser.close();
        process.exit(1);
    }


};

// Запуск приложения
main().catch(error => {
    console.error(new Date(), 'Fatal error:', error);
    process.exit(1);
});
async function login(page) {
    //

    let loginButton = await page.waitForSelector('#loginbutton', { timeout: 5000 }).catch(err => console.error(new Date(), err.message))
    if (loginButton) { await loginButton.click() }

    let loginInput = await page.waitForSelector('#MainContent_txtUserName');
    if (loginInput) {
        await loginInput.click();
        await page.keyboard.down('Control');
        await page.keyboard.press('A');
        await page.keyboard.up('Control');
        await page.keyboard.press('Backspace');
        await loginInput.type(config.username);
    }
    let loginPassword = await page.waitForSelector('#MainContent_txtPassword');
    if (loginPassword) {
        await loginPassword.click();
        await page.keyboard.down('Control');
        await page.keyboard.press('A');
        await page.keyboard.up('Control');
        await page.keyboard.press('Backspace');
        await loginPassword.type(config.password);
    }
    let submitButton = await page.waitForSelector('#MainContent_btnLogin');
    if (submitButton) await submitButton.click();
    console.log(new Date(), 'Login button clicked');

    await delay(10000);

    //<button data-tid="banner-accept" class="termly-styles-module-root-aca1a3 termly-styles-module-primary-c1ce29 termly-styles-module-solid-ea3413 termly-styles-button-a4543c termly-styles-tooltip-d3b548 t-acceptAllButton" style="background: rgb(0, 0, 0); border-color: rgb(0, 0, 0); color: rgb(255, 255, 255); font-size: 12px; font-family: Roboto, &quot;Open Sans&quot;, Arial, Helvetica; font-weight: bold;">Accept</button>
    let acceptButton = await page.waitForSelector('button[data-tid="banner-accept"]', { timeout: 5000 })
        .catch(err => console.error(new Date(), err.message))
    if (acceptButton) {
        console.log(new Date(), 'Accept button found')
        await acceptButton.click()
    }

    let pageText = await page.evaluate(() => {
        return document.body.innerText;
    });
    console.log(new Date(), 'Page text:', pageText)

    if (pageText.includes('USERNAME')) {
        await page.screenshot({ path: './screenshots/proponentlogin.png' });
        await login(page);
    }
}

