const fs = require('fs');
const cheerio = require('cheerio');

try {
    // Читаем HTML файл
    const fileName = 'simplified_partsearchresults_22-05-2025.xlsx'
    
    const records = parseXLSfile(fileName);
    console.log(new Date(), 'Записей найдено:', records.length);
    if (records.length > 0) {
        console.log(new Date(), 'Пример первой записи:', JSON.stringify(records[0], null, 2));
    }

} catch (error) {
    console.error('Ошибка при чтении файла:', error);
    console.error('Stack trace:', error.stack);
}


function parseXLSfile(xlsFile) {
    try {
        console.log(new Date(), 'Начинаем обработку файла:');
        
        // Читаем HTML файл
        let fssync = require('fs');
        const fileContent = fssync.readFileSync(`./downloads/${xlsFile}`, 'utf-8');
        console.log(new Date(), 'Размер файла:', fileContent.length, 'символов');
        
        // Загружаем HTML в cheerio
        const $ = cheerio.load(fileContent);
        
        // Находим основную таблицу с данными
        const table = $('table');
        if (!table.length) {
            console.error(new Date(), 'Таблица не найдена в файле');
            return null;
        }
        console.log(new Date(), 'Таблица найдена');
        
        // Получаем заголовки
        const headers = [];
        const headerRow = table.find('tr').eq(0);
        if (!headerRow.length) {
            console.error(new Date(), 'Строка заголовков не найдена');
            return null;
        }
        
        headerRow.find('th').each((i, elem) => {
            const header = $(elem).text();
            if (header) {
                headers.push(header);
            }
        });
        
        console.log(new Date(), 'Найдены заголовки:', headers);
        
        // Получаем данные
        const records = [];
        const dataRows = table.find('tr').slice(1);
        console.log(new Date(), 'Найдено строк данных:', dataRows.length);
        
        dataRows.each((i, row) => {
            const record = {};
            const rowText = $(row).text();
            
            // Проверяем, что это не строка с условиями Proponent
            if (rowText.includes("All Prices and Availability Subject to Change") ||
                rowText.includes("Quote is subject to Proponent's Terms and Conditions")) {
                return;
            }
            
            // Обрабатываем каждую ячейку
            $(row).find('td').each((j, cell) => {
                const value = $(cell).text().trim();
                const header = headers[j];
                
                if (!header) {
                    console.warn(new Date(), 'Заголовок не найден для ячейки:', value);
                    return;
                }
                
                // Обработка специальных случаев
                if (header === 'CERTS') {
                    record[header] = value
                        ?.replace(/^\*\*\*\*\* CERT NOTES FOR .*? \*\*\*\*\*/g, '')
                        ?.replace(/\n/g, ' | ')
                        ?.replace(/\s+/g, ' ')
                        ?.trim();
                } else if (header === 'Notes') {
                    record[header] = value?.replace(/\n/g, ' | ');
                } else if (header === 'Date Next In') {
                    record[header] = value?.replace(/\n/g, ' | ');
                } else if (header.includes('Qty Break') || header.includes('Price')) {
                    record[header] = value;
                } else {
                    record[header] = value;
                }
            });
            
            // Проверяем, что запись содержит необходимые данные
            if (Object.keys(record).length > 0 && record['Requested Part']) {
                records.push(record);
            } else {
                console.warn(new Date(), 'Пропущена строка без необходимых данных:', rowText);
            }
        });
        
        console.log(new Date(), 'Записей найдено:', records.length);
        if (records.length > 0) {
            console.log(new Date(), 'Пример первой записи:', JSON.stringify(records[0], null, 2));
        }
        
        return records;
        
    } catch (error) {
        console.error(new Date(), 'Ошибка при чтении файла:', error.message);
        console.error(new Date(), 'Stack trace:', error.stack);
        return null;
    }
}