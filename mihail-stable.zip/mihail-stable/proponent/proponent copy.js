require('dotenv').config();
require('dotenv').config({ path: '../.env' }); // загружает .env из родительской директории

const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const XLSX = require('xlsx');

const { hideHeadless } = require('./hideheadless')
puppeteer.use(StealthPlugin());

const { saveProcessedOrder, getUnprocessedOrders } = require('./db');


const fs = require('fs').promises;


// Configuration
const config = {
    loginURL: process.env.LOGINURL || "https://procart.proponent.com/Login.aspx",
    searchURL: process.env.SEARCHURL || "https://procart.proponent.com/Home.aspx",
    serverURL: process.env.PANTHEON_API_URL, //TODO - change to production
    postQuoteUrl: process.env.POSTQUOTEURL,
    getOrdersUrl: process.env.GETORDERSURL,
    authToken: process.env.API_AUTH_TOKEN,
    username: process.env.LOGIN,
    password: process.env.PASSWORD,
    proxyServer: process.env.PROXY_SERVER,
    proxyport: process.env.PROXY_PORT,
    proxyusername: process.env.PROXY_USERNAME,
    proxypassword: process.env.PROXY_PASSWORD,
    delays: {
        typing: { min: 50, max: 100 },
        navigation: { min: 500, max: 2000 },
        clicking: { min: 100, max: 500 }
    }
};

console.log(config.serverURL)
console.log(process.env.NODE_ENV)

// Добавляем глобальную переменную для хранения заказов
let currentOrders = [];


// Функция получения заказов
async function getOrders() {
    console.log(new Date(),`${config.serverURL}${config.getOrdersUrl}`)
    try {
        const response = await fetch(`${config.serverURL}${config.getOrdersUrl}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': config.authToken
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const orders = await response.json();

        currentOrders = await getUnprocessedOrders(orders.filter(order => order.quote_id > 0)); // Добавляем параметр vendor
        console.log(new Date(),'Загружено заказов:', orders.length)
        console.log(new Date(),'В обработку:', currentOrders.length, 'заказов')
        // Формируем строку в нужном формате
        return currentOrders.map(order => `${order.part_number} ${order.qty}`).join('\n');
        

    } catch (error) {
        console.error(new Date(),'Ошибка при получении заказов:', error.message);
        return null;
    }
}

async function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}



async function sendQuoteData(quoteData) {
    try {
        console.log(new Date(),
            `${config.serverURL}${config.postQuoteUrl}`,
            'Sending' + JSON.stringify(quoteData))
        let response;
         if (process.env.NODE_ENV === 'production') {
             response = await fetch(`${config.serverURL}${config.postQuoteUrl}`, {
                 method: 'POST',
                 headers: {
                     'Content-Type': 'application/json',
                     'Authorization': config.authToken
                    },
                    body: JSON.stringify(quoteData)
                });
                const result = await response.json();
                console.log(new Date(),'Данные успешно отправлены:', 'QuoteID:', quoteData.quoteID, 'Result:', result);
                return result;
        } else {
            console.log(new Date(),'Отправляем в Пропонент понарошку')
            response = {ok: true}
        }

        if (!response.ok) {
            throw new Error(`Ошибка при отправке данных: ${response.status}`);
        }

    } catch (error) {
        console.error(new Date(),'Ошибка при отправке данных:', error.message);
        return null;
    }
}

// Добавляем функцию нормализации строк
function normalizeString(str) {
    if (!str) return '';
    return str.replace(/[-/\\]/g, '').trim();
}

// Основная функция
const main = async () => {
    const browser = await puppeteer.launch({
        headless: process.env.NODE_ENV === 'production' ? "new" : false,
        defaultViewport: null,
        args: ['--start-maximized',
            `--proxy-server=http://${config.proxyServer}:${config.proxyport}`,
            '--start-maximized',
            '--disable-session-crashed-bubble',
            '--no-sandbox',
            '--disable-notifications',
            '--disable-dev-shm-usage'
        ],
        userDataDir: './proponent_browsercache',
        persistentContext: true
    });

    const page = (await browser.pages())[0];

    await page.authenticate({
        username: config.proxyusername,
        password: config.proxypassword,
    }).catch(err => console.log(new Date(), err));

    // Устанавливаем дату и время в Гонконге
    const hongKongDate = new Date().toLocaleString('en-US', { timeZone: 'Asia/Hong_Kong' });
    const customDate = new Date(hongKongDate).toISOString();

    // Устанавливаем часовой пояс Гонконга
    await page.evaluateOnNewDocument(() => {
        Object.defineProperty(Intl.DateTimeFormat.prototype, 'resolvedOptions', {
            value: function () {
                return { timeZone: 'Asia/Hong_Kong' };
            }
        });

        Object.defineProperty(navigator, 'timezone', {
            value: 'Asia/Hong_Kong'
        });

        Object.defineProperty(Intl, 'defaultLocale', {
            value: 'zh-Hant-HK'
        });
    });

    await page.evaluateOnNewDocument((customDate) => {
        const originalDate = window.Date;
        const offset = new originalDate(customDate).getTime() - originalDate.now();

        window.Date = function () {
            return new originalDate(Date.now() + offset);
        };

        window.Date.now = function () {
            return originalDate.now() + offset;
        };

        const originalPerformanceNow = performance.now.bind(performance);
        performance.now = function now() {
            return originalPerformanceNow() + offset;
        };

        // Переопределяем методы для получения времени
        Intl.DateTimeFormat.prototype.format = function (date) {
            if (!(date instanceof Date)) {
                date = new Date(date);
            }
            return new originalDate(date.getTime() + offset).toLocaleString('en-US', { timeZone: 'Asia/Hong_Kong' });
        };
    }, customDate);

    try {
        await page.emulateTimezone('Asia/Hong_Kong');
    } catch (e) {
        console.warn('Timezone setting not supported:', e.message);
    }


    // Отлавливаем появление алерта и нажимаем кнопку
    page.on('dialog', async dialog => {
        //console.log(`Пойман диалог: ${dialog.type()} - "${dialog.message()}"`);

        if (dialog.type() === 'confirm') {
            await dialog.accept(); // Нажать "OK"
            // await dialog.dismiss(); // Нажать "Cancel"
        } else {
            await dialog.accept(); // Для alert и prompt просто закрывает
        }
    });


    await hideHeadless(page);

    // Настраиваем обработку запросов один раз при инициализации
    await page.setRequestInterception(true);
    page.on('request', request => {
        try {
            if (request.resourceType() === 'image') {
                request.abort();
            } else {
                request.continue();
            }
        } catch (error) {
            console.error(new Date(), 'Ошибка при обработке запроса:', error);
        }
    });

    try {
        // Логин выполняется только один раз
        await page.goto(config.searchURL);
        let loginButton = await page.waitForSelector('#loginbutton', { timeout: 5000 })
            .catch(err => console.error(new Date(),err.message));
        if (loginButton) {
            await loginButton.click();
            let loginInput = await page.waitForSelector('#MainContent_txtUserName');
            if (loginInput) await loginInput.type(config.username);
            let loginPassword = await page.waitForSelector('#MainContent_txtPassword');
            if (loginPassword) await loginPassword.type(config.password);
            let submitButton = await page.waitForSelector('#MainContent_btnLogin');
            if (submitButton) await submitButton.click();
        } else {
            console.log(new Date(),'Login button not found');
            let maintenence = await page.waitForSelector('.maintenance-inner');
            if (maintenence) {
                console.error(new Date(),'Proponent.com is in Maintenance mode');
                await browser.close();
                process.exit(1);
            }
        }

        // Основной цикл обработки заказов
        while (true) {
            let ordersText = await getOrders();
            if (!ordersText) {
                console.log(new Date(),'No orders found - exiting');
                break;
            }

            if (currentOrders.length === 0) {
                console.log(new Date(), 'Все заказы обработаны, завершаем работу');
                break;
            }

            console.log(new Date(), `Обрабатываем ${currentOrders.length} заказов`);

            let bulkSearch = await page.waitForSelector('#MainContent_txtBulkPart');
            if (bulkSearch) {
                await bulkSearch.type(ordersText);
                let submitSearch = await page.waitForSelector('#MainContent_btnBulkSearch');
                if (submitSearch) await submitSearch.click();
                await delay(60000);
                // Ждем загрузки результатов поиска
                // await page.waitForSelector('#MainContent_gvSearchResults', { timeout: 30000 })
                //     .catch(err => console.error(new Date(), 'Ошибка ожидания результатов поиска:', err.message));

                // Включаем переключатель для Excel формата
                // const excelCheckbox = await page.waitForSelector('#MainContent_chkResultType_0');
                // if (excelCheckbox) {
                //     await excelCheckbox.click();
                //     console.log(new Date(), 'Переключатель Excel формата включен');
                // }

                // Ждем появления кнопки скачивания
                const downloadButton = await page.waitForSelector('#MainContent_lnkExport')
                                .catch(err => console.error(new Date(),err.message));
                if (downloadButton) {
                    // Создаем Promise для ожидания ответа с данными
                    const downloadPromise = new Promise((resolve, reject) => {
                        let responseHandler = async response => {
                            try {
                                const url = response.url();
                                console.log(new Date(), 'Получен ответ:', url);
                                
                                // Проверяем, что это ответ с XLS файлом
                                if (url.includes('PartSearchResults.aspx')) {
                                    const contentType = response.headers()['content-type'];
                                    console.log(new Date(), 'Content-Type:', contentType);
                                    
                                    if (contentType && (contentType.includes('application/vnd.ms-excel') || 
                                        contentType.includes('application/octet-stream'))) {
                                        const buffer = await response.buffer();
                                        resolve(buffer);
                                    } else {
                                        reject(new Error(`Неверный тип контента: ${contentType}`));
                                    }
                                }
                            } catch (error) {
                                reject(error);
                            }
                        };

                        // Устанавливаем обработчик ответа
                        page.once('response', responseHandler);
                        
                        // Устанавливаем таймаут
                        setTimeout(() => {
                            reject(new Error('Таймаут ожидания ответа'));
                        }, 30000);
                    });

                    // Кликаем по кнопке скачивания
                    await downloadButton.click();
                    console.log(new Date(), 'Запущено получение XLS данных');

                    try {
                        // Получаем данные в буфер
                        const buffer = await downloadPromise;
                        console.log(new Date(), 'Данные успешно получены, размер:', buffer.length);

                        // Читаем файл из буфера
                        const workbook = XLSX.read(buffer, { type: 'buffer' });
                        
                        // Проверяем, есть ли листы в файле
                        if (!workbook.SheetNames || workbook.SheetNames.length === 0) {
                            console.log(new Date(), 'XLS файл пустой, помечаем заказы как обработанные');
                            // Помечаем все текущие заказы как обработанные
                            for (const order of currentOrders) {
                                await saveProcessedOrder({
                                    ...order,
                                    processing_status: 'success',
                                    processed_at: new Date(),
                                    failure_reason: 'no_results_found'
                                });
                            }
                            continue;
                        }
                        
                        // Получаем первый лист
                        const firstSheetName = workbook.SheetNames[0];
                        const worksheet = workbook.Sheets[firstSheetName];
                        
                        // Проверяем, есть ли данные в листе
                        if (!worksheet['!ref']) {
                            console.log(new Date(), 'Лист пустой, помечаем заказы как обработанные');
                            // Помечаем все текущие заказы как обработанные
                            for (const order of currentOrders) {
                                await saveProcessedOrder({
                                    ...order,
                                    processing_status: 'success',
                                    processed_at: new Date(),
                                    failure_reason: 'no_results_found'
                                });
                            }
                            continue;
                        }
                        
                        // Конвертируем в JSON
                        const jsonData = XLSX.utils.sheet_to_json(worksheet);
                        console.log(new Date(), 'Получено строк из XLS:', jsonData.length);
                        
                        // Обрабатываем данные
                        const processedData = jsonData.map(row => {
                            return {
                                partNumber: row['Requested Part'],
                                quotedPart: row['Quoted Part'],
                                description: row['Item Description'],
                                qty: row['Requested Qty'],
                                quotedQty: row['Quoted Qty'],
                                um: row['Unit'],
                                price: row['Unit Price'],
                                qtyAvailable: row['Qty Available'],
                                certs: row['CERTS'],
                                warehouse: row['Warehouse'],
                                notes: row['Notes'],
                                dateNextIn: row['Date Next In'],
                                qtyDueIn: row['Qty Due In'],
                                eccn: row['ECCN'],
                                manufacturer: row['Manufacturer'],
                                cureDate: row['Cure Date'],
                                country: row['Country'],
                                cageCode: row['Cage Code'],
                                priceBreaks: [
                                    { qty: row['Qty Break 1'], price: row['Price 1'] },
                                    { qty: row['Qty Break 2'], price: row['Price 2'] },
                                    { qty: row['Qty Break 3'], price: row['Price 3'] },
                                    { qty: row['Qty Break 4'], price: row['Price 4'] },
                                    { qty: row['Qty Break 5'], price: row['Price 5'] }
                                ].filter(priceBreak => priceBreak.qty && priceBreak.price)
                            };
                        });

                        let filteredData = processedData.filter(item => (item.price && item.qtyAvailable > 0));
                        console.log(new Date(), 'Данные успешно обработаны:', filteredData);
                        
                        // Обрабатываем каждое предложение
                        for (const item of filteredData) {
                            console.log(new Date(), 'Обрабатываем предложение:', {
                                requestedPart: item.partNumber,
                                quotedPart: item.quotedPart,
                                qty: item.qty,
                                price: item.price
                            });
                            
                            // Сначала ищем по quotedPart, если не найдено - ищем по partNumber
                            const matchingOrder = currentOrders.find(order => {
                                const normalizedOrderPart = normalizeString(order.part_number);
                                const normalizedQuotedPart = normalizeString(item.quotedPart);
                                const normalizedRequestedPart = normalizeString(item.partNumber);
                                
                                const matchesQuotedPart = normalizedOrderPart === normalizedQuotedPart;
                                const matchesRequestedPart = normalizedOrderPart === normalizedRequestedPart;
                                
                                
                                return matchesQuotedPart || matchesRequestedPart;
                            });
                            
                            console.log(new Date(), 'Результат поиска:', matchingOrder ? {
                                found: true,
                                part_number: matchingOrder.part_number,
                                qty: matchingOrder.qty
                            } : {
                                found: false,
                                reason: 'Заказ не найден'
                            });

                            if (matchingOrder) {
                                // Находим подходящий price break
                                let finalPrice = item.price;
                                if (item.priceBreaks.length > 0) {
                                    console.log(new Date(), 'Price breaks:', item.priceBreaks);
                                    const applicableBreak = item.priceBreaks
                                        .filter(priceBreak => priceBreak.qty <= matchingOrder.qty)
                                        .sort((a, b) => b.qty - a.qty)[0];
                                    
                                    if (applicableBreak) {
                                        finalPrice = applicableBreak.price;
                                    }
                                    console.log(new Date(), 'Final price:', finalPrice);
                                }

                                // Добавляем информацию об альтернативной части, если она отличается
                                const alternativePartNote = item.partNumber !== item.quotedPart ? 
                                    `This is alternative part - ${item.partNumber}` : '';

                                const quoteData = {
                                    part_number: item.quotedPart, // Используем quotedPart как основной номер
                                    qty: matchingOrder.qty,
                                    delivery_place: item.warehouse === 'Brea, CA' ? 'USA' :
                                         item.warehouse === 'Netherlands' ? 'Netherland' : 'USA',
                                    delivery_condition: 'EXW',
                                    item_note: [
                                        alternativePartNote,
                                        item.description || '',
                                        item.notes || '',
                                        item.certs || '',
                                        item.manufacturer ? `Manufacturer: ${item.manufacturer}` : '',
                                        item.qtyAvailable ? `Available qty: ${item.qtyAvailable}` : ''
                                    ]
                                        .filter(item => item && item.trim() !== '')
                                        .join(' | ')
                                        .replace(/Trace[^.,;]*/gi, '')
                                        .replace(/MOV[^.,;]*/gi, '')
                                        .replace(/Exchange[^.,;]*/gi, '')
                                        .replace(/Core[^.,;]*/gi, '')
                                        .replace(/Cost[^.,;]*/gi, '')
                                        .replace(/BER[^.,;]*/gi, '')
                                        .replace(/Hazmat[^.,;]*/gi, '')
                                        .replace(/PROCESSING[^.,;]*/gi, '')
                                        .replace(/HANDLING[^.,;]*/gi, '')
                                        .replace(/MINIMUM[^.,;]*/gi, '')
                                        .replace(/PACKAGE[^.,;]*/gi, '')
                                        .replace(/FREIGHT[^.,;]*/gi, '')
                                        .replace(/SHIPPING[^.,;]*/gi, '')
                                        .replace(/Handling[^.,;]*/gi, '')
                                        .replace(/Processing[^.,;]*/gi, '') 
                                        .replace(/Warranty[^.,;]*/gi, '')
                                        .replace(/WRNTY[^.,;]*/gi, '')
                                        .replace(/Proponent\s+C\s+of\s+C/gi, '')
                                        .replace(/Proponent CofC/g,'')
                                        .replace(/Proponent[^.,;]*/gi, '')
                                        .replace(/^[.,;:!?\s]+/, '')
                                        .replace(/Proponent\s+C\s+of\s+C/gi, '')
                                        .replace(/MIN PO:\s*\$\d+,\s*/i, '')
                                        .replace(/DAR Fee:\s*\$\d+\.?\d*/i, '') 
                                        .replace(/Contact your[^|]*/gi, '')
                                        .replace(/\(no charge[^)]*\)/gi, '')
                                        .replace(/\\n/g, '| ')
                                        .replace(/\n/g, '| ')
                                        .replace(/<br>/g, '| ')
                                        .replace(/\*/g, '') + `\n | Available qty: ${Math.floor(item.qtyAvailable - item.qtyAvailable * 0.2)}`,
                                    customer_request_id: matchingOrder.id,
                                    price: Math.ceil(parseFloat(finalPrice)),
                                    supplier: "PROPONENT",
                                    quote_id: matchingOrder.quote_id,
                                    date: new Date().toISOString().split('T')[0],
                                    valid_to: new Date(new Date().getTime() + 21 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                                    condition: 'NE',
                                    lead_time: 1,
                                    time_unit: 'D',
                                    currency: 'USD',
                                    is_moq: false,
                                    um: item.um,
                                    email_subject: matchingOrder.id + ' ' + matchingOrder.description
                                };
                            
                                if (matchingOrder.qty <= item.qtyAvailable * 1.2) {
                                    console.log(new Date(), 'Отправляем предложение для', item.partNumber);
                                    console.log(new Date(), 'Quote data:', quoteData);
                                    await sendQuoteData(quoteData);
                                    await saveProcessedOrder({
                                        ...matchingOrder,
                                        processing_status: 'success',
                                        processed_at: new Date()
                                    });
                                } else {
                                    console.log(new Date(), 'Недостаточное количество для', item.partNumber);
                                    await saveProcessedOrder({
                                        ...matchingOrder,
                                        processing_status: 'failed',
                                        failure_reason: 'insufficient_stock'
                                    });
                                }
                            }
                        }
                        
                        // Удаляем файл после обработки
                            await fs.unlink(`./downloads/${xlsFile}`);
                            console.log(new Date(), 'Файл удален после обработки');
                        
                    } catch (error) {
                        console.error(new Date(), 'Ошибка при обработке XLS файла:', error);
                        // Если ошибка связана с пустым файлом или отсутствием таблицы
                        if (error.message.includes('could not find <table>') || error.message.includes('Invalid HTML')) {
                            console.log(new Date(), 'XLS файл не содержит результатов, помечаем заказы как обработанные');
                            // Помечаем все текущие заказы как обработанные
                            for (const order of currentOrders) {
                                await saveProcessedOrder({
                                    ...order,
                                    processing_status: 'success',
                                    processed_at: new Date(),
                                    failure_reason: 'no_results_found'
                                });
                            }
                        }
                    }
                }
            }

            // Ждем перед следующей итерацией
            await page.goto(config.searchURL);
            await delay(5000);
        }

    } catch (error) {
        console.error('An error occurred:', error.message);
    } finally {
        await browser.close();
        process.exit(0);
    }
};

// Запуск приложения
main().catch(error => {
    console.error(new Date(),'Fatal error:', error);
    process.exit(1);
});

