require('dotenv').config({ path: '../.env' }); // загружает .env из родительской директории

const { MongoClient } = require('mongodb');

const mongourl = process.env.MONGODB_URL

const dbName = process.env.MONGO_DB;

console.log(mongourl, dbName);






async function saveProcessedRFQ(rfqData) {
    let client;
    try {
        client = await MongoClient.connect(mongourl);
        const db = client.db(dbName);
        const rfqCollection = db.collection('rfqs');

        // Сохраняем данные RFQ
        if (rfqData && rfqData.length > 0) {
            const result = await rfqCollection.insertMany(
                rfqData.map(item => ({
                    ...item,
                    processedAt: new Date()
                }))
            );
            console.log(`Сохранено ${result.insertedCount} RFQ записей`);
        }
    } catch (error) {
        console.error('Ошибка при сохранении RFQ данных:', error);
        throw error;
    } finally {
        if (client) {
            await client.close();
        }
    }
}

async function getLastProcessedRFQDate() {
    let client;
    try {
        client = await MongoClient.connect(mongourl);
        const db = client.db(dbName);
        const rfqCollection = db.collection('rfqs');

        // Находим последнюю запись, отсортированную по дате RFQ
        const lastRecord = await rfqCollection
            .find({})
            .sort({ rfqDate: -1 })
            .limit(1)
            .toArray();

        if (lastRecord && lastRecord.length > 0) {
            return lastRecord[0].rfqDate;
        }
        return null;
    } catch (error) {
        console.error('Ошибка при получении последней даты RFQ:', error);
        return null;
    } finally {
        if (client) {
            await client.close();
        }
    }
}

async function saveVendorToMongoDB(vendorData) {
    let client;
    try {
        client = await MongoClient.connect(mongourl);
        const db = client.db(dbName);
        const vendorsCollection = db.collection('vendors');

        const existingVendor = await vendorsCollection.findOne({
            EmailAddress: vendorData.EmailAddress
        });

        if (existingVendor) {
            const result = await vendorsCollection.updateOne(
                { EmailAddress: vendorData.EmailAddress },
                { $set: vendorData }
            );
            //logger.info(`Vendor data updated, matched: ${result.matchedCount}`);
        } else {
            const result = await vendorsCollection.insertOne(vendorData);
            //logger.info(`New vendor data saved with id: ${result.insertedId}`);
        }
    } catch (error) {
        console.error('Error saving to MongoDB:', error);
        throw error;
    } finally {
        if (client) {
            await client.close();
        }
    }
}

async function getStatistics(vendor_email, order_id) {
    let client;
    try {
        client = await MongoClient.connect(mongourl);
        const db = client.db(dbName);
        const statsCollection = db.collection('statistics');

        const result = await statsCollection.findOne({
            marketplace: "stockmarket.aero",
            vendor_email,
            order_id
        });

        return result ? true : false ; 
    } catch (error) {
        console.error('Error getting statistics:', error);
        throw error;
    } finally {
        if (client) {
            await client.close();
        }
    }
}

async function saveStatistics(part_number, vendor_email, timestamp, order_id) {
    let client;
    try {
        client = await MongoClient.connect(mongourl);
        const db = client.db(dbName);
        const statsCollection = db.collection('statistics');

        await statsCollection.insertOne({
            marketplace: "stockmarket.aero",
            part_number,
            vendor_email,
            timestamp,
            order_id,
            created_at: new Date()
        });
    } catch (error) {
        console.error('Error saving statistics:', error);
    } finally {
        if (client) {
            await client.close();
        }
    }
}

async function saveProcessedOrder(order) {
    let client;
    try {
        client = await MongoClient.connect(mongourl);
        const db = client.db(dbName);
        const ordersCollection = db.collection('orders');

        const existingOrder = await ordersCollection.findOne({
            id: order.id,
            part_number: order.part_number
        });

        if (existingOrder) {
            await ordersCollection.updateOne(
                { id: order.id },
                { $set: { ...order, processed: true, marketplace: "stockmarket.aero" } }
            );
        } else {
            await ordersCollection.insertOne({
                ...order,
                marketplace: "stockmarket.aero",
                processed: true,
                processedAt: new Date()
            });
        }
    } catch (error) {
        console.error('Error saving processed order:', error);
        throw error;
    } finally {
        if (client) {
            await client.close();
        }
    }
}

async function getUnprocessedOrders(orders) {
    let client;
    try {
        client = await MongoClient.connect(mongourl);
        const db = client.db(dbName);
        const ordersCollection = db.collection('orders');

        const processedOrders = await ordersCollection.find(
            {
                id: { $in: orders.map(o => o.id) },
                processed: true,
                marketplace: "stockmarket.aero"
            },
            { projection: { id: 1 } }
        ).toArray();

        const processedIds = new Set(processedOrders.map(o => o.id));
        return orders
            .filter(order => !processedIds.has(order.id))
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)); // Сортировка по timestamp (новые сначала)
    } catch (error) {
        console.error('Error getting unprocessed orders:', error);
        throw error;
    } finally {
        if (client) {
            await client.close();
        }
    }
}

async function updateOrdersWithoutStatistics() {
    let client;
    try {
        client = await MongoClient.connect(mongourl);
        const db = client.db(dbName);
        const ordersCollection = db.collection('orders');
        const statsCollection = db.collection('statistics');

        // Получаем все обработанные заказы
        const processedOrders = await ordersCollection.find({
            processed: true,
            marketplace: "stockmarket.aero"
        }).toArray();

        console.log(`Найдено ${processedOrders.length} обработанных заказов для проверки`);
        let updatedCount = 0;

        // Проверяем каждый заказ на наличие статистики
        for (const order of processedOrders) {
            console.log(`Проверка заказа ID: ${order.id}, Поставщик: ${order.vendor_email}`);
            
            const hasStatistics = await statsCollection.findOne({
                marketplace: "stockmarket.aero",
                vendor_email: order.vendor_email,
                order_id: order.id
            });

            // Если статистики нет, обновляем статус заказа
            if (!hasStatistics) {
                console.log(`Статистика не найдена для заказа ID: ${order.id}, обновляем статус на processed: false`);
                await ordersCollection.updateOne(
                    { _id: order._id },
                    { $set: { processed: false } }
                );
                updatedCount++;
            } else {
                console.log(`Статистика найдена для заказа ID: ${order.id}, статус не изменен`);
            }
        }

        console.log(`Обновлено ${updatedCount} заказов (processed: false)`);
        return updatedCount;
    } catch (error) {
        console.error('Ошибка при обновлении статуса заказов:', error);
        throw error;
    } finally {
        if (client) {
            await client.close();
        }
    }
}

module.exports = {
    saveVendorToMongoDB,
    saveStatistics,
    saveProcessedOrder,
    getUnprocessedOrders,
    getStatistics,
    saveProcessedRFQ,
    getLastProcessedRFQDate,
    updateOrdersWithoutStatistics
}; 


updateOrdersWithoutStatistics()