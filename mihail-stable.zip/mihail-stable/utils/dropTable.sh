#!/bin/bash

# Загрузка переменных из файла .env
if [ -f .env ]; then
  export $(grep -v '^#' ../.env | xargs)
else
  echo "Файл .env не найден"
  exit 1
fi

# Захардкоженные параметры MongoDB
MONGODB_URL="mongodb://mongodb:27018/vendorsDB"
MONGO_CONTAINER_NAME="parser-mongodb-1"
MONGO_DB="vendorsDB"
COLLECTION_NAME="rfqs"

echo "Подключение к MongoDB в контейнере $MONGO_CONTAINER_NAME"
echo "URL: $MONGODB_URL"
echo "Коллекция: $COLLECTION_NAME"

# Запрос пользователю на подтверждение удаления
read -p "Вы уверены, что хотите полностью удалить коллекцию $COLLECTION_NAME? (y/n): " confirm
if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]; then
  # Выполнение команды для удаления коллекции
  sudo docker exec -it $MONGO_CONTAINER_NAME mongosh "$MONGODB_URL" --eval "
    db.$COLLECTION_NAME.drop();
    print('Коллекция $COLLECTION_NAME успешно удалена');
  "
  echo "Удаление коллекции выполнено."
else
  echo "Операция удаления отменена."
fi