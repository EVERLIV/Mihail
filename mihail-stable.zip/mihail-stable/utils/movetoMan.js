// Загрузка переменных окружения из .env файла
require('dotenv').config();
require('dotenv').config({ path: '../.env' }); // загружает .env из родительской директории
const Imap = require('imap');
const { MongoClient } = require('mongodb');

// Конфигурация IMAP
const imapConfig = {
  user: process.env.EMAIL_USER,
  password: process.env.EMAIL_PASSWORD,
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT || 993,
  tls: true,
  tlsOptions: { rejectUnauthorized: false }
};

// Функция для подключения к почтовому ящику
function connectToMailbox() {
  return new Promise((resolve, reject) => {
    const imap = new Imap(imapConfig);
    
    imap.once('ready', () => {
      imap.openBox('INBOX.PROCESSED', false, (err, box) => {
        if (err) {
          imap.end();
          return reject(err);
        }
        resolve(imap);
      });
    });
    
    imap.once('error', (err) => {
      reject(err);
    });
    
    imap.connect();
  });
}

// Функция для поиска писем по message_id
function searchEmailsByMessageId(imap, messageIds) {
  return new Promise((resolve, reject) => {
    imap.search(['ALL'], (err, results) => {
      if (err) return reject(err);
      if (!results || !results.length) {
        console.log('Не найдено писем в папке INBOX.PROCESSED');
        return resolve([]);
      }
      
      console.log(`Всего писем в папке INBOX.PROCESSED: ${results.length}`);
      
      // Создаем Set для быстрого поиска
      const messageIdSet = new Set(messageIds.map(id => id.trim().toLowerCase()));
      const messageIdSetNoBrackets = new Set(messageIds.map(id => id.trim().replace(/[<>]/g, '').toLowerCase()));
      
      const fetch = imap.fetch(results, { bodies: 'HEADER' });
      const matchedUids = [];
      const allMessageIds = [];
      
      fetch.on('message', (msg, seqno) => {
        let uid;
        let messageId;
        
        msg.on('attributes', (attrs) => {
          uid = attrs.uid;
          // Проверяем, есть ли уже messageId, и если да, проверяем соответствие
          if (messageId) {
            checkAndAddUid(messageId, uid);
          }
        });
        
        msg.on('body', (stream, info) => {
          let buffer = '';
          
          stream.on('data', (chunk) => {
            buffer += chunk.toString('utf8');
          });
          
          stream.on('end', () => {
            const headers = Imap.parseHeader(buffer);
            messageId = headers['message-id'] ? headers['message-id'][0] : null;
            
            if (messageId) {
              allMessageIds.push(messageId);
              
              // Если uid уже получен, проверяем соответствие
              if (uid) {
                checkAndAddUid(messageId, uid);
              }
            }
          });
        });
        
        // Функция для проверки и добавления uid в matchedUids
        function checkAndAddUid(msgId, msgUid) {
          const normalizedId = msgId.trim().toLowerCase();
          const idWithoutBrackets = normalizedId.replace(/[<>]/g, '');
          
          if (messageIdSet.has(normalizedId) || 
              messageIdSetNoBrackets.has(idWithoutBrackets) ||
              messageIdSet.has(idWithoutBrackets) ||
              messageIdSetNoBrackets.has(normalizedId)) {
            console.log(`Найдено соответствие для message_id: ${msgId}, UID: ${msgUid}`);
            matchedUids.push(msgUid);
          }
        }
      });
      
      fetch.on('error', (err) => {
        reject(err);
      });
      
      fetch.on('end', () => {
        console.log(`Всего уникальных message_id в папке: ${new Set(allMessageIds).size}`);
        console.log(`Первые 5 message_id из базы данных: ${messageIds.slice(0, 5).join(', ')}`);
        console.log(`Первые 5 message_id из папки: ${allMessageIds.slice(0, 5).join(', ')}`);
        console.log(`Найдено соответствий: ${matchedUids.length}`);
        console.log('Returning', matchedUids.length, 'uids');
        
        if (matchedUids.length === 0) {
          console.log("Странная ситуация: в логах видны совпадения, но массив matchedUids пуст");
          console.log("Проверяем последние добавленные элементы в matchedUids:", matchedUids.slice(-5));
        }
        
        resolve(matchedUids);
      });
    });
  });
}

// Функция для перемещения письма в другую папку
function moveEmail(imap, uid, folder) {
  return new Promise((resolve, reject) => {
    imap.move(uid, folder, (err) => {
      if (err) return reject(err);
      resolve(true);
    });
  });
}

// Функция для получения записей из MongoDB
async function getRecordsToProcess() {
  let client;

  try {
    // Подключаемся к MongoDB
    const url = process.env.MONGODB_URL;
    client = new MongoClient(url);

    await client.connect();
    const db = client.db('vendorsDB');
    
    // Получаем записи с quoteID = 0 или null
    const nullQuoteIdRecords = await db.collection('pantheon_quotes').find({
      $or: [
        { quoteID: 0 },
        { quoteID: null }
      ]
    }).toArray();
    
    console.log(`Найдено записей с quoteID = 0 или null: ${nullQuoteIdRecords.length}`);
    
    // Получаем записи с pantheon_sent_at и sent_to_pantheon: false
    const sentNotProcessedRecords = await db.collection('pantheon_quotes').find({
      pantheon_sent_at: { $exists: true },
      sent_to_pantheon: false
    }).toArray();
    
    console.log(`Найдено записей с pantheon_sent_at и sent_to_pantheon: false: ${sentNotProcessedRecords.length}`);
    
    // Объединяем результаты
    const allRecords = [...nullQuoteIdRecords, ...sentNotProcessedRecords];
    
    // Извлекаем message_id из записей
    const messageIds = allRecords
      .filter(record => record.message_id)
      .map(record => record.message_id);
    
    console.log(`Всего записей с message_id: ${messageIds.length}`);
    
    return messageIds;
  } catch (error) {
    console.error("Ошибка при получении данных из базы данных:", error);
    return [];
  } finally {
    if (client) {
      await client.close();
    }
  }
}

// Основная функция для перемещения писем
async function moveEmailsToManual() {
  let imap;
  try {
    console.log(new Date(), 'Подключение к почтовому ящику...');
    imap = await connectToMailbox();
    console.log(new Date(), 'Подключение успешно установлено');
    
    // Получаем message_id писем, которые нужно переместить
    const messageIds = await getRecordsToProcess();
    
    if (messageIds.length === 0) {
      console.log(new Date(), 'Нет писем для перемещения');
      imap.end();
      return;
    }
    
    console.log(new Date(), `Найдено ${messageIds.length} писем для перемещения в INBOX.MANUAL`);
    
    // Ищем письма по message_id
    const uids = await searchEmailsByMessageId(imap, messageIds);
    console.log('uids returned', uids.length)

    if (uids.length === 0) {
      console.log(new Date(), 'Не найдено писем с указанными message_id в папке INBOX.PROCESSED');
      imap.end();
      return;
    }
    
    console.log(new Date(), `Найдено ${uids.length} писем для перемещения`);
    
    // Перемещаем каждое письмо
    for (const uid of uids) {
      try {
        if (uid === undefined) {
          console.log('Пропускаем undefined UID');
          continue;
        }
        await moveEmail(imap, uid, 'INBOX.MANUAL');
        console.log(new Date(), `Письмо с UID ${uid} перемещено в папку INBOX.MANUAL`);
      } catch (err) {
        console.error(`Ошибка при перемещении письма ${uid}:`, err);
      }
    }
    
    console.log(new Date(), 'Перемещение писем завершено');
  } catch (err) {
    console.error('Произошла ошибка:', err);
  } finally {
    if (imap && imap.state !== 'disconnected') {
      imap.end();
      console.log(new Date(), 'Соединение закрыто');
    }
  }
}

// Запуск скрипта
moveEmailsToManual();

// Экспорт функций для тестирования
module.exports = {
  connectToMailbox,
  searchEmailsByMessageId,
  moveEmail,
  getRecordsToProcess,
  moveEmailsToManual
};