#!/bin/bash

# Захардкоженные параметры MongoDB
MONGODB_URL="mongodb://mongodb:27018/vendorsDB"
MONGO_CONTAINER_NAME="parser-mongodb-1"
MONGO_DB="vendorsDB"

echo "Подключение к MongoDB в контейнере $MONGO_CONTAINER_NAME"
echo "URL: $MONGODB_URL"
echo "Коллекция: pantheon_quotes"

# Сначала выведем записи, которые будут изменены
echo "Записи, которые будут изменены:"
sudo docker exec -it $MONGO_CONTAINER_NAME mongosh "$MONGODB_URL" --eval 'db.pantheon_quotes.find({$or: [{"um": "SET"}, {"um": "PC"}]})'

# Запрос пользователю на подтверждение изменения
read -p "Вы уверены, что хотите изменить um для этих записей? (y/n): " confirm
if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]; then
  # Выполнение запроса на обновление записей с from, содержащим @aircraftparts.net
  sudo docker exec -it $MONGO_CONTAINER_NAME mongosh "$MONGODB_URL" --eval 'db.pantheon_quotes.updateMany({$or: [{"um": "SET"}, {"um": "PC"}]}, {$set: {"um": "EA"}})'
  echo "Обновление записей выполнено."
else
  echo "Операция обновления отменена."
fi

# Вывод записей, где поле um пусто или равно PC
echo "Записи, где поле um пусто или равно 'PC':"
sudo docker exec -it $MONGO_CONTAINER_NAME mongosh "$MONGODB_URL" --eval 'db.pantheon_quotes.find({$or: [{"um": ""}, {"um": "PC"}, {"um": {$exists: false}}]}).limit(5).forEach(printjson)'

# Запрос пользователю на подтверждение изменения поля um
read -p "Вы уверены, что хотите изменить поле um на 'EA' для записей, где оно пусто или равно 'PC'? (y/n): " confirm_um
if [[ $confirm_um == [yY] || $confirm_um == [yY][eE][sS] ]]; then
  # Выполнение запроса на обновление записей с пустым полем um или um=PC
  sudo docker exec -it $MONGO_CONTAINER_NAME mongosh "$MONGODB_URL" --eval 'db.pantheon_quotes.updateMany({$or: [{"um": ""}, {"um": "PC"}]}, {$set: {"um": "EA"}})'
  echo "Обновление поля um выполнено."
  
else
  echo "Операция обновления поля um отменена."
fi