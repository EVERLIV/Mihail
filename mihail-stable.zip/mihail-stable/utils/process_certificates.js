// Загрузка переменных окружения из .env файла
require('dotenv').config();
require('dotenv').config({ path: '../.env' }); // загружает .env из родительской директории
const Imap = require('imap');
const { simpleParser } = require('mailparser');
const pdfParse = require('pdf-parse');
const { MongoClient } = require('mongodb');
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');

// Конфигурация IMAP
const imapConfig = {
  user: process.env.EMAIL_USER,
  password: process.env.EMAIL_PASSWORD,
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT || 993,
  tls: true,
  tlsOptions: { rejectUnauthorized: false }
};

// Функция для подключения к почтовому ящику
function connectToMailbox() {
  return new Promise((resolve, reject) => {
    const imap = new Imap(imapConfig);
    
    imap.once('ready', () => {
      imap.openBox('INBOX.PROCESSED1', false, (err, box) => {
        if (err) {
          imap.end();
          return reject(err);
        }
        resolve(imap);
      });
    });
    
    imap.once('error', (err) => {
      reject(err);
    });
    
    imap.connect();
  });
}

// Функция для поиска писем в папке PROCESSED1
function searchProcessedEmails(imap, count = 10000) {
  return new Promise((resolve, reject) => {
    imap.search(['ALL'], (err, results) => {
      if (err) return reject(err);
      if (!results || !results.length) {
        return resolve([]);
      }
      
      // Сортируем результаты по убыванию (сначала новые)
      results.sort((a, b) => b - a);
      
      // Берем только первые count писем
      const uids = results.slice(0, count);
      resolve(uids);
    });
  });
}

// Функция для получения содержимого письма
function fetchEmail(imap, uid) {
  return new Promise((resolve, reject) => {
    const fetch = imap.fetch(uid, { bodies: '', markSeen: false });
    
    fetch.on('message', (msg) => {
      let buffer = '';
      
      msg.on('body', (stream) => {
        stream.on('data', (chunk) => {
          buffer += chunk.toString('utf8');
        });
        
        stream.on('end', () => {
          simpleParser(buffer)
            .then(parsed => {
              resolve({
                uid: uid,
                parsed: parsed,
                messageId: parsed.messageId
              });
            })
            .catch(err => reject(err));
        });
      });
      
      msg.on('error', (err) => {
        reject(err);
      });
    });
    
    fetch.on('error', (err) => {
      reject(err);
    });
    
    fetch.on('end', () => {
      // Завершение выборки
    });
  });
}

// Функция для извлечения текста из PDF
async function extractTextFromPDF(buffer) {
  try {
    const data = await pdfParse(buffer);
    return data.text;
  } catch (error) {
    console.error('Ошибка при извлечении текста из PDF:', error);
    return null;
  }
}

// Функция для проверки, является ли PDF сертификатом
function isPdfCertificate(filename, pdfText) {
  // Проверяем имя файла на наличие ключевых слов
  const filenameCheck = filename.toLowerCase().includes('cert') || 
                        filename.toLowerCase().includes('certificate') || 
                        filename.toLowerCase().includes('form8130');
  
  // Если имя файла уже указывает на сертификат, возвращаем true
  if (filenameCheck) return true;
  
  // Можно добавить дополнительные проверки содержимого PDF
  return false;
}

// Функция для загрузки PDF в S3
async function uploadPdfToS3(pdfBuffer, filename, messageId) {
  try {
    // Создаем клиент S3 с использованием переменных окружения
    const s3Client = new S3Client({
      region: process.env.S3_REGION,
      credentials: {
        accessKeyId: process.env.S3_ACCESS_KEY,
        secretAccessKey: process.env.S3_SECRET_KEY
      },
      endpoint: process.env.S3_ENDPOINT_URL
    });
    
    // Генерируем уникальное имя файла, используя messageId и оригинальное имя файла
    const sanitizedMessageId = messageId.replace(/[<>]/g, '').replace(/[^a-zA-Z0-9]/g, '_');
    const uniqueFilename = `certificates/${sanitizedMessageId}/${filename}`;
    
    // Загружаем файл в S3
    const command = new PutObjectCommand({
      Bucket: process.env.S3_BUCKET_NAME,
      Key: uniqueFilename,
      Body: pdfBuffer,
      ContentType: 'application/pdf'
    });
    
    const response = await s3Client.send(command);
    
    // Формируем URL для доступа к файлу (для логирования)
    const fileUrl = `${process.env.S3_ENDPOINT_URL}/${process.env.S3_BUCKET_NAME}/${uniqueFilename}`;
    
    console.log(`PDF-сертификат успешно загружен в S3: ${fileUrl}`);
    return {
      success: true,
      url: filename, // Возвращаем только имя файла вместо полного URL
      key: uniqueFilename
    };
  } catch (error) {
    console.error('Ошибка при загрузке PDF в S3:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

// Функция для обновления записи в MongoDB
async function updateCertificatesInDatabase(messageId, certificateUrls) {
  let client;

  try {
    // Подключаемся к MongoDB
    const url = process.env.MONGODB_URL;
    client = new MongoClient(url);

    await client.connect();
    const db = client.db('vendorsDB');
    
    // Обновляем запись в коллекции pantheon_quotes
    const result = await db.collection('pantheon_quotes').updateOne(
      { message_id: messageId },
      { $set: { certificates: certificateUrls } }
    );
    
    if (result.matchedCount === 0) {
      console.log(`Запись с message_id ${messageId} не найдена в базе данных`);
      return false;
    }
    
    console.log(`Запись с message_id ${messageId} успешно обновлена в базе данных`);
    return true;
  } catch (error) {
    console.error("Ошибка при обновлении данных в базе данных:", error);
    return false;
  } finally {
    if (client) {
      await client.close();
    }
  }
}

// Функция для перемещения письма в другую папку
function moveEmail(imap, uid, folder) {
  return new Promise((resolve, reject) => {
    imap.move(uid, folder, (err) => {
      if (err) return reject(err);
      resolve(true);
    });
  });
}

// Основная функция для обработки писем
async function processCertificatesFromEmails(count = 100) {
  let imap;
  try {
    console.log(new Date(), 'Подключение к почтовому ящику...');
    imap = await connectToMailbox();
    console.log(new Date(), 'Подключение успешно установлено');
    
    // Получаем список писем из папки PROCESSED1
    const uids = await searchProcessedEmails(imap, count);
    
    if (uids.length === 0) {
      console.log(new Date(), 'Папка INBOX.PROCESSED1 пуста');
      imap.end();
      return;
    }
    
    console.log(new Date(), `Найдено ${uids.length} писем для проверки на наличие сертификатов`);
    
    // Обрабатываем каждое письмо
    for (const uid of uids) {
      try {
        console.log(new Date(), `Обрабатываем письмо ${uid}`);
        
        // Получаем содержимое письма
        const email = await fetchEmail(imap, uid);
        const { attachments, messageId } = email.parsed;
        
        let certificateUrls = []; // Массив для хранения URL сертификатов
        let hasCertificates = false;
        
        // Проверяем наличие вложений
        if (attachments?.length) {
          for (const attachment of attachments) {
            console.log(`- Вложение в письме ${uid}:`, attachment.filename);
            
            // Проверяем, является ли вложение PDF-файлом
            if (attachment?.filename?.toLowerCase().includes('pdf') && !attachment?.filename?.includes('General Terms')) {
              const pdfText = await extractTextFromPDF(attachment.content);
              
              if (pdfText) {
                // Проверяем, является ли PDF сертификатом
                if (isPdfCertificate(attachment.filename, pdfText)) {
                  console.log(`PDF-файл ${attachment.filename} определен как сертификат`);
                  
                  // Загружаем сертификат в S3
                  const uploadResult = await uploadPdfToS3(attachment.content, attachment.filename, messageId);
                  
                  if (uploadResult.success) {
                    // Добавляем URL сертификата в массив
                    certificateUrls.push(uploadResult.url);
                    hasCertificates = true;
                  }
                }
              }
            }
          }
        }
        
        // Если найдены сертификаты, обновляем запись в базе данных
        if (hasCertificates) {
          console.log(`Найдены сертификаты в письме ${uid}, обновляем запись в базе данных`);
          const updateResult = await updateCertificatesInDatabase(messageId, certificateUrls);
          
          if (updateResult) {
            // Перемещаем письмо в папку PROCESSED2 после успешной обработки
            await moveEmail(imap, uid, 'INBOX.PROCESSED');
            console.log(new Date(), `Письмо ${uid} перемещено в папку INBOX.PROCESSED`);
          }
        } else {
          console.log(`В письме ${uid} не найдены сертификаты`);
          // Перемещаем письмо в папку PROCESSED2, так как сертификатов нет
          await moveEmail(imap, uid, 'INBOX.PROCESSED');
          console.log(new Date(), `Письмо ${uid} перемещено в папку INBOX.PROCESSED`);
        }
      } catch (err) {
        console.error(`Ошибка при обработке письма ${uid}:`, err);
      }
    }
  } catch (err) {
    console.error('Произошла ошибка:', err);
  } finally {
    if (imap && imap.state !== 'disconnected') {
      imap.end();
      console.log(new Date(), 'Соединение закрыто');
    }
  }
}

// Запуск скрипта для обработки 100 писем
processCertificatesFromEmails(10000);

// Экспорт функций для тестирования
module.exports = {
  connectToMailbox,
  searchProcessedEmails,
  fetchEmail,
  extractTextFromPDF,
  isPdfCertificate,
  uploadPdfToS3,
  updateCertificatesInDatabase,
  processCertificatesFromEmails
}; 