#!/bin/bash

# Загрузка переменных из файла .env
if [ -f .env ]; then
  export $(grep -v '^#' .env | xargs)
else
  echo "Файл .env не найден"
  exit 1
fi

# Имя контейнера с MongoDB (замените на ваше)
MONGODB_URL="mongodb://mongodb:27018/vendorsDB"
MONGO_CONTAINER_NAME="parser-mongodb-1"
MONGO_DB="vendorsDB"

echo "Подключение к MongoDB в контейнере $MONGO_CONTAINER_NAME"
echo "База данных: $MONGO_DB"
echo "Коллекция: pantheon_quotes"

# Выполнение запроса к MongoDB внутри контейнера для поиска записей с quoteID=0 или null
sudo docker exec -it $MONGO_CONTAINER_NAME mongosh $MONGODB_URL --eval 'db.pantheon_quotes.find({certificates: {$exists: true}}).forEach(printjson)'

echo "Запрос выполнен."
