#!/bin/bash

# Загрузка переменных из файла .env
if [ -f .env ]; then
  export $(grep -v '^#' ../.env | xargs)
else
  echo "Файл .env не найден"
  exit 1
fi

# Захардкоженные параметры MongoDB
MONGODB_URL="mongodb://mongodb:27018/vendorsDB"
MONGO_CONTAINER_NAME="parser-mongodb-1"
MONGO_DB="vendorsDB"

# Создаем массив с запрещенными доменами из blacklist.js
BLACKLIST=(
  'airpartstock'
  'turboresources'
  'avair.aero'
  'aviodirect'
  'turboresources'
  'aerodirect'
  'aviationexcess'
  'lht.dlh.de'
  'zinaflight'
  'seattleav'
  'magneticgroup'
  'fltechnics'
  'aerotechnic-china'
  'xiamen'
  'jetmidwest'
  'stockmarket@componentcontrol.com'
  'myuas'
)

# Формируем запрос MongoDB с использованием JavaScript-синтаксиса
MONGO_QUERY_JS="
  const query = { \$or: [
"

for domain in "${BLACKLIST[@]}"; do
  MONGO_QUERY_JS+="    { from: { \$regex: '$domain', \$options: 'i' } },
"
done

# Удаляем последнюю запятую и добавляем закрывающую скобку
MONGO_QUERY_JS+="  ]};
"

echo "Подключение к MongoDB в контейнере $MONGO_CONTAINER_NAME"
echo "URL: $MONGODB_URL"
echo "Коллекция: pantheon_quotes"

# Сначала выведем записи, которые будут удалены
echo "Записи, которые будут удалены (содержащие в поле 'from' слова из черного списка):"
sudo docker exec -it $MONGO_CONTAINER_NAME mongosh "$MONGODB_URL" --eval "
$MONGO_QUERY_JS
db.pantheon_quotes.find(query).forEach(printjson);
"

# Запрос пользователю на подтверждение удаления
read -p "Вы уверены, что хотите удалить эти записи? (y/n): " confirm
if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]; then
  # Выполнение запроса на удаление записей
  sudo docker exec -it $MONGO_CONTAINER_NAME mongosh "$MONGODB_URL" --eval "
$MONGO_QUERY_JS
const result = db.pantheon_quotes.deleteMany(query);
print('Удалено записей: ' + result.deletedCount);
"
  echo "Удаление записей выполнено."
else
  echo "Операция удаления отменена."
fi