#!/bin/bash

# Захардкоженные параметры MongoDB
MONGODB_URL="mongodb://mongodb:27018/vendorsDB"
MONGO_CONTAINER_NAME="parser-mongodb-1"
MONGO_DB="vendorsDB"

echo "Подключение к MongoDB в контейнере $MONGO_CONTAINER_NAME"
echo "URL: $MONGODB_URL"
echo "Коллекция: orders"

# Сначала выведем записи, которые будут изменены (случай 1)
echo "Записи с vendor: PROPONENT и marketplace: stockmarket.aero:"
sudo docker exec -it $MONGO_CONTAINER_NAME mongosh "$MONGODB_URL" --eval 'db.orders.find({"vendor": "PROPONENT"}).limit(5).forEach(printjson)'

# Запрос пользователю на подтверждение изменения (случай 1)
read -p "Вы уверены, что хотите обновить эти записи? (y/n): " confirm
if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]; then
  # Выполнение запроса на обновление записей (случай 1)
  sudo docker exec -it $MONGO_CONTAINER_NAME mongosh "$MONGODB_URL" --eval 'db.orders.updateMany(
    {"vendor": "PROPONENT"},
    {
      $set: {"marketplace": "PROPONENT"},
      $unset: {"vendor": ""}
    }
  )'
  echo "Обновление записей выполнено (случай 1)."
else
  echo "Операция обновления отменена (случай 1)."
fi

# Теперь обработаем записи только с vendor: PROPONENT (случай 2)
echo "Записи только с vendor: PROPONENT:"
sudo docker exec -it $MONGO_CONTAINER_NAME mongosh "$MONGODB_URL" --eval 'db.orders.find({"vendor": "PROPONENT", "marketplace": {$exists: false}}).limit(5).forEach(printjson)'

# Запрос пользователю на подтверждение изменения (случай 2)
read -p "Вы уверены, что хотите обновить эти записи? (y/n): " confirm2
if [[ $confirm2 == [yY] || $confirm2 == [yY][eE][sS] ]]; then
  # Выполнение запроса на обновление записей (случай 2)
  sudo docker exec -it $MONGO_CONTAINER_NAME mongosh "$MONGODB_URL" --eval 'db.orders.updateMany(
    {"vendor": "PROPONENT", "marketplace": {$exists: false}},
    {
      $set: {"marketplace": "PROPONENT"},
      $unset: {"vendor": ""}
    }
  )'
  echo "Обновление записей выполнено (случай 2)."
else
  echo "Операция обновления отменена (случай 2)."
fi

# Вывод обновленных записей для проверки
echo "Обновленные записи:"
sudo docker exec -it $MONGO_CONTAINER_NAME mongosh "$MONGODB_URL" --eval 'db.orders.find({"marketplace": "PROPONENT"}).limit(5).forEach(printjson)'