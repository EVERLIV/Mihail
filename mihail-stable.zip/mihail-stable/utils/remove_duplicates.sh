#!/bin/bash

# Загрузка переменных из файла .env
if [ -f .env ]; then
  export $(grep -v '^#' .env | xargs)
else
  echo "Файл .env не найден"
  exit 1
fi

# Имя контейнера с MongoDB
MONGODB_URL="mongodb://mongodb:27018/vendorsDB"
MONGO_CONTAINER_NAME="parser-mongodb-1"
MONGO_DB="vendorsDB"

echo "Подключение к MongoDB в контейнере $MONGO_CONTAINER_NAME"
echo "База данных: $MONGO_DB"
echo "Коллекция: orders"

# Создаем временную коллекцию с уникальными записями
echo "Создание временной коллекции с уникальными записями..."
sudo docker exec -it $MONGO_CONTAINER_NAME mongosh $MONGODB_URL --eval '
db.orders.aggregate([
  { $match: { vendor: "PROPONENT", marketplace: null } },
  { $sort: { createdAt: -1 } },
  {
    $group: {
      _id: "$id",
      doc: { $first: "$$ROOT" }
    }
  },
  { $replaceRoot: { newRoot: "$doc" } },
  { $out: "orders_unique" }
])'

# Удаляем старую коллекцию
echo "Удаление старой коллекции..."
sudo docker exec -it $MONGO_CONTAINER_NAME mongosh $MONGODB_URL --eval '
db.orders.drop()'

# Переименовываем новую коллекцию
echo "Переименование новой коллекции..."
sudo docker exec -it $MONGO_CONTAINER_NAME mongosh $MONGODB_URL --eval '
db.orders_unique.renameCollection("orders")'

# Создаем индекс для оптимизации
# echo "Создание индекса..."
# sudo docker exec -it $MONGO_CONTAINER_NAME mongosh $MONGODB_URL --eval '
# db.orders.createIndex({ id: 1, vendor: 1 }, { unique: true })'

echo "Операция завершена успешно!"
echo "Статистика:"
sudo docker exec -it $MONGO_CONTAINER_NAME mongosh $MONGODB_URL --eval '
print("Количество записей в коллекции orders: " + db.orders.countDocuments())' 