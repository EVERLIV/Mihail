#!/bin/bash

# Проверяем, передан ли аргумент
if [ $# -eq 0 ]; then
    echo "Ошибка: Необходимо указать номер заказа"
    echo "Использование: $0 <номер_заказа>"
    exit 1
fi

# Загружаем переменные окружения
source .env

# Имя контейнера с MongoDB
MONGODB_URL="mongodb://mongodb:27018/vendorsDB"
MONGO_CONTAINER_NAME="parser-mongodb-1"
MONGO_DB="vendorsDB"

# Получаем номер заказа из аргумента
ORDER_ID=$1

echo "Подключение к MongoDB в контейнере $MONGO_CONTAINER_NAME"
echo "База данных: $MONGO_DB"
echo "Коллекция: orders"

echo "Проверяем заказ $ORDER_ID:"
echo "----------------------------------------"

# Проверяем заказ
echo "Заказ $ORDER_ID:"
sudo docker exec -it $MONGO_CONTAINER_NAME mongosh $MONGODB_URL --eval "
db.orders.find({
    id: $ORDER_ID
  }).forEach(printjson)"

echo "----------------------------------------"

# Проверяем статистику по заказу
echo "Статистика по заказу:"
sudo docker exec -it $MONGO_CONTAINER_NAME mongosh $MONGODB_URL --eval "
db.statistics.find({
    order_id: $ORDER_ID
}).forEach(printjson)"

echo "Запрос выполнен."