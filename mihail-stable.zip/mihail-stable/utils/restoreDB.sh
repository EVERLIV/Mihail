#!/bin/bash

# Загрузка переменных из файла .env
if [ -f ../.env ]; then
  export $(grep -v '^#' ../.env | xargs)
else
  echo "Файл .env не найден"
  exit 1
fi

# Параметры MongoDB
MONGODB_URL="mongodb://mongodb:27018/vendorsDB"
MONGO_CONTAINER_NAME="parser-mongodb-1"
MONGO_DB="vendorsDB"
BACKUP_DIR="./BACKUP"
BACKUP_NAME="vendorsDB_20250327_183102"
COLLECTION_NAME="orders"

echo "Восстановление коллекции $COLLECTION_NAME из резервной копии"
echo "Контейнер: $MONGO_CONTAINER_NAME"
echo "База данных: $MONGO_DB"
echo "Путь бэкапа: $BACKUP_DIR/$BACKUP_NAME"

# Копируем бэкап внутрь контейнера
echo "Копирование бэкапа в контейнер..."
sudo docker cp $BACKUP_DIR/$BACKUP_NAME $MONGO_CONTAINER_NAME:/tmp/restore

# Восстанавливаем только коллекцию orders
echo "Восстановление коллекции $COLLECTION_NAME..."
sudo docker exec -it $MONGO_CONTAINER_NAME mongorestore \
    --host mongodb \
    --port 27018 \
    --db $MONGO_DB \
    --collection $COLLECTION_NAME \
    --drop \
    /tmp/restore/$COLLECTION_NAME.bson

# Очистка временных файлов в контейнере
echo "Очистка временных файлов..."
sudo docker exec -it $MONGO_CONTAINER_NAME rm -rf /tmp/restore

echo "Восстановление завершено" 