const totest = [ 
  "Exchange is available if needed. DUAL RELEASE 8130-3 EASA'",
  "EXCHANGE $2000 + COSTS, Tagged by: PACIFIC AEROTECH on Feb 26, 2025, Tag Type: 8130/EASA'",
  "Exchange: $2000.00 + cost'",
  "$2000.00 exchange + cost'",
  "$2000.00 exchange + cost'",
  "$2000.00 exchange + cost'",
  "220,000.00 core deposit. FAA Form 8130-3'",
  "ALSO AVAILABLE FOR EXCHANGE $4,000 PLUS COSTS 12 MONTHS WARRANTY STOCK UK. Tagged by: OVERHAUL ACCESSORY on Sep 6, 2024. Tag Type: FRESH 8130/EASA'",
  "$1,000 exchange + cost'",
  "Exchange'",
  "FAA/EASA Dual Release(Exchange)'",
  "FAA/EASA Dual Release(Exchange)'",
  "$4500 Flat rate Exchange with a core value of $2100. No bill backs unless the core is not returned to AeroVision International, AeroVision International is able to core charge if the core is not returned within 30 days of the purchased unit shipping or if the unit is deemed BER by the repair vendor or the repairs exceed 70% of the outright value of the unit. If a core is BER any evaluation fees charged by the shop will be billed back to the customer, separate of the outright/core value. AeroVision International holds the right to charge a late fee of 10% of the outright value if the core is not returned witnin 30 days, and reapply the late fee every 30 days from then on. These late fees are separate to the core value.'",
  "Flat Rate Exchange requiring the return of a like core that requires a standard overhaul. All units come with a fresh, Dual Release 8130-3 dated with the date of invoice.'",
  "Exchange unit, Core Charge: 12,500.00'",
  "Plus 1250.00 core'",
  "STOCK UK QUOTING ALTERNATE ALSO AVAILABLE FOR EXCHANGE $1,000 PLUS COSTS'",
  "DUAL RELEASE EASA+FAA, Tagged by AIR FRANCE on Sep 2, 2024, Core due: Mar 27, 2025, Core charge: $10,000.00'",
  "Stock Uk Core Value - $40 000, DUAL RELEASE EASA / FAA'",
  "FAA/EASA Dual Release(Exchange)'",
  "Exchange is available for $500 + cost, DUAL RELEASE 8130/EASA'",
  "Fresh SETAERO Dual Release with 2 years warranty. Exchange is possible please advise.'",
  "EXCHANGE OPTION AVAILABLE:$650 EXCHANGE PLUS COST'",
  "FLAT RATE EXCHANGE $65K'",
  "EXCHANGE OPTION AVAILABLE:$650 EXCHANGE PLUS COST'",
  "Exchange is available if needed!'",
  "EXCHANGE ONLY, DUAL FAA 8130-3 on Oct 31, 2024'",
  "EXCHANGE ONLY'",
  "Exchange is available if needed.'",
  "3500.00 core, FAA/EASA dual release'",
  "Exchange available at 15%'",
  "01/2025 8130/EASA, EXCHANGE AVAILABLE'",
  "FLAT RATE EXCHANGE $65K'",
  "Fresh SETAERO Dual Release with 2 years warranty. Exchange is possible please advise.'",
  "Thank you for your RFQ, offering in OH condition, Fresh SETAERO Dual Release with 2 years warranty. Ex. works Miami. Exchange is possible please advise.'",
  "Exchange with a $5,000 core'",
  "VSE 8130 9/2024 $30,000 EXCH / $25,000 CORE'",
  "TAG TYPE: 8130-3 / EASA / CAAC, TAGGED BY: HONEYWELL, Exchange + cost and Flat Rate Exchange are available if needed, MOQ=1 unit'",
  "MOQ=1 unit, Trace ID: 2096539, Certificate Type: Stockist Certificate, Tagged By: WENCORE WEST INC, Tag Date: 23 Apr 2008'",
  "MOQ=1 unit, $1850 EXCHANGE + COST'",
  "TAG TYPE: DUAL RELEASE FAA+EASA, TAGGED BY: ILIFF AIRCRAFT REPAIR & SERVICE CO., INC on Jun 12, 2024, MOQ=1 unit, Core due: Mar 22, 2025, Core charge: $18,000.00'",
  "MOQ=1 unit, TAG TYPE: 8130/EASA DUAL, TAGGED BY: TEAM AEROSPACE, ALSO AVAILABLE FOR EXCHANGE $2,000 PLUS COSTS'",
  "TAG TYPE: 8130/EASA DUAL, TAGGED BY: SOUTHWINGS on Nov 1, 2024, ALSO AVAILABLE FOR EXCHANGE $1,500 PLUS COSTS STOCK UK, MOQ=1 unit'",
  "Offering as an exchange only. Core PN must be 442653 and be inspected prior to shipment of exchange. MOQ=1 unit'",
  "TAG TYPE: DUAL RELEASE 8130-3 EASA, TAGGED BY: PRAXIS RESOURCES INC, Exchange is available if needed, MOQ=1 unit'",
  "DUAL RELEASE 8130 EASA, Tagged by: Icon Aerospace on Feb 27, 2023, Part is available for exchange if needed at 15%'",
  "TAGGED BY: VSE AVIATION on Aug 22, 2023; TAG TYPE: FAA/EASA DUAL; OR $250 EXCHANGE + COSTS'",
  "TAG TYPE: 8130/EASA DUAL, TAGGED BY: SOUTHWINGS on Nov 1, 2024, ALSO AVAILABLE FOR EXCHANGE $1,500 PLUS COSTS STOCK UK'",
]

for (let to of totest) {
    // Удаляем фразы, содержащие ключевые слова, включая цифры перед ними
    let newNote = to.replace(/(\s*[,\.]\s*)?([^,\.]*?(\$?\d+[,\.\d]*\s+)?(Fee|Cost|Warranty|Exchange|Core|Core charge|Core cost)[^,\.]*?)(\s*[,\.]\s*|$)/gi, "$5");
    // Удаляем лишние запятые или точки в начале или конце строки
    newNote = newNote.replace(/^[,\.]\s*/, "").replace(/[,\.]\s*$/, "");   
    // Удаляем двойные запятые или точки, если они появились
    newNote = newNote.replace(/[,\.]\s*[,\.]/g, ",");
    // Очищаем строки, которые содержат только знаки пунктуации без букв
    if (!/[a-zA-Z]/.test(newNote)) {
        newNote = "";
    }
    // Удаляем апострофы в конце строки и точки в начале
    newNote = newNote.trim().replace(/^\./, "").replace(/'$/, "").trim();
    console.log(newNote);
}