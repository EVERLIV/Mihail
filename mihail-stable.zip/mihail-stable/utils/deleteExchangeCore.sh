# Захардкоженные параметры MongoDB
MONGODB_URL="mongodb://mongodb:27018/vendorsDB"
MONGO_CONTAINER_NAME="parser-mongodb-1"
MONGO_DB="vendorsDB"

echo "Подключение к MongoDB в контейнере $MONGO_CONTAINER_NAME"
echo "URL: $MONGODB_URL"
echo "Коллекция: pantheon_quotes"

# Создаем регулярное выражение для поиска нужных слов
SEARCH_PATTERN="Fee|Cost|Warranty|Exchange|Core|Core charge|Core cost"

# Сначала выведем записи, которые будут изменены
echo "Записи, которые будут изменены (item_note содержит: '$SEARCH_PATTERN'):"
sudo docker exec -it $MONGO_CONTAINER_NAME mongosh "$MONGODB_URL" --eval 'db.pantheon_quotes.find({item_note: {$regex: "Fee|Cost|Warranty|Exchange|Core|Core charge|Core cost", $options: "i"}}).forEach(printjson)'

# Запрос пользователю на подтверждение изменения
read -p "Вы уверены, что хотите удалить фразы, содержащие указанные слова из поля item_note? (y/n): " confirm
if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]; then
  # Используем регулярное выражение для удаления фраз, содержащих указанные слова
  sudo docker exec -it $MONGO_CONTAINER_NAME mongosh "$MONGODB_URL" --eval '
    db.pantheon_quotes.find({item_note: {$regex: "Fee|Cost|Warranty|Exchange|Core|Core charge|Core cost", $options: "i"}}).forEach(function(doc) {
      // Удаляем фразы, содержащие ключевые слова, включая цифры перед ними
      let newNote = doc.item_note.replace(/(\s*[,\.]\s*)?([^,\.]*?(\$?\d+[,\.\d]*\s+)?(Fee|Cost|Warranty|Exchange|Core|Core charge|Core cost)[^,\.]*?)(\s*[,\.]\s*|$)/gi, "$5");
      
      // Удаляем лишние запятые или точки в начале или конце строки
      newNote = newNote.replace(/^[,\.]\s*/, "").replace(/[,\.]\s*$/, "");
      
      // Удаляем двойные запятые или точки, если они появились
      newNote = newNote.replace(/[,\.]\s*[,\.]/g, ",");
      
      // Очищаем строки, которые содержат только знаки пунктуации без букв
      if (!/[a-zA-Z]/.test(newNote)) {
        newNote = "";
      }
      
      // Удаляем апострофы в конце строки и точки в начале
      newNote = newNote.trim().replace(/^\./, "").replace(/\\'"'"'$/, "").trim();
      
      // Обновляем документ
      db.pantheon_quotes.updateOne(
        { _id: doc._id },
        { $set: { item_note: newNote } }
      );
      
      print("Обновлено: " + doc._id + " - Старое значение: " + doc.item_note + " -> Новое значение: " + newNote);
    })
  '
  echo "Удаление фраз выполнено."
else
  echo "Операция изменения отменена."
fi 