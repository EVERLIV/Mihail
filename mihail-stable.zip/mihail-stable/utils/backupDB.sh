#!/bin/bash

# Загрузка переменных из файла .env
if [ -f ../.env ]; then
  export $(grep -v '^#' ../.env | xargs)
else
  echo "Файл .env не найден"
  exit 1
fi

# Захардкоженные параметры MongoDB
MONGODB_URL="mongodb://mongodb:27018/vendorsDB"
MONGO_CONTAINER_NAME="parser-mongodb-1"
MONGO_DB="vendorsDB"

# Создание директории для резервных копий, если она не существует
BACKUP_DIR="./BACKUP"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_PATH="${BACKUP_DIR}/${MONGO_DB}_${TIMESTAMP}"

mkdir -p $BACKUP_DIR

echo "Создание резервной копии базы данных MongoDB"
echo "Контейнер: $MONGO_CONTAINER_NAME"
echo "База данных: $MONGO_DB"
echo "Путь для сохранения: $BACKUP_PATH"

# Создание резервной копии с помощью mongodump
sudo docker exec -it $MONGO_CONTAINER_NAME mongodump --host mongodb --port 27018 --db $MONGO_DB --out /tmp/backup

# Копирование резервной копии из контейнера в локальную директорию
sudo docker cp $MONGO_CONTAINER_NAME:/tmp/backup/$MONGO_DB $BACKUP_PATH

# Очистка временных файлов в контейнере
sudo docker exec -it $MONGO_CONTAINER_NAME rm -rf /tmp/backup

echo "Резервная копия успешно создана в директории: $BACKUP_PATH"
echo "Содержимое резервной копии:"
ls -la $BACKUP_PATH 