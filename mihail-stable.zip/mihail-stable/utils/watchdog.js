require('dotenv').config({ path: '../.env' });
const { MongoClient } = require('mongodb');
const Docker = require('dockerode');
const util = require('util');
const execPromise = util.promisify(require('child_process').exec);

const mongourl = process.env.MONGODB_URL;
const dbName = process.env.MONGO_DB;
const docker = new Docker();

const MARKETPLACE_CONTAINERS = {
    'stockmarket.aero': 'stockmarket_parser',
    'stockmarket.aero': 'stockmarket_reverse',
    'ILSMART': 'ils_parser',
    'PROPONENT': 'proponent',
    'PARTSBASE': 'partsbase',
    'WENCOR': 'wencor'
};

async function checkLastOrderTime() {
    console.log(`[${new Date().toISOString()}] Checking last order time`);
    const client = new MongoClient(mongourl);
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('orders');

        for (const [marketplace, container] of Object.entries(MARKETPLACE_CONTAINERS)) {
            let query = { marketplace };
            
            // Специальная обработка для stockmarket парсеров
            if (marketplace === 'stockmarket.aero') {
                if (container === 'stockmarket_parser') {
                    // Для основного парсера - нечетные ID
                    query.id = { $regex: /[13579]$/ };
                } else if (container === 'stockmarket_reverse') {
                    // Для reverse парсера - четные ID
                    query.id = { $regex: /[02468]$/ };
                }
            }

            const lastOrder = await collection
                .find(query)
                .sort({ processedAt: -1 })
                .limit(1)
                .toArray();

            if (lastOrder.length > 0) {
                const lastOrderTime = new Date(lastOrder[0].processedAt);
                const now = new Date();
                const diffMinutes = (now - lastOrderTime) / (1000 * 60);

                if (diffMinutes > 60) {
                    console.log(`[${new Date().toISOString()}] Restarting ${container} - last order was ${diffMinutes.toFixed(2)} minutes ago`);
                    try {
                        const dockerContainer = docker.getContainer(container);
                        await dockerContainer.restart();
                        console.log(`[${new Date().toISOString()}] Successfully restarted ${container}`);
                    } catch (error) {
                        console.error(`[${new Date().toISOString()}] Error restarting ${container}:`, error.message);
                    }
                }
            }
        }
    } catch (error) {
        console.error(`[${new Date().toISOString()}] Error checking orders:`, error);
    } finally {
        await client.close();
    }
}

// Запускаем проверку каждые 5 минут
setInterval(checkLastOrderTime, 5 * 60 * 1000);

// Запускаем первую проверку сразу
checkLastOrderTime();
