#!/bin/bash

# Загрузка переменных из файла .env
if [ -f .env ]; then
  export $(grep -v '^#' ../.env | xargs)
else
  echo "Файл .env не найден"
  exit 1
fi

# Захардкоженные параметры MongoDB
MONGODB_URL="mongodb://mongodb:27018/vendorsDB"
MONGO_CONTAINER_NAME="parser-mongodb-1"
MONGO_DB="vendorsDB"

# Формируем запрос MongoDB с использованием JavaScript-синтаксиса
MONGO_QUERY_JS="
  const query = { \$or: [
    { quoteID: null },
    { customer_request_id: null }
  ]};
"

echo "Подключение к MongoDB в контейнере $MONGO_CONTAINER_NAME"
echo "URL: $MONGODB_URL"
echo "Коллекция: pantheon_quotes"

# Сначала выведем записи, которые будут удалены
echo "Записи, которые будут удалены (с quoteID: null или customer_request_id: null):"
sudo docker exec -it $MONGO_CONTAINER_NAME mongosh "$MONGODB_URL" --eval "
$MONGO_QUERY_JS
db.pantheon_quotes.find(query).forEach(printjson);
"

# Запрос пользователю на подтверждение удаления
read -p "Вы уверены, что хотите удалить эти записи? (y/n): " confirm
if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]; then
  # Выполнение запроса на удаление записей
  sudo docker exec -it $MONGO_CONTAINER_NAME mongosh "$MONGODB_URL" --eval "
$MONGO_QUERY_JS
const result = db.pantheon_quotes.deleteMany(query);
print('Удалено записей: ' + result.deletedCount);
"
  echo "Удаление записей выполнено."
else
  echo "Операция удаления отменена."
fi 