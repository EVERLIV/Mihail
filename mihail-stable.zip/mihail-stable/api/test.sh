curl -X GET https://reports.pantheon-mro.com/api/statistics

# С фильтрацией по marketplace:
curl -X GET https://reports.pantheon-mro.com/api/statistics?marketplace=stockmarket.aero


### С фильтрацией по part_number:

curl -X GET https://reports.pantheon-mro.com/api/statistics?part_number=3510-0053-01


### С фильтрацией по vendor_email:

curl -X GET https://reports.pantheon-mro.com/api/statistics?vendor_email=sales@uaminc.com


### С пагинацией:

curl -X GET https://reports.pantheon-mro.com/api/statistics?limit=10\&skip=0


### Базовый запрос:

curl -X GET https://reports.pantheon-mro.com/api/vendors


### С фильтрацией по email:

curl -X GET https://reports.pantheon-mro.com/api/vendors?email=sales@uaminc.com


### С пагинацией:

curl -X GET "https://reports.pantheon-mro.com/api/vendors?limit=10&skip=0"


### Добавление статистики:
curl -X POST https://reports.pantheon-mro.com/api/statistics \
  -H "Content-Type: application/json" \
  \
  -d '{
    "marketplace": "partsbase.com",
    "part_number": "3510-0053-01",
    "vendor_email": "sales@uaminc.com",
    "order_id": 53693  
  }'

#### order_idinteger


https://reports.pantheon-mro.com/api/
pantheon
cn394c8ha9hdR#