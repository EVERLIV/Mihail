require('dotenv').config();
require('dotenv').config({ path: '../.env' });
const logger = require('./logger');

const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const bodyParser = require('body-parser');
//const { Client } = require('pg');
const Imap = require('imap');
const { simpleParser } = require('mailparser');

const app = express();
const port = process.env.API_PORT || 3000;

// Выбираем URL в зависимости от окружения
const mongourl = process.env.MONGODB_URL || 'mongodb://localhost:27018';
const dbName = process.env.MONGO_DB || 'vendorsDB';
const apiUrl = process.env.PANTHEON_API_URL
const suppliersUrl = process.env.GETSUPPLIERSURL
const postQuoteUrl = process.env.POSTQUOTEURL
const findOrdersUrl = process.env.FINDORDERSURL

logger.info('apiUrl: ' + apiUrl + postQuoteUrl);

// Конфигурация IMAP из переменных окружения
const imapConfig = {
  user: process.env.EMAIL_USER,
  password: process.env.EMAIL_PASSWORD,
  user1: process.env.EMAIL_USER1,
  password1: process.env.EMAIL_PASSWORD1,
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT || 993,
  tls: true,
  tlsOptions: { rejectUnauthorized: false }
};
// Подключаемся к почтовому ящику

// Middleware
app.use(bodyParser.json());

// Создаем подключение к MongoDB
let client;
let db;

// В начале файла объявляем переменную для leven
let leven;
// В асинхронной функции инициализируем leven
async function initializeLeven() {
  leven = await import('leven');
}

// Вызываем инициализацию
initializeLeven().catch(logger.error);

async function connectToDatabase() {
  try {
    client = await MongoClient.connect(mongourl);
    db = client.db(dbName);
    logger.info('Успешное подключение к MongoDB');
  } catch (error) {
    logger.error('Ошибка подключения к MongoDB:' + error);
    process.exit(1);
  }
}

// GET /statistics - получение статистики
app.get('/statistics', async (req, res) => {
  try {
    const statsCollection = db.collection('statistics');
    const query = {};

    // Обработка параметров запроса
    if (req.query.vendor) query.vendor = req.query.vendor;
    if (req.query.part_number) query.part_number = req.query.part_number;
    if (req.query.vendor_email) query.vendor_email = req.query.vendor_email;

    // Пагинация
    const limit = parseInt(req.query.limit) || 100;
    const skip = parseInt(req.query.skip) || 0;

    const statistics = await statsCollection.find(query)
      .sort({ created_at: -1 })
      .skip(skip)
      .limit(limit)
      .toArray();

    const total = await statsCollection.countDocuments(query);

    res.json({
      data: statistics,
      meta: {
        total,
        limit,
        skip
      }
    });
  } catch (error) {
    logger.error('Ошибка при получении статистики:' + error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера' });
  }
});

// GET /vendors - получение списка вендоров
app.get('/vendors', async (req, res) => {
  try {
    const vendorsCollection = db.collection('vendors');
    const query = {};

    // Обработка параметров запроса
    if (req.query.email) query.EmailAddress = req.query.email;

    // Пагинация
    const limit = parseInt(req.query.limit) || 100;
    const skip = parseInt(req.query.skip) || 0;

    const vendors = await vendorsCollection.find(query)
      .skip(skip)
      .limit(limit)
      .toArray();

    const total = await vendorsCollection.countDocuments(query);

    res.json({
      data: vendors,
      meta: {
        total,
        limit,
        skip
      }
    });
  } catch (error) {
    logger.error('Ошибка при получении вендоров:' + error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера' });
  }
});


// POST /statistics - добавление новой статистики
app.post('/statistics', async (req, res) => {
  try {
    const { marketplace, part_number, vendor_email, order_id } = req.body;

    if (!marketplace || !part_number || !vendor_email || !order_id) {
      return res.status(400).json({
        error: 'Необходимо указать marketplace, part_number, vendor_email и order_id'
      });
    }

    const statsCollection = db.collection('statistics');

    const result = await statsCollection.insertOne({
      marketplace,
      part_number,
      vendor_email,
      order_id,
      timestamp: req.body.timestamp || new Date().toISOString(),
      created_at: new Date()
    });

    res.status(201).json({
      success: true,
      id: result.insertedId,
      message: 'Статистика успешно добавлена'
    });
  } catch (error) {
    logger.error('Ошибка при добавлении статистики:' + error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера' });
  }
});

// POST /send-to-pantheon/:part_number - отправка предложения в Pantheon
app.post('/send-to-pantheon/:quoteId', async (req, res) => {
  try {
    let quoteMongoId = req.params.quoteId === '0' ? null : req.params.quoteId;
    let quoteBody = req.body;


    logger.info('---------------------------quoteBody--------------------------------------')
    logger.info(quoteBody);
    logger.info('quoteId' + quoteMongoId);

    if (!quoteMongoId && Object.keys(quoteBody).length === 0) {
      return res.status(400).json({ ok: false, error: 'Не указан ID предложения и нет тела запроса' });
    }

    const quotesCollection = db.collection('pantheon_quotes');
    let quote;
    if (quoteMongoId) {
      quote = await quotesCollection.findOne({ _id: new ObjectId(quoteMongoId) });
      logger.info('mongo quote\n' + JSON.stringify(quote));
    } else {
      quote = quoteBody;
    }

    if (!quote) {
      return res.status(404).json({ error: 'Предложение не найдено' });
    }

    if (quote.stk_qty && quote.stk_qty > quote.qty) {
      quote.qty = quote.stk_qty;
    }

    // Поиск заказов в Pantheon
    let quotas = [];
    let pantheonResults = [];
    try {

      // Если в part_number есть : или ( то чистим
      if (quote.part_number.includes(':') || quote.part_number.includes('(')) {
        let partNumber = '';
        let description = '';
        let parts = [];

        if (quote.part_number.includes(':')) {
          parts = quote.part_number?.split(':').map(p => p.trim());
        }
        if (quote.part_number.includes('(')) {
          parts = quote.part_number?.split('(').map(p => p.trim());
        }
        partNumber = parts[0];
        description = parts[1].replace(')', '');

        // Проверяем формат номера детали
        // Номер детали может быть чисто цифровым или содержать буквы и цифры, может включать - или /
        if (partNumber && partNumber.match(/^[0-9]+$/) || partNumber.match(/^[A-Za-z0-9]+[-/]?[A-Za-z0-9]+$/)) {
          // Оставляем как есть
        } else if (description && (description.match(/^[0-9]+$/) || description.match(/^[A-Za-z0-9]+[-/]?[A-Za-z0-9]+$/))) {
          // Если описание похоже на номер детали, используем его
          partNumber = description;
        }

        quote.part_number = partNumber;
      }
      //quote.part_number = quote.part_number?.replace('/', '').trim()  
      logger.info('Поиск заказов в Pantheon: ' + apiUrl + findOrdersUrl + '?part_number=' + quote.part_number?.replace(/\([^)]*\)/g, '').trim());
      let partNumberVariants = [quote.part_number?.replace(/\([^)]*\)/g, '').trim()]
      partNumberVariants.push(quote.part_number?.replace(/\([^)]*\)/g, '').replace(/-/g, '').replace(/\//g, '').trim())
      partNumberVariants.push(quote.part_number?.replace(/\([^)]*\)/g, '').replace(/\//g, '').trim())

      logger.info(partNumberVariants.join(', '));

      let searchResponse;
      let responseResults = [];
      for (let partNumber of partNumberVariants) {
        searchResponse = await fetch(apiUrl + findOrdersUrl + '?part_number=' + partNumber, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': process.env.API_AUTH_TOKEN
          }
        }).then(res => res.json());

        if (searchResponse.ok && searchResponse.data && Array.isArray(searchResponse.data)) {
          let recentOrders = filterOrders(searchResponse.data);

          responseResults = [...responseResults, ...recentOrders];
        }
        logger.info('Order search results:\n');
        logger.info(JSON.stringify(responseResults, null, 2));
      }

      if (responseResults?.length) {
        // Удаляем дубликаты
        responseResults = [...new Set(responseResults.map(item => JSON.stringify(item)))].map(item => JSON.parse(item));
        logger.info(`Отфильтровано ${responseResults.length} заказов за последние 30 дней`);

        if (responseResults?.length > 0) {

          for (let order of responseResults) {
            logger.info('найденный заказ\n' + JSON.stringify(order));
            const quoteForOrder = { ...quote };
            quoteForOrder.customer_request_id = order.id;
            quoteForOrder.quote_id = order.quote_id;
            
            // Если номер детали в заказе отличается от оригинального, добавляем его в примечания
            if (quoteForOrder.part_number !== order.part_number) {
              quoteForOrder.item_note = (quoteForOrder.item_note || '') + ' | Original part number: ' + order.part_number;
            }

            // если MOQ больше количества, то пропускаем
            if (quoteForOrder.moq && quoteForOrder.moq > quoteForOrder.qty) {
              logger.info('мок больше количества' + quoteForOrder.moq + ' ' + quoteForOrder.qty + 'пропускаем');
              pantheonResults.push({
                customer_request_id: order.id,
                quote_id: order.quote_id,
                result: {
                  ok: true,
                  message: `Мок больше количества (${quoteForOrder.moq} > ${quoteForOrder.qty}) - предложение пропущено`
                }
              });
              continue;
            }

            // если количество не было указано значит априори достаточно
            if (quoteForOrder.qty === 0) {
              quoteForOrder.qty = order.qty;
            }

            if (order.qty > quoteForOrder.qty) {
              logger.info('количество заказа больше количества в предложении' + order.qty + ' ' + quoteForOrder.qty + 'пропускаем');
              pantheonResults.push({
                customer_request_id: order.id,
                quote_id: order.quote_id,
                result: {
                  ok: true,
                  message: `Количество в заказе (${order.qty}) больше количества в предложении (${quoteForOrder.qty} - предложение пропущено)`
                }
              });
              continue;
            } else {
              quoteForOrder.qty = order.qty;
            }

            if (quoteForOrder.lead_time > 30) {
              logger.info('срок поставки больше 30 дней' + quoteForOrder.lead_time + 'пропускаем');
              pantheonResults.push({
                customer_request_id: order.id,
                quote_id: order.quote_id,
                result: {
                  ok: true,
                  message: `Срок поставки больше 30 дней (${quoteForOrder.lead_time} > 30) - предложение пропущено`
                }
              });
              continue;
            }

            if (quoteForOrder.lead_time > 4 && quoteForOrder.time_unit === 'W') {
              logger.info('срок поставки больше 4 недель' + quoteForOrder.lead_time + 'пропускаем');
              pantheonResults.push({
                customer_request_id: order.id,
                quote_id: order.quote_id,
                result: {
                  ok: true,
                  message: `Срок поставки больше 4 недель (${quoteForOrder.lead_time} > 4) - предложение пропущено`
                }
              });
              continue;
            }
            quotas.push(quoteForOrder);
          }
        } else {
          // Если нет заказов за 30 дней, отправляем одно предложение без привязки
          quotas.push(quote);
        }
      } else {
        // Если нет заказов вообще, отправляем одно предложение без привязки
        logger.info('нет заказов вообще, отправляем одно предложение без привязки');
        quotas.push(quote);
      }


      // Отправка каждого предложения

      for (let quoteItem of quotas) {
        const pantheonData = await cleanUp(quoteItem);
        if (!quoteItem._id) {

          let sameMessageId = await quotesCollection.findOne({ message_id: quoteItem.message_id });
          if (sameMessageId) {
            logger.info('Предложение с таким message_id уже существует, пропускаем');
            quoteMongoId = sameMessageId._id; // Добавляем _id в объект quote
            logger.info('Предложение с таким message_id уже существует, пропускаем');
          } else {

            const result = await quotesCollection.insertOne({
              ...pantheonData,
              from: quoteItem.from,
              received_at: quoteItem.received_at,
              sent_to_pantheon: false
            });
            quoteMongoId = result.insertedId; // Добавляем _id в объект quote
            logger.info('Inserted quote with ID:');
            logger.info(JSON.stringify(pantheonData, null, 2));

          }

        }

        let dataToSend = { ...pantheonData };
        delete dataToSend.message_id;
        logger.info('Sending to Pantheon:\n');
        logger.info(JSON.stringify(dataToSend, null, 2));

        const pantheonResult = await sendToPantheon(dataToSend);



        await quotesCollection.updateOne(
          { message_id: quoteItem.message_id },
          {
            $set: {
              ...pantheonData,
              from: quoteItem.from,
              received_at: quoteItem.received_at,
              sent_to_pantheon: pantheonResult.ok,
              pantheon_sent_at: new Date(),
              pantheon_results: pantheonResult
            }
          },
          { upsert: true }
        );

        pantheonResults.push({
          customer_request_id: quoteItem.customer_request_id,
          quote_id: quoteItem.quote_id,
          result: pantheonResult
        });
      }

      // Обновление статуса в базе данных, если есть part_number
      // const success = pantheonResults.some(result => result.result.ok);
      // if (quoteMongoId) {

      //} 

      // Формируем ответ
      logger.info('pantheonResults:');
      logger.info(JSON.stringify(pantheonResults, null, 2));

      const overallSuccess = pantheonResults.some(result => result.result.ok);
      res.json({
        ok: overallSuccess,
        success: overallSuccess,
        message: overallSuccess ?
          'Предложения успешно отправлены в Pantheon' :
          'Ошибка при отправке предложений в Pantheon',
        results: JSON.stringify(pantheonResults)
      });

    } catch (error) {
      logger.error('Ошибка при отправке предложений в Pantheon:', error);
      res.status(500).json({
        ok: false,
        error: 'Внутренняя ошибка сервера',
        message: error.message
      });
    }
  } catch (error) {
    logger.error('Ошибка при обработке запроса:', error);
    res.status(500).json({
      ok: false,
      error: 'Внутренняя ошибка сервера',
      message: error.message
    });
  }

  function filterOrders(responseResults) {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    let recentOrders = responseResults.filter(order => {
      const orderDate = order.request_date ? new Date(order.request_date) : null;
      return orderDate && orderDate >= thirtyDaysAgo;
    });

    recentOrders = recentOrders.filter(order => order.quote_id)
      .sort((a, b) => new Date(b.request_date) - new Date(a.request_date));
    return recentOrders;
  }
});

async function sendToPantheon(dataToSend) {

  let pantheonResult;
  const pantheonResponse = await fetch(apiUrl + postQuoteUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': process.env.API_AUTH_TOKEN
    },
    body: JSON.stringify(dataToSend)
  });

  pantheonResult = await pantheonResponse.json();

  if (pantheonResult.error === 'duplicate_proposals') {
    pantheonResult.ok = true;
  }
  logger.info('pantheonResult:');
  logger.info(JSON.stringify(pantheonResult, null, 2));


  if (!pantheonResult.ok) {

    if (pantheonResult.message[0].msg === 'Value error, No this part number in database') {
      if (dataToSend.part_number.includes('-')) {
        dataToSend.part_number = dataToSend.part_number.replace(/-/g, '/')
      }
      else if (dataToSend.part_number.includes('/')) {
        dataToSend.part_number = dataToSend.part_number.replace(/\//g, '-');
      }
      logger.info('Отправляем предложение с новым part_number', dataToSend.part_number);


      const pantheonResponse = await fetch(apiUrl + postQuoteUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': process.env.API_AUTH_TOKEN
        },
        body: JSON.stringify(dataToSend)
      });

      pantheonResult = await pantheonResponse.json();
      if (pantheonResult.error === 'duplicate_proposals') {
        pantheonResult.ok = true;
      }
      logger.info('pantheonResult');
      logger.info(JSON.stringify(pantheonResult, null, 2));


      if (pantheonResult.message[0].msg === 'Value error, No this part number in database') {
        dataToSend.part_number = dataToSend.part_number.replace(/[-/]/g, '');
        logger.info('Отправляем предложение с новым part_number', dataToSend.part_number);


        const pantheonResponse = await fetch(apiUrl + postQuoteUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': process.env.API_AUTH_TOKEN
          },
          body: JSON.stringify(dataToSend)
        });

        pantheonResult = await pantheonResponse.json();
        if (pantheonResult.error === 'duplicate_proposals') {
          pantheonResult.ok = true;
        }
        logger.info('pantheonResult');
        logger.info(JSON.stringify(pantheonResult, null, 2));
      }
    }
  }


  return pantheonResult;
}

// Вспомогательная функция для подготовки данных
async function cleanUp(quote) {

  // Поиск информации о поставщике
  let emailDomain = '';
  let supplierName = '';

  if (quote.from) {
    if (quote.from.includes('app.partsrfq.com')) {
      emailDomain = quote.from?.split('@')[0]?.toLowerCase();
    } else if (quote.from.includes('@')) {
      emailDomain = quote.from?.split('@')[1]?.toLowerCase()
    } else {
      emailDomain = quote.from?.split(' ')[0]?.toLowerCase();
    }

    supplierName = quote.supplier?.toUpperCase().trim();

    const mainDomain = emailDomain?.split('.').slice(-2).join('.')
      || emailDomain;
    logger.info('Ищем вендора с таким же доменом и именем в базе -', mainDomain, supplierName);

    const response = await fetch(apiUrl + suppliersUrl + '?email=' + mainDomain, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': process.env.API_AUTH_TOKEN
      }
    }).then(res => res.json());

    if (response.ok && response.suppliers?.length) {
      let supplier = response.suppliers[0];
      logger.info('Найден поставщик -' + supplier.name + ' ' + supplier.country);
      if (supplier.name) {
        quote.supplier = supplier.name;
      }

      if (supplier.country) {
        quote.delivery_place = quote.delivery_place ? quote.delivery_place : supplier.country;
      }
    }
  }

  if (!quote.delivery_place && quote.supplier) {
    logger.info('Поставщик не найден в базе по домену', 'ищем по имени');
    const resp = await fetch(apiUrl + suppliersUrl + '?email='
      +
      quote.supplier.replace(/[\s.,\/#!$%\^&\*;:{}=\-_`~()]/g, '').substring(0, 10),
      {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': process.env.API_AUTH_TOKEN
        }
      }).then(res => res.json());

    if (resp.ok && resp.suppliers?.length) {
      for (let supplier of resp.suppliers) {
        const distance = leven.default(supplier.name.toLowerCase(), quote.supplier.toLowerCase());
        logger.info('сравниваем поставщиков -', supplier.name, quote.supplier, 'расстояние -', distance);
        if (distance < 3) {
          logger.info('поставщик найден -', supplier.name, supplier.country);
          if (supplier.name) {
            quote.supplier = supplier.name;
          }
          if (supplier.country) {
            quote.delivery_place = quote.delivery_place ? quote.delivery_place : supplier.country;
          }
        }
      }

    }

  }

  if (quote.certificates && quote.certificates.length > 0 && !quote.cert_file_name) {
    quote.cert_file_name = quote.certificates[0];
  }


  quote.delivery_place = quote.delivery_place?.toUpperCase().includes('UNITED STATES') ?
    'USA' : quote.delivery_place;
  quote.delivery_condition = quote.delivery_condition === 'FOB' ? 'EXW' : quote.delivery_condition;
  quote.item_note = quote.item_note
    .replace(/https?:[^\s]+/g, '')
    .replace(/Contact us[^|]*/gi, '')
    .replace(/NOTE TO BUYER[^|]*/gi, '')
    .replace(/SEND YOUR PO TO[^|]*/gi, '')
    .replace(/Any orders below[^|]*/gi, '')
    .replace(/Min PO[^.,;]*/gi, '')
    .replace(/Afterhours AOG Fee[^,;]*/gi, '')
    .replace(/\d+\s*Days,/gi, '')
    .replace(/\d+\s*-day Warranty,/gi, '')
    .replace(/N\|A\s*PLEASE/gi, '')
    .replace(/\$\d+\.?\d*/gi, '')
    .replace(/\d+\s*YR/gi, '')
    .replace(/\d+\s*months/gi, '')
    .replace(/\d+\s*month/gi, '')
    .replace(/\d+\s*year/gi, '')
    .replace(/\d+\s*years/gi, '')
    .replace(/WE HAVE A[^]*/gi, '')
    .replace(/AND MIN LINE[^]*/gi, '')
    .replace(/PLEASE[^]*/gi, '')
    .replace(/LET ME KNOW[^]*/gi, '')
    .replace(/DO NOT HESITATE[^]*/gi, '')
    .replace(/SEND EMAIL FOR STOCK AVAILABILITY AND PRICE TO[^]*/gi, '')
    .replace(/Mitchell[^.]*/gi, '')
    .replace(/All orders are subject[^.]*/gi, '')
    .replace(/ALL QUOTATIONS[^]*/gi, '')
    .replace(/Same day[^]*/gi, '')
    .replace(/Items available from stock[^]*/gi, '')
    .replace(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/gi, '')
    .replace(/Trace[^.,;]*/gi, '')
    .replace(/MOV[^.,;]*/gi, '')
    .replace(/MLV[^.,;]*/gi, '')
    .replace(/Ships same day[^.,;]*/gi, '')
    .replace(/All stock in[^.,;]*/gi, '')
    .replace(/Will sell at[^.,;]*/gi, '')
    .replace(/100% life qty[^.,;]*/gi, '')
    .replace(/Link for[^.,;]*/gi, '')
    .replace(/Terms:[^.,;]*/gi, '')
    .replace(/Note to Buyer:[^]*/gi, '')
    .replace(/UNLESS OTHERWISE[^]*/gi, '')
    .replace(/End-user Form[^.,;]*/gi, '')
    .replace(/Cost[^.,;]*/gi, '')
    .replace(/Hazmat[^.,;]*/gi, '')
    .replace(/PROCESSING[^.,;]*/gi, '')
    .replace(/HANDLING[^.,;]*/gi, '')
    .replace(/MINIMUM[^.,;]*/gi, '')
    .replace(/MIN ORDER[^.,;]*/gi, '')
    .replace(/PACKAGE[^.,;]*/gi, '')
    .replace(/FREIGHT[^.,;]*/gi, '')
    .replace(/SHIPPING[^.,;]*/gi, '')
    .replace(/Handling[^.,;]*/gi, '')
    .replace(/Processing[^.,;]*/gi, '')
    .replace(/Warranty[^.,;]*/gi, '')
    .replace(/WRNTY[^.,;]*/gi, '')
    .replace(/Proponent\s+C\s+of\s+C/gi, '')
    .replace(/Proponent CofC/gi, '')
    .replace(/Proponent[^.,;]*/gi, '')
    .replace(/TESTED \/ INSPECTED ITEMS HAVE 30 DAY/g, '')
    .replace(/parts in stock ready for immediate shipment/g, '')
    .replace(/READY TO GO!!!/g, '')
    .replace(/MOQ=1 unit/gi, '')
    .replace(/Min\.?\s*PO\s*(?:US)?\$?\d+\.?\d*\s*/gi, '')
    .replace(/MIN PO\s*:?\s*\$?\d+\$?,?\s*/gi, '')
    .replace(/MIN. PO\s*:?\s*\$?\d+\$?,?\s*/gi, '')
    .replace(/Min. PO\s*:?\s*\$?\d+\$?,?\s*/gi, '')
    .replace(/Afterhours AOG Fee\s*:?\s*\$?\d+\$?,?\s*/gi, '')
    .replace(/MIN ORDER\s*\$\d+,\s*/gi, '')
    .replace(/DAR Fee\s*:?\s*\$?\d+\$?,?\s*/gi, '')
    .replace(/\$?\d+\.?\d*\s*USD\s*PO\s*/gi, '')
    .replace(/Contact your[^|]*/gi, '')
    .replace(/\(no charge[^)]*\)/gi, '')
    .replace(/\$\s?\d+\.?(?:USD)?/g, '')
    .replace(/\s*\.00\s*/g, '')
    .replace(/^[)(.,;:!?\s]+/g, '')
    .replace(/,,\s*/g, '')
    .replace(/[<>/\\]/g, '|')
    .slice(0, 250)
  // удаляем знаки пунктуации в начале

  quote.um = quote.um === 'GR' ? 'G' : quote.um
  quote.um = quote.um === 'RL' ? 'RO' : quote.um
  quote.um = quote.um === 'LT' ? 'L' : quote.um
  if (!["EA", "FT", "M", "YD", "KG", "LB", "G", "L", "OZ", "RO", "KT", "CA"].includes(quote.um)) {
    quote.um = 'EA';
  }

  logger.info('quote cleaned up: ' + quote.item_note);

  // Разделяем строку по двоеточию и проверяем формат


  return {
    part_number: quote.part_number,
    qty: Math.ceil(quote.qty),
    delivery_place: quote.delivery_place?.substring(0, 10),
    delivery_condition: quote.delivery_condition || 'EXW',
    item_note: quote.item_note + (quote.stk_qty > 0 ? (' | Avl. ' + quote.stk_qty) : '') || '',
    customer_request_id: quote.customer_request_id,
    price: Math.ceil(quote.price),
    supplier: quote.supplier?.toUpperCase().trim(),
    quote_id: quote.quote_id,
    date: quote.date,
    valid_to: quote.valid_to,
    condition: quote.condition?.substring(0, 2) || 'NE',
    lead_time: quote.lead_time || 1,
    time_unit: quote.time_unit || 'D',
    currency: quote.currency,
    is_moq: quote.is_moq || false,
    um: quote.um || 'EA',
    email_subject: quote.email_subject || '',
    message_id: quote.message_id || '',
    cert_file_name: quote.cert_file_name || ''
  };
}

// POST /email - получение содержимого письма по Message-ID
// POST /email - получение содержимого письма по Message-ID
app.post('/email', async (req, res) => {
  try {
    const { messageId } = req.body;

    if (!messageId) {
      return res.status(400).json({ error: 'Не указан Message-ID письма' });
    } else {
      logger.info('Загружаем письмо с Message-ID -' + messageId);
    }

    // Пробуем найти письмо в разных папках и почтовых ящиках
    try {
      // Сначала ищем в основном ящике в папке INBOX.PROCESSED
      const email = await findEmailInMailbox(messageId, imapConfig.user, imapConfig.password, 'INBOX.PROCESSED');
      res.json(formatEmailResponse(email));
      return;
    } catch (error) {
      logger.info(`Письмо не найдено в INBOX.PROCESSED: ${error.message}`);

      try {
        // Затем ищем в основном ящике в папке INBOX.MANUAL
        const email = await findEmailInMailbox(messageId, imapConfig.user, imapConfig.password, 'INBOX.MANUAL');
        res.json(formatEmailResponse(email));
        return;
      } catch (error) {
        logger.info(`Письмо не найдено в INBOX.MANUAL: ${error.message}`);

        try {
          // Затем ищем во втором ящике в папке INBOX.PROCESSED
          const email = await findEmailInMailbox(messageId, imapConfig.user1, imapConfig.password1, 'INBOX.PROCESSED');
          res.json(formatEmailResponse(email));
          return;
        } catch (error) {
          logger.info(`Письмо не найдено во втором ящике в INBOX.PROCESSED: ${error.message}`);

          try {
            // Наконец, ищем во втором ящике в папке INBOX.MANUAL
            const email = await findEmailInMailbox(messageId, imapConfig.user1, imapConfig.password1, 'INBOX.MANUAL');
            res.json(formatEmailResponse(email));
            return;
          } catch (error) {
            logger.info(`Письмо не найдено во втором ящике в INBOX.MANUAL: ${error.message}`);
            throw new Error(`Письмо с Message-ID ${messageId} не найдено ни в одном из почтовых ящиков`);
          }
        }
      }
    }
  } catch (error) {
    logger.error('Ошибка при получении письма:' + error);
    res.status(500).json({ error: `Внутренняя ошибка сервера при получении письма: ${error.message}` });
  }
});

// Функция для поиска письма в указанном почтовом ящике и папке
async function findEmailInMailbox(messageId, user, password, mailbox) {
  logger.info(`Ищем письмо в ящике ${user}, папка ${mailbox}`);

  const currentImapConfig = {
    ...imapConfig,
    user: user,
    password: password
  };

  const imap = new Imap(currentImapConfig);

  return new Promise((resolve, reject) => {
    let isResolved = false;

    // Устанавливаем таймаут в 30 секунд
    const timeout = setTimeout(() => {
      if (!isResolved) {
        imap.end();
        reject(new Error(`Таймаут при загрузке письма из ${mailbox}`));
      }
    }, 30000);

    imap.once('ready', () => {
      imap.openBox(mailbox, false, (err, box) => {
        if (err) {
          clearTimeout(timeout);
          imap.end();
          return reject(err);
        }

        logger.info(`Ищем письмо с Message-ID ${messageId} в ${mailbox}`);
        // Ищем письмо по Message-ID
        imap.search([['HEADER', 'Message-ID', messageId]], (err, results) => {
          if (err) {
            clearTimeout(timeout);
            imap.end();
            return reject(err);
          }

          logger.info(results);

          if (!results || results.length === 0) {
            clearTimeout(timeout);
            imap.end();
            return reject(new Error(`Письмо с Message-ID ${messageId} не найдено в ${mailbox}`));
          }

          // Получаем первое найденное письмо
          const fetch = imap.fetch(results, {
            bodies: '',
            markSeen: false
          });

          let messageFound = false;

          fetch.on('message', (msg) => {
            messageFound = true;
            const chunks = [];

            msg.on('body', (stream) => {
              // Более надежный способ обработки потока - собирать бинарные фрагменты
              stream.on('data', (chunk) => {
                chunks.push(chunk);
              });

              stream.on('end', () => {
                // Объединяем все фрагменты в единый буфер
                const buffer = Buffer.concat(chunks);

                simpleParser(buffer)
                  .then(parsed => {
                    clearTimeout(timeout);
                    isResolved = true;
                    resolve(parsed);
                  })
                  .catch(err => {
                    clearTimeout(timeout);
                    isResolved = true;
                    reject(err);
                  });
              });
            });

            msg.on('error', (err) => {
              clearTimeout(timeout);
              isResolved = true;
              reject(err);
            });
          });

          fetch.on('error', (err) => {
            clearTimeout(timeout);
            isResolved = true;
            reject(err);
          });

          fetch.on('end', () => {
            // Проверяем, найдено ли письмо
            if (!messageFound) {
              clearTimeout(timeout);
              isResolved = true;
              reject(new Error(`Письмо с Message-ID ${messageId} не найдено в ${mailbox}`));
            }
            imap.end();
          });
        });
      });
    });

    imap.once('error', (err) => {
      clearTimeout(timeout);
      isResolved = true;
      reject(err);
    });

    imap.connect();
  });
}

// Функция для форматирования ответа с данными письма
function formatEmailResponse(email) {
  return {
    from: email.from?.value?.[0]?.address || '',
    to: email.to?.value?.map(to => to.address) || [],
    subject: email.subject || '',
    text: email.text || '',
    html: email.html || '',
    date: email.date || new Date(),
    attachments: email.attachments?.map(attachment => ({
      filename: attachment.filename,
      contentType: attachment.contentType,
      size: attachment.size,
      contentId: attachment.contentId
    })) || []
  };
}



// GET /attachment - получение вложения из письма
app.get('/attachment', async (req, res) => {
  try {
    logger.info(req.query)
    const { messageId, contentId, filename, view } = req.query;

    if (!messageId || (!contentId && !filename)) {
      return res.status(400).json({ error: 'Не указаны необходимые параметры' });
    }

    logger.info('Загружаем вложение из письма с Message-ID -' + messageId);
    logger.info('ContentID:' + contentId + 'Filename:' + filename);

    const imap = new Imap(imapConfig);

    // Промис для работы с IMAP с таймаутом
    const attachmentPromise = new Promise((resolve, reject) => {
      let isResolved = false;

      // Устанавливаем таймаут в 30 секунд
      const timeout = setTimeout(() => {
        if (!isResolved) {
          imap.end();
          reject(new Error('Таймаут при загрузке вложения'));
        }
      }, 30000);

      imap.once('ready', () => {
        imap.openBox('INBOX.PROCESSED', false, (err, box) => {
          if (err) {
            clearTimeout(timeout);
            imap.end();
            return reject(err);
          }

          logger.info('Ищем письмо с Message-ID -' + messageId);
          // Ищем письмо по Message-ID
          imap.search([['HEADER', 'Message-ID', messageId]], (err, results) => {
            if (err) {
              clearTimeout(timeout);
              imap.end();
              return reject(err);
            }

            if (!results || results.length === 0) {
              clearTimeout(timeout);
              imap.end();
              return reject(new Error(`Письмо с Message-ID ${messageId} не найдено`));
            }

            // Получаем первое найденное письмо
            const fetch = imap.fetch(results, {
              bodies: '',
              markSeen: false
            });

            let messageFound = false;

            fetch.on('message', (msg) => {
              messageFound = true;
              const chunks = [];

              msg.on('body', (stream) => {
                stream.on('data', (chunk) => {
                  chunks.push(chunk);
                });

                stream.on('end', () => {
                  // Объединяем все фрагменты в единый буфер
                  const buffer = Buffer.concat(chunks);

                  simpleParser(buffer)
                    .then(parsed => {
                      // Ищем нужное вложение
                      let attachment = null;

                      if (contentId) {
                        // Ищем по contentId
                        attachment = parsed.attachments.find(att =>
                          att.contentId === contentId ||
                          att.contentId === `<${contentId}>` ||
                          `<${att.contentId}>` === contentId
                        );
                      }

                      // Если не нашли по contentId или он не был указан, ищем по имени файла
                      if (!attachment && filename) {
                        attachment = parsed.attachments.find(att => att.filename === filename);
                      }

                      if (!attachment) {
                        clearTimeout(timeout);
                        isResolved = true;
                        reject(new Error(`Вложение не найдено в письме`));
                        return;
                      }

                      clearTimeout(timeout);
                      isResolved = true;
                      resolve({
                        content: attachment.content,
                        contentType: attachment.contentType,
                        filename: attachment.filename
                      });
                    })
                    .catch(err => {
                      clearTimeout(timeout);
                      isResolved = true;
                      reject(err);
                    });
                });
              });

              msg.on('error', (err) => {
                clearTimeout(timeout);
                isResolved = true;
                reject(err);
              });
            });

            fetch.on('error', (err) => {
              clearTimeout(timeout);
              isResolved = true;
              reject(err);
            });

            fetch.on('end', () => {
              // Проверяем, найдено ли письмо
              if (!messageFound) {
                clearTimeout(timeout);
                isResolved = true;
                reject(new Error(`Письмо с Message-ID ${messageId} не найдено в INBOX.PROCESSED`));
              }
              imap.end();
            });
          });
        });
      });

      imap.once('error', (err) => {
        clearTimeout(timeout);
        isResolved = true;
        reject(err);
      });

      imap.connect();
    });

    // Ожидаем получение вложения
    const attachment = await attachmentPromise;

    // Устанавливаем заголовки для скачивания или просмотра
    res.setHeader('Content-Type', attachment.contentType);

    // Если запрошен просмотр и это PDF, устанавливаем заголовок для отображения в браузере
    if (view === 'true' && attachment.contentType.includes('pdf')) {
      res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(attachment.filename)}"`);
    } else {
      res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(attachment.filename)}"`);
    }

    // Отправляем содержимое вложения
    res.send(attachment.content);

  } catch (error) {
    logger.error('Ошибка при получении вложения:' + error);
    res.status(500).json({ error: `Внутренняя ошибка сервера при получении вложения: ${error.message}` });
  }
});

// Запуск сервера
async function startServer() {
  await connectToDatabase();

  app.listen(port, () => {
    logger.info(`API сервер запущен на порту ${port}`);
  });

  // Обработка завершения работы
  process.on('SIGINT', async () => {
    if (client) {
      await client.close();
      logger.info('Соединение с MongoDB закрыто');
    }
    process.exit(0);
  });
}

startServer().catch(logger.error); 
