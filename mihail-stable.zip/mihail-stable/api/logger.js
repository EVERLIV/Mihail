const winston = require('winston');
const fs = require('fs');
const path = require('path');



// Функция для форматирования сообщения и метаданных
const formatMessage = ({ timestamp, level, message, ...meta }) => {
  // Преобразуем сообщение, если это объект с числовыми ключами

  // Форматируем сообщение
  const formattedMessage = typeof message === 'object' 
    ? JSON.stringify(message, null, 2)
    : message;

  // Форматируем метаданные
  const metaStr = Object.keys(meta).length 
    ? '\n' + JSON.stringify(meta, null, 2)
    : '';

  return `${timestamp} [${level}]: ${formattedMessage}${metaStr}`;
};

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.prettyPrint(),
    winston.format.timestamp(),
    winston.format.printf(formatMessage)
  ),
  transports: [
    new winston.transports.File({ 
      filename: 'logs/error.log', 
      maxsize: 10485760,
      maxFiles: 10,
      level: 'error',
      format: winston.format.combine(
        winston.format.prettyPrint(),
        winston.format.timestamp(),
        winston.format.printf(formatMessage)
      )
    }),
    new winston.transports.File({ 
      filename: 'logs/combined.log',
      maxsize: 10485760,
      maxFiles: 10,
      format: winston.format.combine(
        winston.format.prettyPrint(),
        winston.format.timestamp(),
        winston.format.printf(formatMessage)
      )
    })
  ]
});

// Добавляем вывод в консоль
logger.add(new winston.transports.Console({
  format: winston.format.combine(
    winston.format.prettyPrint(),
    winston.format.colorize(),
    winston.format.timestamp(),
    winston.format.printf(formatMessage)
  )
}));

module.exports = logger;