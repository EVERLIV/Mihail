const OpenAI = require('openai');
const { HttpsProxyAgent } = require('https-proxy-agent');
const prompt = require('./prompt.js');
const { logger } = require('./logger.js');

async function processEmailWithDeepseek(emailContent, subject) {
    logger.info('Обрабатываем письмо с Deepseek API:');

    // Создаем прокси агент
    //const proxyUrl = `http://${process.env.CLAUDE_PROXY}:${process.env.CLAUDE_PORT}`;
    //const proxyAgentDeepseek = new HttpsProxyAgent(proxyUrl);

    emailContent = emailContent.replace(/[\r\n]/g, ', ');

    const openai = new OpenAI({
        baseURL: process.env.DEEPSEEK_API_URL,
        apiKey: process.env.DEEPSEEK_API_KEY,
        //httpAgent: proxyAgentDeepseek
    });

    try {
        const completion = await openai.chat.completions.create({
            model: "deepseek-chat",
            messages: [
                {
                    role: "system",
                    content: "You are an AI assistant specializing in extracting structured data from customer order emails. Your task is to carefully analyze customer emails that contain requests for parts and quantities, and extract this information into a standardized JSON format."
                },
                {
                    role: "user",
                    content: `${prompt}\n\nInput:\n${emailContent}\n\n`
                }
            ],
            temperature: 1,
            max_tokens: 8000,
            response_format: { type: "json_object" }
        });

        let responseText = completion.choices[0].message.content;
        var parsedResponse = JSON.parse(responseText);

        if (!Array.isArray(parsedResponse)) {
            logger.info('Ответ от Deepseek не является массивом, преобразуем в массив');
            parsedResponse = [parsedResponse];
        }

        for (item of parsedResponse) {
            item.um = item.um ? item.um : 'EA';


            let priority
            if (!item.priority) {
                if (subject.toLowerCase().includes('asap')) {
                    priority = 'AOG'

                } else if (subject.toLowerCase().includes('urgent')) {
                    priority = 'WSP'

                } else if (subject.includes('AOG')) {
                    priority = 'AOG'

                } else if (subject.includes('NO-GO')) {
                    priority = 'AOG'

                } else if (subject.toLowerCase().includes('critical')) {
                    priority = 'WSP'

                } else if (subject.includes('CRT!')) {
                    priority = 'WSP'

                } else if (subject.toLowerCase().includes('urgent stock replenishment')) {
                    priority = 'USR'

                } else {
                    priority = 'RTN'
                }
            }

            item.part_number = String(item.part_number)?.replace(/\s/g, '').trim();
            item.priority = ['AOG', 'WSP', 'USR', 'RTN'].some(elem => elem === item.priority) ? item.priority : priority
        }

        return parsedResponse;

    } catch (error) {
        logger.error('Ошибка при обработке письма через Deepseek API:', JSON.stringify(error));
        throw error;
    }
}

module.exports = {
    processEmailWithDeepseek
}; 