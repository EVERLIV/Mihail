require('dotenv').config();
require('dotenv').config({ path: '../.env' });

const { logger } = require('./logger');
const apiUrl = process.env.PANTHEON_API_URL;
const sendCRurl = process.env.POST_CR_NEW;
const token = process.env.API_AUTH_TOKEN;

// Функция для очистки объекта перед отправкой
function sanitizeCR(data) {
    return {
        message_id: data.message_id.replace(/^<|>$/g, ''),
        customer: data.customer,
        description: data.description.substring(0, 250),
        request_date: data.request_date,
        request_number: data.request_number,
        target_date: data.target_date,
        part_number: data.part_number,
        um: data.um,
        qty: data.qty,
        condition: data.condition,
        priority: data.priority,
        from_email: data.from_email,
        ac_type: data.ac_type,
        pn_alt: data.pn_alt,
        transfer_to_quote: data.transfer_to_quote || '',
        remarks: data.remarks.substring(0, 200)
    };
}

let counter = 0;
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const sendCR = async (data) => {
    logger.info('Sending CR to Pantheon');
    logger.info('API URL:' + apiUrl + sendCRurl);

    for (let i = 0; i < data.rfq_details.length; i++) {
        let item = data.rfq_details[i];
        item.um = item.um === 'GR' ? 'G' : item.um;
        item.um = item.um === 'RL' ? 'RO' : item.um;
        item.um = item.um === 'SH' ? 'EA' : item.um;
        if (!['FT', 'M', 'YD', 'KG', 'LB', 'G', 'L', 'OZ', 'RO', 'KT', 'CA', 'PR', 'PK', 'EA'].some(unit => item.um === unit)) {
            item.um = 'EA';
        }
        data.rfq_details[i] = sanitizeCR(item);
    }

    // Очищаем объект перед отправкой
    logger.info('Отправляем в Pantheon:' + JSON.stringify(data, null, 2));
    logger.info(apiUrl + sendCRurl)
    let response = await fetch(apiUrl + sendCRurl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': token
        },
        body: JSON.stringify(data)
    });

    logger.info('Status code: ' + response.status)
    logger.info(response.statusText)


    if (response.status === 200) {

        try {
            let respData = await response.json();
            logger.info('Response data:' + JSON.stringify(respData, null, 2));
            if (respData.error) {
                if (respData.error === 'auth_failed') {
                    logger.error('Пантеон отдыхает - повторная попытка отправки через 10 секунд');
                    counter++;
                    if (counter > 3) {
                        throw new Error('Ошибка - пантеон висит - auth_failed');
                    }
                    await delay(10000);
                    await sendCR(data);
                    return respData;
                } else {
                    throw new Error('Ошибка при отправке CR в Pantheon');
                }
            }
            return respData;
        } catch (error) {
            let errorResponse = await response.text();
            logger.error('Error response:', {
                error: errorResponse,
                details: error
            });
        }

    } else if (response.status === 400) {
        logger.error('Error response:', {
            error: '400',
            details: 'Bad Request'
        });
    }
}

module.exports = { sendCR };