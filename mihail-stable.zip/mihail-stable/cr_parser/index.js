// Загрузка переменных окружения из .env файла
require('dotenv').config({ path: '../.env' });
require('dotenv').config();
const Imap = require('imap');
const XLSX = require('xlsx');

const { simpleParser } = require('mailparser');
const { processEmailWithDeepseek } = require('./deepseek.js');
const { parseAirQuotationEmail } = require('./airquotation_parser');
const { aeroflotParser } = require('./aeroflot_parser.js');
const { aeroflotTableParser } = require('./aeroflot_table.js');
const { azurParser } = require('./azur_parser.js');
const { yamalParser } = require('./yamal_parser.js');
const { s7parser } = require('./s7_parser.js');
const { atechParser } = require('./atechnics_parser.js');
const { simpleTableParser } = require('./simple_table.js');
const { iflyParser } = require('./ifly_parser.js');
const { lukoilParser } = require('./lukoil_parser.js');

const { translateRequest } = require('./translate.js');
const { sendCR } = require('./sendcr.js');
const { MongoClient } = require('mongodb');
const { logger, skippedLogger } = require('./logger');


// Функция для проверки наличия кириллицы в тексте
function containsCyrillic(text) {
  let result = /[а-яА-ЯЁё]/.test(text);
  if (result) {
    logger.info('Заказ содержит кириллицу');
    logger.info(text);
  }
  return result;
}

// Конфигурации IMAP для нескольких почтовых ящиков
const imapConfigs = [];

// Поиск всех настроенных почтовых ящиков (EMAIL_USER0, EMAIL_USER1, и т.д.)
for (let i = 0; i <= 10; i++) {
  const userVar = `EMAIL_USER${i}`;
  const passVar = `EMAIL_PASSWORD${i}`;
  const hostVar = `EMAIL_HOST${i}`;
  const portVar = `EMAIL_PORT${i}`;
  
  if (process.env[userVar] && process.env[passVar]) {
    imapConfigs.push({
      name: `Ящик ${i}`,
      user: process.env[userVar],
      password: process.env[passVar],
      host: process.env[hostVar] || process.env.EMAIL_HOST,
      port: process.env[portVar] || process.env.EMAIL_PORT || 993,
      tls: true,
      tlsOptions: { rejectUnauthorized: false }
    });
  }
}

skippedLogger.info(`Настроено ${imapConfigs.length} почтовых ящиков для обработки`);

const domains = [
  '@s7.ru',
  '@aeroflot.ru',
  'flysmartavia.com',
  '@airquotation.com',
  'nordwindairlines.ru',
  '@u6.ru',
  '@azurair.ru',
  'yamalaero',
   'atechnics.ru',
  'flyredwings.com',
  'iflyltd.ru',
  'yakutia.aero',
  'aviastartu.ru',
  'izhavia',
  'rossiya-airlines',
  'lukoil.com',
  'severstal-avia.com',
  'jetica',
  'velparts.com',
  'vd-technics.com',
  'tulparair.ru',
  'tulpar.aero'
];

// Функция для подключения к почтовому ящику
function connectToMailbox(imapConfig) {
  return new Promise((resolve, reject) => {
    const imap = new Imap(imapConfig);

    imap.once('ready', () => {
      imap.openBox('INBOX', false, (err, box) => {
        if (err) {
          imap.end();
          return reject(err);
        }
        resolve(imap);
      });
    });

    imap.once('error', (err) => {
      reject(err);
    });

    imap.connect();
  });
}

// Функция для поиска писем по критериям
function searchEmails(imap, criteria) {
  return new Promise((resolve, reject) => {
    imap.search(criteria, (err, results) => {
      if (err) return reject(err);
      // Сортируем результаты по убыванию (сначала новые)
      results.sort((a, b) => b - a);
      resolve(results);
    });
  });
}

// Функция для получения содержимого письма
function fetchEmail(imap, uid) {
  return new Promise((resolve, reject) => {
    const fetch = imap.fetch(uid, { bodies: '', markSeen: false });

    fetch.on('message', (msg) => {
      let buffer = '';

      msg.on('body', (stream) => {
        stream.on('data', (chunk) => {
          buffer += chunk.toString('utf8');
        });

        stream.on('end', () => {
          simpleParser(buffer)
            .then(parsed => {
              resolve({
                uid: uid,
                parsed: parsed,
                messageId: parsed.messageId
              });
            })
            .catch(err => reject(err));
        });
      });

      msg.on('error', (err) => {
        reject(err);
      });
    });

    fetch.on('error', (err) => {
      reject(err);
    });
  });
}

// Функция для форматирования даты в YYYY-MM-DD
function formatDate(date, daysToAdd = 0) {
  const d = new Date(date);
  d.setDate(d.getDate() + daysToAdd);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

const mongourl = process.env.MONGODB_URL;
const dbName = process.env.MONGO_DB;

// Функция для проверки существования запроса
async function checkIfRequestExists(messageId) {
  let client;
  try {
    client = await MongoClient.connect(mongourl);
    const db = client.db(dbName);
    const collection = db.collection('cr_requests');

    const result = await collection.findOne({ message_id: messageId });
    return result !== null;
  } catch (error) {
    logger.error('Ошибка при проверке существования запроса:', error);
    return false;
  } finally {
    if (client) {
      await client.close();
    }
  }
}

// Функция для сохранения запроса
async function saveRequest(request) {
  let client;
  try {
    client = await MongoClient.connect(mongourl);
    const db = client.db(dbName);
    const collection = db.collection('cr_requests');

    await collection.insertOne(request);
    skippedLogger.info(`Запрос ${request.request_number} успешно сохранен в MongoDB`);
  } catch (error) {
    logger.error('Ошибка при сохранении запроса:', error);
    throw error;
  } finally {
    if (client) {
      await client.close();
    }
  }
}

// Функция для пометки письма как прочитанного
function markEmailAsRead(imap, uid) {
  return new Promise((resolve, reject) => {
    imap.addFlags(uid, '\\Seen', (err) => {
      if (err) return reject(err);
      resolve();
    });
  });
}

async function markEmailAsFlagged(imap, uid) {
  return new Promise((resolve, reject) => {
    imap.addFlags(uid, '\\Flagged', (err) => {
      if (err) {
        reject(err);
      } else {
        resolve();
      }
    });
  });
}

function cleanEmailText(text) {
  if (text) {
    return text
      .replace(/\[http:[^\]]+\]/g, '')
      // Удаляем встроенные изображения (base64)
      .replace(/data:image\/[^;]+;base64,[^\s]+/g, '')
      // Удаляем ссылки на изображения
      .replace(/https?:\/\/[^\s]+\.(jpg|jpeg|png|gif|bmp|svg)/gi, '')
      // Удаляем HTML-теги для изображений
      .replace(/<img[^>]+>/g, '')
      // Удаляем style-блоки вместе с содержимым
      .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
      .replace(/<head\b[^<]*(?:(?!<\/head>)<[^<]*)*<\/head>/gi, '')
      // Удаляем любые URL в угловых скобках
      .replace(/<https?:\/\/[^>]+>/gi, '')
      // Удаляем всё после "Original Message"
      //.replace(/Thank you in advance![\s\S]*$/i, '')
      .replace(/This document may contain[\s\S]*$/i, '')
      .replace(/Best regards[^]*/i, '')
      .replace(/С уважением[^]*/i, '')
      // Удаляем специальные символы Unicode, кроме переносов строк
      .replace(/[\u0000-\u0009\u000B-\u001F\u007F-\u009F]/g, '')
      .trim();
  } else {
    return '';
  }
}

function createImapSearchStructure(domains) {
  // Если нет доменов, возвращаем пустой массив
  if (!domains || domains.length === 0) return [];

  // Если только один домен, возвращаем простую структуру
  if (domains.length === 1) {
    return ['FROM', domains[0]];
  }

  // Разбиваем на пары
  const pairs = [];
  for (let i = 0; i < domains.length; i += 2) {
    if (i + 1 < domains.length) {
      pairs.push(['OR', ['FROM', domains[i]], ['FROM', domains[i + 1]]]);
    } else {
      pairs.push(['FROM', domains[i]]);
    }
  }

  // Если только одна пара, возвращаем её
  if (pairs.length === 1) return pairs[0];

  // Объединяем пары в структуру
  let result = pairs[0];
  for (let i = 1; i < pairs.length; i++) {
    result = ['OR', result, pairs[i]];
  }

  return result;
}



async function parseXLSX(buffer) {
  try {
    const workbook = XLSX.read(buffer, { type: 'buffer' });
    const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
    let rows = XLSX.utils.sheet_to_json(firstSheet);
    // Нормализация ключей
    rows = rows.map(normalizeXLSXRow);
    return rows;
  } catch (error) {
    logger.error('Ошибка при парсинге XLSX файла:', error);
    return null;
  }
}

// Нормализация ключей для XLSX-объектов
function normalizeXLSXRow(row) {
  // Сопоставление возможных заголовков с целевыми ключами (все ключи в верхнем регистре)
  const map = {
    'PN': 'part_number',
    'P/N': 'part_number',
    'PART NUMBER': 'part_number',
    'PART NUMBER:': 'part_number',
    'PART NO.': 'part_number',
    'PART NO': 'part_number',
    'DESCR': 'description',
    'DESCRIPTION': 'description',
    'DESCRIPTION:': 'description',
    'Q-TY': 'qty',
    'QTY': 'qty',
    'QTY.': 'qty',
    'QT': 'qty',
    'QUANTITY': 'qty',
    'КОЛ-ВО': 'qty',
    'UOM': 'um',
    'UM': 'um',
    'MU': 'um',
    'EXT. MEASURE UNIT': 'um',
    'EXT MEASURE UNIT': 'um',
    'MEASURE': 'um',
    'KNOWN ALT': 'pn_alt',
    'ALT P/N': 'pn_alt',
    'ALT': 'pn_alt',
    'ALT1': 'pn_alt',
    'ALT2': 'pn_alt',
    'ALT3': 'pn_alt',
    'ALT4': 'pn_alt',
    'ALT5': 'pn_alt',
    'ALTS': 'pn_alt',
    'REMARKS': 'remarks',
    'PRIORITY': 'priority',
    'AC TYPE': 'ac_type',
    'AC': 'ac_type',
    'A/C': 'ac_type',
    'F/A TYPE': 'ac_type',
    'F/A': 'ac_type',
   
  };
  const normalized = {};
  let alts = [];
  for (const key in row) {
    const normKey = map[key.trim().toUpperCase()];
    if (normKey === 'pn_alt') {
      // Собираем все ALT в массив
      alts.push(row[key]);
    }
    if (normKey) {
      normalized[normKey] = row[key];
    }
  }
  // pn_alt всегда массив всех найденных ALT
  if (alts.length) {
    normalized.pn_alt = alts
      .flatMap(alt => typeof alt === 'string' ? alt.split(/[,;\n]/) : [alt])
      .map(s => String(s).trim())
      .filter(Boolean);
  }
  // Гарантируем, что part_number всегда строка
  if (normalized.part_number !== undefined && normalized.part_number !== null) {
    // Заменяем все похожие на дефис символы на обычный дефис
    normalized.part_number = String(normalized.part_number)
      .replace(/[−–—‒―﹘﹣－]/g, '-') // длинное тире, минус и др.
      .trim();
  }
  return normalized;
}


// Основная функция для обработки писем в одном почтовом ящике
async function processEmailsForMailbox(imapConfig) {
  let imap;
  try {
    skippedLogger.info(`Подключение к почтовому ящику ${imapConfig.name} (${imapConfig.user})...`);
    imap = await connectToMailbox(imapConfig);
    skippedLogger.info('Подключение успешно установлено');

    const searchStructure = createImapSearchStructure(domains);    // if (process.env.ENVIRONMENT === 'production') {
    // Критерии поиска писем
    searchCriteria = [
      searchStructure,
      //['UNSEEN'],
      ['SINCE', new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()],
      ['UNFLAGGED'], // Только непрочитанные письма
    ];


    // Поиск писем по критериям
    const uids = await searchEmails(imap, searchCriteria);
    skippedLogger.info(`Найдено ${uids.length} писем, соответствующих критериям`);

    // Обработка каждого найденного письма
    for (const uid of uids) {
      try {
        const email = await fetchEmail(imap, uid);
        const { from, subject, text, html, messageId, date, attachments } = email.parsed;

        // Пропускаем письма, которые являются ответами
        if (subject?.toUpperCase().startsWith('RE:') ||
            subject?.toUpperCase().includes('RFQ FOR REPAIR') ||
            (subject && /(?:прошу.*(?:выслать|предоставить|направить).*сертификат|просьба.*(?:выслать|направить).*сертификат|прошу.*принять.*в.*работу.*новый.*заказ|квотация|планируем.*разместить.*заказ)/i.test(subject.replace(/\s+/g, ' '))) ||
            (text && /(?:прошу.*(?:выслать|предоставить|направить).*сертификат|просьба.*(?:выслать|направить).*сертификат|прошу.*заказ.*новый|планируем.*разместить.*заказ)/i.test(text.replace(/\s+/g, ' ')))
        ) {
          skippedLogger.info(`Пропускаем письмо ${subject}`);
          continue;
        }

        // Создаем объект с извлеченными данными
        const extractedData = {
          messageId: messageId,
          date: date,
          subject: subject,
          from: from?.value?.[0]?.address,
          text: text || html
        };

        let requestNumber = subject// + ' ' + date.toLocaleString('ru-RU', { timeZone: 'Europe/Moscow' })
        const alreadySent = await checkIfRequestExists(messageId);
        if (alreadySent) {
          skippedLogger.info(`Запрос ${requestNumber} уже был отправлен ранее, пропускаем`);
          continue;
        } else {
          skippedLogger.info(`Запрос ${requestNumber} не был отправлен ранее, отправляем`);
        }

        // Выводим извлеченные данные
        logger.info('Извлеченные данные из письма:');
        logger.info(subject);
        //---------------------------------------------------------------------------------
        let structuredData;
        let fromAddress = from.value?.[0]?.address;
        //----------------------------------------------------------------------------------------

        if (fromAddress.includes('airquotation.com')) {
          logger.info('Парсинг письма с AirQuotation');
          structuredData = await parseAirQuotationEmail(html, subject);
        }
        //------------------------------------------------------------------------------------------
        if (extractedData.from.includes('aeroflot.ru')) {
          logger.info('Парсинг письма с Aeroflot')
          logger.info(subject);

          if (attachments.length > 0) {
            structuredData = await processAttachment(attachments, structuredData);
          }

          // if (!structuredData || structuredData.length === 0) {
          //   structuredData = aeroflotParser(html, subject);
          // }

          if (!structuredData || structuredData.length === 0) {
            structuredData = await aeroflotTableParser(cleanEmailText(html), subject);
            if (!structuredData || structuredData.length === 0) {
              structuredData = await processEmailWithDeepseek(cleanEmailText(text), subject);
            }

            if (
              structuredData && structuredData.some(part => part.error)
            ) {
              throw new Error('Найдены ошибки в структурированных данных после всех попыток');
            }
          }
        }
        //---------------------------------------------------------------------------------
        if (fromAddress.includes('s7.ru')) {
          // Обрабатываем текст письма через соответствующий парсер
          logger.info('Парсинг данных из таблицы');
          let tableData = s7parser(cleanEmailText(html), subject);


          if (!tableData || tableData.length === 0) {
            logger.info('Парсинг письма с Deepseek');
            // logger.info(cleanEmailText(extractedData.text));
            structuredData = await processEmailWithDeepseek(cleanEmailText(text) || cleanEmailText(html), subject);
            //logger.info(structuredData);
          } else {
            structuredData = tableData;
          }

          if (
            structuredData?.some(part => part.error)
          ) {
            throw new Error('Найдены ошибки в структурированных данных после всех попыток');
          }
        }
        //---------------------------------------------------------------------------------
         //---------------------------------------------------------------------------------
         if ([
          'tulparair.ru', 
          'tulpar.aero', 
          'u6.ru', 
          'flysmartavia.com', 
          'jetica', 
          'severstal-avia.com'          
        ].some(domain => fromAddress.includes(domain))) {
          logger.info('Парсинг письма от' + fromAddress)
          logger.info(subject);
          logger.info(cleanEmailText(text));


          if (attachments.length > 0) {
            structuredData = await processAttachment(attachments, structuredData);
          }

          if (!structuredData || structuredData.length === 0) {
            structuredData = await processEmailWithDeepseek(cleanEmailText(text) || cleanEmailText(html), subject);
          }
          
          if (
            structuredData?.some(part => part.error)
          ) {
            throw new Error('Найдены ошибки в структурированных данных после всех попыток');
          }
        }
        //---------------------------------------------------------------------------------
        if ([
          'vd-technics.com',
        ].some(domain => fromAddress.includes(domain))) {
          logger.info('Парсинг письма от ' + fromAddress)
          logger.info(subject);
          structuredData = azurParser(cleanEmailText(html), subject);
          if (!structuredData || structuredData.length === 0) {
            structuredData = await processEmailWithDeepseek(cleanEmailText(html), subject)
          }
          if (
            structuredData?.some(part => part.error)
          ) {
            throw new Error('Найдены ошибки в структурированных данных после всех попыток');
          }
        }
          console.log(structuredData)
        //---------------------------------------------------------------------------------

          //---------------------------------------------------------------------------------
        // if (
        //   fromAddress.includes('u6.ru')
        //   || fromAddress.includes('flysmartavia.com')
        //   || fromAddress.includes('jetica')
        //   || fromAddress.includes('severstal-avia.com')
        
        // )
        //  {
        //   logger.info('Парсинг письма от  ' + fromAddress);
        //   logger.info(subject);

        //   structuredData = await processEmailWithDeepseek(cleanEmailText(text) || cleanEmailText(html), subject);
        // }
        //---------------------------------------------------------------------------------
        if ([
          'azurair.ru',
        ].some(domain => fromAddress.includes(domain))) {
          logger.info('Парсинг письма от ' + fromAddress)
          logger.info(subject);
          structuredData = azurParser(cleanEmailText(html), subject);
          console.log(structuredData)
          if (!structuredData || structuredData.length === 0) {
            structuredData = await processEmailWithDeepseek(cleanEmailText(html), subject)
          }
          if (
            structuredData?.some(part => part.error)
          ) {
            throw new Error('Найдены ошибки в структурированных данных после всех попыток');
          }
        }
        //---------------------------------------------------------------------------------------------------
        if ([
          'nordwindairlines.ru',
        ].some(domain => fromAddress.includes(domain))) {
          logger.info('Парсинг письма от ' + fromAddress)
          logger.info(subject);
          structuredData = azurParser(cleanEmailText(html), subject);
          if (!structuredData || structuredData.length === 0) {
            structuredData = await processEmailWithDeepseek(cleanEmailText(html), subject)
          }
          if (
            structuredData?.some(part => part.error)
          ) {
            throw new Error('Найдены ошибки в структурированных данных после всех попыток');
          }
        }
        
        //---------------------------------------------------------------------------------
        if (fromAddress.includes('yamalaero.ru')) {
          logger.info('Парсинг письма с Yamal');
          logger.info(subject);
          let tableData = yamalParser(cleanEmailText(html), subject);

          logger.info(tableData);

          if (!tableData || tableData.length === 0) {
            logger.info('Парсинг письма с Deepseek');
            structuredData = await processEmailWithDeepseek(cleanEmailText(extractedData.text), subject);
          } else {
            structuredData = tableData;
          }

          if (structuredData?.some(part => part.error)) {
            logger.info('Найдены ошибки deepseek');
            throw new Error('Найдены ошибки в структурированных данных после всех попыток');
   
          }
        }
        //---------------------------------------------------------------------------------
        if (fromAddress.includes('atechnics.ru')) {
          logger.info('Парсинг письма с Atechnics');

          if (attachments.length > 0) {
            structuredData = await processAttachment(attachments, structuredData);
          }

          if (!structuredData || structuredData.length === 0) {
            logger.info('Парсинг данных из таблицы');
            structuredData = atechParser(cleanEmailText(html), subject);
          }
          if (!structuredData || structuredData.length === 0) {
            logger.info('Парсинг данных с Deepseek');
            structuredData = await processEmailWithDeepseek(cleanEmailText(text), subject);
          }
          if (!structuredData || structuredData.length === 0) {
            logger.info('Парсинг данных с Deepseek');
            structuredData = await processEmailWithDeepseek(cleanEmailText(html), subject);
          }

          if (
            structuredData?.some(part => part.error)
          ) {
            throw new Error('Ошибка при парсинге письма с Deepseek');
          }
        }
        //---------------------------------------------------------------------------------
        if (fromAddress.includes('flyredwings.com')) {
          logger.info('Парсинг письма с FlyRedWings')
          logger.info(subject);
          structuredData = simpleTableParser(cleanEmailText(html), subject);
          if (!structuredData || structuredData.length === 0) {
            structuredData = await processEmailWithDeepseek(cleanEmailText(text)
              || cleanEmailText(html), subject);
          }
          if (
            structuredData && structuredData.some(part => part.error)
          ) {
            throw new Error('Ошибка при парсинге письма с Deepseek');
          }
        }
        //------------------------------------------------------------------------------------
        if (extractedData.from.includes('iflyltd.ru')) {
          logger.info('Парсинг письма с IFLY LTD')
          logger.info(subject);
          structuredData = iflyParser(cleanEmailText(html), subject);
          if (!structuredData || structuredData.length === 0) {
            structuredData = await processEmailWithDeepseek(cleanEmailText(text)
              || cleanEmailText(html), subject);
          }
          if (
            structuredData && structuredData.some(part => part.error)
          ) {
            throw new Error('Ошибка при парсинге письма с Deepseek');
          }
        }
        //------------------------------------------------------------------------------------

        if (fromAddress.includes('yakutia.aero') || fromAddress.includes('aviastartu.ru')
          || fromAddress.includes('izhavia') || fromAddress.includes('rossiya-airlines.com')
        ) {
          logger.info('Парсинг письма' + fromAddress)
          logger.info(subject);
          structuredData = azurParser(cleanEmailText(html), subject);
          if (!structuredData || structuredData.length === 0) {
            structuredData = await processEmailWithDeepseek(cleanEmailText(html), subject)
          }
          if (
            structuredData.some(part => part.error)
          ) {
            throw new Error('Ошибка при парсинге письма с Deepseek');
          }
        }
        //---------------------------------------------------------------------------------
        // Парсинг письма от lukoil.com
        if (fromAddress.includes('lukoil.com')) {
          logger.info('Парсинг письма от lukoil.com')
          logger.info(subject);
          structuredData = lukoilParser(cleanEmailText(html), subject);
          console.log(structuredData)
          if (!structuredData || structuredData.length === 0) {
            structuredData = await processEmailWithDeepseek(cleanEmailText(html), subject)
          }
        }
        //---------------------------------------------------------------------------------
        if ( fromAddress.includes('velparts.com')
        ) {
          logger.info('Парсинг письма' + fromAddress)
          logger.info(subject);
         
          if (attachments.length > 0) {
            logger.info('Attachments:');
            for (const attachment of attachments) {
              if (attachment.filename.toLowerCase().endsWith('.xlsx')) {
                logger.info(`Обработка XLSX файла: ${attachment.filename}`);
                structuredData = await parseXLSX(attachment.content);
                if (structuredData && structuredData.length) {
                  logger.info('В XLSX найдено :' + structuredData.length + ' строк с заголовками');
                  logger.info(Object.keys(structuredData[0]));
                  for (let item of structuredData) {
                    if (item.pn_alt) {
                      const altPartNumbersText = item.pn_alt.length > 0 ? `Alt P/N: ${item.pn_alt.join(', ')}` : '';
                      const remarksText = [item.remarks, altPartNumbersText].filter(Boolean).join('; ');
                      item.remarks = remarksText;
                    }
                  }
                  // Здесь можно добавить дополнительную обработку данных
                }
              }
            }
          }

          if (!structuredData || structuredData.length === 0) {
            structuredData = await processEmailWithDeepseek(cleanEmailText(html), subject)
          }
          
          if (
            structuredData.some(part => part.error)
          ) {
            throw new Error('Ошибка при парсинге письма с Deepseek');
          }
        }
        //------------------------------------------------------------------------------------
        if (structuredData) {
          if (structuredData && containsCyrillic(structuredData.map(part => part.description).join(' '))) {
            logger.info('Заказ содержит кириллицу - передаем переводчику');
            let translationResult = await translateRequest(structuredData);
            if (translationResult) {
              structuredData = translationResult;
            }
          }

          // Убеждаемся, что structuredData - это массив
          if (structuredData && structuredData.some(part => !/^[A-Za-z0-9\-/]+$/.test(part.part_number))) {

            logger.info('Найдены недопустимые символы в номере детали - передаем в deepseek');

            let goodPart = structuredData.filter(part => /^[A-Za-z0-9\-/]+$/.test(part.part_number));
            let badPart = structuredData.filter(part => !/^[A-Za-z0-9\-/]+$/.test(part.part_number));

            logger.info(badPart.map(part => part.part_number));

            let deepOutput = [];
            for (let item of badPart) {
              let deepInput = '';
              for (let field of Object.keys(item)) {
                deepInput += `${field}: ${item[field]}\n`;
              }
              logger.info(deepInput);
              let resp = await processEmailWithDeepseek(deepInput, subject);
              if (Array.isArray(resp) && resp.length && !resp.error) {
                deepOutput.push(...resp);
              }
            }
            structuredData = [...goodPart, ...deepOutput];
            if (
              structuredData && structuredData.some(part => part.error)
            ) {
              throw new Error('Ошибка при парсинге письма с Deepseek');
            }
          }

          logger.info('Финальные данные:');
          logger.info(structuredData);

          if (structuredData?.some(part => part.error)) {
            await markEmailAsFlagged(imap, uid);
            throw new Error('Найдены ошибки в структурированных данных после всех попыток');
          }



          // Преобразуем объект с числовыми ключами в массив, если это необходимо

          for (item of structuredData) {
            let priorityField = item.priority?.toLowerCase().includes('urgent') ? 'AOG'
              : item.priority?.toLowerCase().includes('aog') ? 'AOG'
                : item.priority?.toLowerCase().includes('routine') ? 'RTN'
                  : item.priority?.toLowerCase().includes('replenishment') ? 'USR'
                    : item.priority?.toLowerCase().includes('crit') ? 'WSP' : item.priority
            item.priority =
              ['AOG', 'RTN', 'USR', 'WSP'].some(elem => elem === priorityField) ?
                priorityField : 'RTN'

            if ( fromAddress.toUpperCase().includes('AOG@')) {
              item.priority = 'AOG'
            }

            if (item.um?.toUpperCase() === 'RL') {
              item.um = 'RO';
            }
            if (item.um?.toUpperCase() === 'LT') {
              item.um = 'L';
            }
            if (!["EA", "FT", "M", "YD", "KG", "LB", "G", "L", "OZ", "RO", "KT", "CA", "QT"].includes(item.um?.toUpperCase())) {
              item.um = 'EA';
            }
            // if (item.part_number.includes(',')) {
            //   let [partNumber, clarification] = item.part_number.split(',')
            //   item.part_number = partNumber
            //   item.remarks = item.remarks + ' ' + clarification
            // }
            item.description = item.description || item.part_number
            item.from_email = extractedData.from
            item.message_id = messageId
            item.condition = "SV"
            item.remarks = imapConfig.user + ' ' + item.remarks
            item.customer =
            extractedData.from.includes('s7') ? 'S7' :
            extractedData.from.toLowerCase().includes('aeroflot') ? 'AEROFLOT' :
            extractedData.from.toLowerCase().includes('airquotation') ? 'S7' :
            extractedData.from.toLowerCase().includes('u6') ? 'URAL AIRLINES' :
            extractedData.from.toLowerCase().includes('nordwindairlines') ? 'NORDWIND' :
            extractedData.from.toLowerCase().includes('flysmartavia') ? 'SMARTAVIA' :
            extractedData.from.toLowerCase().includes('azurair') ? 'AZUR' :
            extractedData.from.toLowerCase().includes('yamalaero') ? 'YAMAL' :
            extractedData.from.toLowerCase().includes('atechnics.ru') ? 'AFL-TECHNICS' :
            extractedData.from.toLowerCase().includes('flyredwings.com') ? 'RED WINGS' :
            extractedData.from.toLowerCase().includes('iflyltd.ru') ? 'IFLY' : 
            extractedData.from.toLowerCase().includes('yakutia') ? 'YAKUTIA' : 
            extractedData.from.toLowerCase().includes('aviastartu') ? 'AVIASTAR' : 
            extractedData.from.toLowerCase().includes('izhavia') ? 'IZHAVIA' : 
            extractedData.from.toLowerCase().includes('rossiya-airlines') ? 'ROSSIYA AIRLINES' :
            extractedData.from.toLowerCase().includes('velparts') ? 'VELPARTS' : 
            extractedData.from.toLowerCase().includes('vd-technics') ? 'VDTM' : 
            extractedData.from.toLowerCase().includes('lukoil.com') ? 'LUKOIL' :
            extractedData.from.toLowerCase().includes('jetica.ru') ? 'JETICA' :
            extractedData.from.toLowerCase().includes('severstal-avia.com') ? 'SEVERSTAL' :
            extractedData.from.toLowerCase().includes('tulparair.ru') ? 'TULPARAIR' :
            extractedData.from.toLowerCase().includes('tulpar.aero') ? 'TULPAR AERO GROUP' :
            ''

            item.transfer_to_quote = ""
            item.request_number = requestNumber
            item.request_date = formatDate(date)

            let priority = item.priority
            let daysToAdd = priority === 'RTN' ? 40 : priority === 'USR' ? 30 :
              priority === 'WSP' ? 8 : priority === 'AOG' ? 5 : 5
            item.target_date = formatDate(date, daysToAdd)

            if (item.pn_alt) {
              let alts = []
              for (let alt of item.pn_alt) {
                // Разбиваем по всем возможным разделителям
                let parts = alt.split(/[\n,;]|\s+or\s+/)
                // Фильтруем пустые строки и добавляем в результат
                alts.push(...parts.filter(part => part.trim()))
              }
              // Удаляем дубликаты
              item.pn_alt = [...new Set(alts)]
            }

            
            delete item.requestNumber
          }

          logger.info('Обработанные данные');
          logger.info(structuredData);
          
          structuredData = structuredData.filter(part => !containsCyrillic(part.part_number));
          
          if (structuredData.length === 0) {
            logger.info('Структурированные данные не найдены - пропускаем письмо')
            await markEmailAsFlagged(imap, uid);
            return;
          }

          //// Отправляем в Pantheon
          let pantheonResult = await sendCR({
            rfq_details: structuredData
          }
          );
          //// Если отправка успешна, сохраняем в MongoDB и помечаем письмо как прочитанное
          if (pantheonResult) {
            if (pantheonResult.ok) {
              logger.info('Отправка в Pantheon успешна')
              //await markEmailAsRead(imap, uid);
            } else {
              logger.info('Отправка в Pantheon с ошибкой')
              logger.error(pantheonResult)
              // if error: 'auth_failed' wait 10 seconds and try again

              await markEmailAsFlagged(imap, uid);
            }
            for (let item of structuredData) {
              await saveRequest({
                ...item,
                message_id: messageId,
                sent_to_pantheon: pantheonResult.ok,
                pantheon_result: pantheonResult,
                created_at: new Date()
              });
            }
            skippedLogger.info(`Письмо ${uid} помечено как прочитанное`);
          } else {
            await markEmailAsFlagged(imap, uid);
            logger.error('Отправка в Pantheon не успешна')
          }
        } else {
          logger.info('Структурированные данные не найдены')
          await markEmailAsFlagged(imap, uid);

        }

      } catch (err) {
        logger.error(`Ошибка при обработке письма ${uid}:`, err);
        await markEmailAsFlagged(imap, uid);
      }
    }

  } catch (err) {
    logger.error(`Произошла ошибка при обработке ящика ${imapConfig.name}:`, err);
  } finally {
    if (imap && imap.state !== 'disconnected') {
      imap.end();
      skippedLogger.info(`Соединение с ящиком ${imapConfig.name} закрыто`);
    }
  }
}

// Главная функция для циклической обработки всех почтовых ящиков
async function processAllMailboxes() {
  if (imapConfigs.length === 0) {
    logger.error('Не настроено ни одного почтового ящика');
    return;
  }

  while (true) {
    try {
      skippedLogger.info(`Начинаем цикл обработки ${imapConfigs.length} почтовых ящиков`);
      
      for (const imapConfig of imapConfigs) {
        try {
          await processEmailsForMailbox(imapConfig);
          skippedLogger.info(`Обработка ящика ${imapConfig.name} завершена`);
        } catch (err) {
          logger.error(`Ошибка при обработке ящика ${imapConfig.name}:`, err);
        }
        
        // Пауза между ящиками
        await new Promise(resolve => setTimeout(resolve, 5000));
      }
      
      logger.info('Цикл обработки всех ящиков завершен - пауза 10 секунд и перезапуск скрипта');
      await new Promise(resolve => setTimeout(resolve, 10000));
      process.exit(0);
      
    } catch (err) {
      logger.error('Критическая ошибка в главном цикле:', err);
      process.exit(1);
    }
  }
}

// Запуск скрипта
processAllMailboxes();

// Экспорт функций для тестирования
module.exports = {
  connectToMailbox,
  searchEmails,
  fetchEmail,
  processEmailsForMailbox,
  processAllMailboxes
}; 

async function processAttachment(attachments, structuredData) {
  logger.info('Attachments:');
  for (const attachment of attachments) {
    if (attachment.filename.toLowerCase().endsWith('.xlsx')) {
      logger.info(`Обработка XLSX файла: ${attachment.filename}`);
      structuredData = await parseXLSX(attachment.content);
      if (structuredData && structuredData.length) {
        logger.info('В XLSX найдено :' + structuredData.length + ' строк с заголовками');
        logger.info(Object.keys(structuredData[0]));
        for (let item of structuredData) {
          if (item.pn_alt) {
            const altPartNumbersText = item.pn_alt.length > 0 ? `Alt P/N: ${item.pn_alt.join(', ')}` : '';
            const remarksText = [item.remarks, altPartNumbersText].filter(Boolean).join('; ');
            item.remarks = remarksText;
          }
        }
        // Здесь можно добавить дополнительную обработку данных
      }
    }
  }
  return structuredData;
}
