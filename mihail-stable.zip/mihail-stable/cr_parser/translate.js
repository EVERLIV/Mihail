// Загрузка переменных окружения из .env файла
require('dotenv').config({ path: '../.env' });
require('dotenv').config();
const OpenAI = require('openai');
const { HttpsProxyAgent } = require('https-proxy-agent');
const { logger } = require('./logger.js');

async function translate(sentence) {
    const openai = new OpenAI({
        baseURL: process.env.DEEPSEEK_API_URL,
        apiKey: process.env.DEEPSEEK_API_KEY,
        //httpAgent: proxyAgentDeepseek
    });
    try {
        const completion = await openai.chat.completions.create({
            model: "deepseek-chat",
            messages: [
                {
                    role: "system",
                    content: "You are an AI assistant specializing in translating aviation parts names from Russian to English. \
                    Your task is to translate the part name from Russian to English.\
                    Do not add anything to the answer, like 'Output:' \
                     You will receive a  part name on Russian as Input and you need to translate it to English. \
                     You can sometime receive an english partname but it will contain one or more cyrillic letters looking like latin \
                     - just change those letters to latin. Please return only the translated part name in English. Use only aviation parts names."
                },
                {
                    role: "user",
                    content: `Input:${sentence}`
                }
            ],
            temperature: 1,
            max_tokens: 2000,
            // response_format: { type: "json_object" }
        });

        let responseText = completion.choices[0].message.content;
        logger.info('Ответ от Deepseek:' + responseText);

        return responseText;

    } catch (error) {
        logger.error('Ошибка при обработке письма через Deepseek API:', JSON.stringify(error));
        throw error;
    }
}

function containsCyrillic(text) {
 
  let result = /[а-яА-ЯЁё]/.test(text);
  if (result) {
    logger.info('Part description содержит кириллицу');
    logger.info(text);
  }
  return result;
}

async function translateRequest(requestData) {
    logger.info('Переводим письмо с Deepseek API:');

    let translatedData = [];
    for (item of requestData) {
        let needsTranslation = false;
        
        if (containsCyrillic(item.description)) {
            logger.info('Описание детали содержит кириллицу - переводим');
            let translationResult = await translate(item.description);
            if (translationResult) {
                item.description = translationResult.toUpperCase();
                needsTranslation = true;
            }
        }
        
        if (containsCyrillic(item.part_number)) {
            logger.info('Номер детали содержит кириллицу - переводим');
            let translationResult = await translate(item.part_number);
            if (translationResult) {
                item.part_number = translationResult.toUpperCase();
                needsTranslation = true;
            }
        }
        
        if (needsTranslation) {
            logger.info('Переведенные данные детали: ');
            logger.info(item);
        }
        
        translatedData.push(item);
    }

    return translatedData;

    // Создаем прокси агент
    //const proxyUrl = `http://${process.env.CLAUDE_PROXY}:${process.env.CLAUDE_PORT}`;
    //const proxyAgentDeepseek = new HttpsProxyAgent(proxyUrl);



}

module.exports = {
    translateRequest
}; 

