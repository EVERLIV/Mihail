function createImapSearchStructure(domains) {
    // Если нет доменов, возвращаем пустой массив
    if (!domains || domains.length === 0) return [];
    
    // Если только один домен, возвращаем простую структуру
    if (domains.length === 1) {
      return ['FROM', domains[0]];
    }
  
    // Разбиваем на пары
    const pairs = [];
    for (let i = 0; i < domains.length; i += 2) {
      if (i + 1 < domains.length) {
        pairs.push(['OR', ['FROM', domains[i]], ['FROM', domains[i + 1]]]);
      } else {
        pairs.push(['FROM', domains[i]]);
      }
    }
  
    // Если только одна пара, возвращаем её
    if (pairs.length === 1) return pairs[0];
  
    // Объединяем пары в структуру
    let result = pairs[0];
    for (let i = 1; i < pairs.length; i++) {
      result = ['OR', result, pairs[i]];
    }
  
    return result;
  }

  const domains = [
    '@s7.ru',
    '@aeroflot.ru',
    'flysmartavia.com',
    '@airquotation.com',
    'nordwindairlines.ru',
    '@u6.ru',
    '@azurair.ru',
  ];
  
  const searchStructure = createImapSearchStructure(domains);


  console.log(JSON.stringify(searchStructure, null, 2));