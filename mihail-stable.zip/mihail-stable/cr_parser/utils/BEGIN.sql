BEGIN;

-- Set the transaction to not abort on errors
SET LOCAL statement_timeout = 0;

-- First identify the duplicate records
CREATE TEMP TABLE duplicate_ids AS
WITH DuplicatesCTE AS (
    SELECT
        cr.id AS customer_request_id,
        cr.description,
        cr.request_number,
        cr.part_number,
        cr.from_email,
        ROW_NUMBER() OVER (PARTITION BY cr.description, cr.request_number, cr.part_number, cr.from_email ORDER BY cr.id ASC) as rn
    FROM
        customers_requests cr
    WHERE
        cr.request_date >= CURRENT_DATE - INTERVAL '13 days'
        AND remarks LIKE '%sales@sprollc.com%'
),
PotentialDeletesCTE AS (
    SELECT
        customer_request_id
    FROM
        DuplicatesCTE
    WHERE
        rn > 1
)
SELECT
    p.customer_request_id AS record_id_to_delete
FROM
    PotentialDeletesCTE p
WHERE
    NOT EXISTS (
        SELECT 1
        FROM
            suppliers_proposals sp
        WHERE
            sp.customer_request_id = p.customer_request_id
    );

-- Try to delete quotation_requests first (errors will be reported but not abort the transaction)
DELETE FROM quotation_requests
WHERE customer_request IN (SELECT record_id_to_delete FROM duplicate_ids);

-- Try to delete customers_requests (errors will be reported but not abort the transaction)
DELETE FROM customers_requests
WHERE id IN (SELECT record_id_to_delete FROM duplicate_ids);

-- Clean up
DROP TABLE duplicate_ids;

-- Commit all changes that succeeded
COMMIT;