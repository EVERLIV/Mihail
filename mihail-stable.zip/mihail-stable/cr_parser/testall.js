// Загрузка переменных окружения из .env файла
require('dotenv').config({ path: '../.env' });
require('dotenv').config();
const Imap = require('imap');
const XLSX = require('xlsx');

const { simpleParser } = require('mailparser');
const { processEmailWithDeepseek } = require('./deepseek.js');
const { parseAirQuotationEmail } = require('./airquotation_parser');
const { aeroflotParser } = require('./aeroflot_parser.js');
const { azurParser } = require('./azur_parser.js');
const { aeroflotTableParser } = require('./aeroflot_table.js');
const { yamalParser } = require('./yamal_parser.js');
const { s7parser } = require('./s7_parser.js');
const { atechParser } = require('./atechnics_parser.js');
const { simpleTableParser } = require('./simple_table.js');
const { iflyParser } = require('./ifly_parser.js');
const { translateRequest } = require('./translate.js');
const { sendCR } = require('./sendcr.js');
const { MongoClient } = require('mongodb');
const { logger, skippedLogger } = require('./logger');
const { lukoilParser } = require('./lukoil_parser.js');


// Функция для проверки наличия кириллицы в тексте
function containsCyrillic(text) {
  let result = /[а-яА-ЯЁё]/.test(text);
  if (result) {
    logger.info('Заказ содержит кириллицу');
    logger.info(text);
  }
  return result;
}

// Конфигурация IMAP
const imapConfig = {
  user: process.env.EMAIL_USER,
  password: process.env.EMAIL_PASSWORD,
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT || 993,
  tls: true,
  tlsOptions: { rejectUnauthorized: false }
};

const domains = [
  // '@s7.ru',
  //'@aeroflot.ru',
  // 'flysmartavia.com',
  //'@airquotation.com',
   //'nordwindairlines.ru',
   //'@u6.ru',
  // '@azurair.ru',
  // 'yamalaero',
  //'atechnics.ru',
  //'iflyltd.ru',
  //'flyredwings.com',
  // 'yakutia.aero',
  // 'aviastartu.ru',
  // 'izhavia',
  // 'rossiya-airlines.com',
   //'tulparair.ru',
  // 'tulpar.aero',
  //'lukoil.com',
   
    //'severstal-avia.com',
   //'dreamjet',
   //'jetica',
    //'407technics.by',
   // 'polar.aero',
   // 'alliancemn.com',
   // 'utg.aero',
   // 'l39engineering.com',
   // 'uvtaero.ru',
   // 'alliance-mngroup.ru',
    //'velparts.com',
    'vd-technics.com',

  
];

// Функция для подключения к почтовому ящику
function connectToMailbox() {
  return new Promise((resolve, reject) => {
    const imap = new Imap(imapConfig);

    imap.once('ready', () => {
      imap.openBox('INBOX', false, (err, box) => {
        if (err) {
          imap.end();
          return reject(err);
        }
        resolve(imap);
      });
    });

    imap.once('error', (err) => {
      reject(err);
    });

    imap.connect();
  });
}

// Функция для поиска писем по критериям
function searchEmails(imap, criteria) {
  return new Promise((resolve, reject) => {
    imap.search(criteria, (err, results) => {
      if (err) return reject(err);
      // Сортируем результаты по убыванию (сначала новые)
      results.sort((a, b) => b - a);
      resolve(results);
    });
  });
}

// Функция для получения содержимого письма
function fetchEmail(imap, uid) {
  return new Promise((resolve, reject) => {
    const fetch = imap.fetch(uid, { bodies: '', markSeen: false });

    fetch.on('message', (msg) => {
      let buffer = '';

      msg.on('body', (stream) => {
        stream.on('data', (chunk) => {
          buffer += chunk.toString('utf8');
        });

        stream.on('end', () => {
          simpleParser(buffer)
            .then(parsed => {
              resolve({
                uid: uid,
                parsed: parsed,
                messageId: parsed.messageId
              });
            })
            .catch(err => reject(err));
        });
      });

      msg.on('error', (err) => {
        reject(err);
      });
    });

    fetch.on('error', (err) => {
      reject(err);
    });
  });
}

// Функция для форматирования даты в YYYY-MM-DD
function formatDate(date, daysToAdd = 0) {
  const d = new Date(date);
  d.setDate(d.getDate() + daysToAdd);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

const mongourl = process.env.MONGODB_URL;
const dbName = process.env.MONGO_DB;

// Функция для пометки письма как прочитанного


function cleanEmailText(text) {
  if (text) {
    return text
      .replace(/–/g, '-')
      .replace(/\[http:[^\]]+\]/g, '')
      // Удаляем встроенные изображения (base64)
      .replace(/data:image\/[^;]+;base64,[^\s]+/g, '')
      // Удаляем ссылки на изображения
      .replace(/https?:\/\/[^\s]+\.(jpg|jpeg|png|gif|bmp|svg)/gi, '')
      // Удаляем HTML-теги для изображений
      .replace(/<img[^>]+>/g, '')
      // Удаляем style-блоки вместе с содержимым
      .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
      .replace(/<head\b[^<]*(?:(?!<\/head>)<[^<]*)*<\/head>/gi, '')
      // Удаляем iframe-теги вместе с содержимым
      .replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, '')
      // Удаляем любые URL в угловых скобках
      .replace(/<https?:\/\/[^>]+>/gi, '')
      // Удаляем всё после "Original Message"
      // .replace(/Thank you in advance![\s\S]*$/i, '')
      .replace(/This document may contain[\s\S]*$/i, '')
      .replace(/Best regards[^]*/i, '')
      .replace(/С уважением[^]*/i, '')
      .replace(/Original Message[^]*/i, '')
      // Удаляем специальные символы Unicode, кроме переносов строк
      .replace(/[\u0000-\u0009\u000B-\u001F\u007F-\u009F]/g, '')
      .trim();
  } else {
    return '';
  }
}

function createImapSearchStructure(domains) {
  // Если нет доменов, возвращаем пустой массив
  if (!domains || domains.length === 0) return [];

  // Если только один домен, возвращаем простую структуру
  if (domains.length === 1) {
    return ['FROM', domains[0]];
  }

  // Разбиваем на пары
  const pairs = [];
  for (let i = 0; i < domains.length; i += 2) {
    if (i + 1 < domains.length) {
      pairs.push(['OR', ['FROM', domains[i]], ['FROM', domains[i + 1]]]);
    } else {
      pairs.push(['FROM', domains[i]]);
    }
  }

  // Если только одна пара, возвращаем её
  if (pairs.length === 1) return pairs[0];

  // Объединяем пары в структуру
  let result = pairs[0];
  for (let i = 1; i < pairs.length; i++) {
    result = ['OR', result, pairs[i]];
  }

  return result;
}



async function parseXLSX(buffer) {
  try {
    const workbook = XLSX.read(buffer, { type: 'buffer' });
    const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
    let rows = XLSX.utils.sheet_to_json(firstSheet);
    // Нормализация ключей
    rows = rows.map(normalizeXLSXRow);
    return rows;
  } catch (error) {
    logger.error('Ошибка при парсинге XLSX файла:', error);
    return null;
  }
}

// Нормализация ключей для XLSX-объектов
function normalizeXLSXRow(row) {
  // Сопоставление возможных заголовков с целевыми ключами (все ключи в верхнем регистре)
  const map = {
    'PN': 'part_number',
    'P/N': 'part_number',
    'PART NUMBER': 'part_number',
    'PART NUMBER:': 'part_number',
    'PART NO.': 'part_number',
    'PART NO': 'part_number',
    'DESCR': 'description',
    'DESCRIPTION': 'description',
    'DESCRIPTION:': 'description',
    'Q-TY': 'qty',
    'QTY': 'qty',
    'QTY.': 'qty',
    'QT': 'qty',
    'QUANTITY': 'qty',
    'КОЛ-ВО': 'qty',
    'UOM': 'um',
    'UM': 'um',
    'MU': 'um',
    'EXT. MEASURE UNIT': 'um',
    'EXT MEASURE UNIT': 'um',
    'MEASURE': 'um',
    'KNOWN ALT': 'pn_alt',
    'ALT P/N': 'pn_alt',
    'ALT': 'pn_alt',
    'ALT1': 'pn_alt',
    'ALT2': 'pn_alt',
    'ALT3': 'pn_alt',
    'ALT4': 'pn_alt',
    'ALT5': 'pn_alt',
    'ALTS': 'pn_alt',
    'REMARKS': 'remarks',
    'PRIORITY': 'priority',
    'AC TYPE': 'ac_type',
    'AC': 'ac_type',
    'A/C': 'ac_type',
    'F/A TYPE': 'ac_type',
    'F/A': 'ac_type',
   
  };
  const normalized = {};
  let alts = [];
  for (const key in row) {
    const normKey = map[key.trim().toUpperCase()];
    if (normKey === 'pn_alt') {
      // Собираем все ALT в массив
      alts.push(row[key]);
    }
    if (normKey) {
      normalized[normKey] = row[key];
    }
  }
  // pn_alt всегда массив всех найденных ALT
  if (alts.length) {
    normalized.pn_alt = alts
      .flatMap(alt => typeof alt === 'string' ? alt.split(/[,;\n]/) : [alt])
      .map(s => String(s).trim())
      .filter(Boolean);
  }
  // Гарантируем, что part_number всегда строка
  if (normalized.part_number !== undefined && normalized.part_number !== null) {
    // Заменяем все похожие на дефис символы на обычный дефис
    normalized.part_number = String(normalized.part_number)
      .replace(/[−–—‒―﹘﹣－]/g, '-') // длинное тире, минус и др.
      .trim();
  }
  return normalized;
}


async function processAttachment(attachments, structuredData) {
  logger.info('Attachments:');
  for (const attachment of attachments) {
    if (attachment.filename.toLowerCase().endsWith('.xlsx')) {
      logger.info(`Обработка XLSX файла: ${attachment.filename}`);
      structuredData = await parseXLSX(attachment.content);
      if (structuredData && structuredData.length) {
        logger.info('В XLSX найдено :' + structuredData.length + ' строк с заголовками');
        logger.info(Object.keys(structuredData[0]));
        for (let item of structuredData) {
          if (item.pn_alt) {
            const altPartNumbersText = item.pn_alt.length > 0 ? `Alt P/N: ${item.pn_alt.join(', ')}` : '';
            const remarksText = [item.remarks, altPartNumbersText].filter(Boolean).join('; ');
            item.remarks = remarksText;
          }
        }
        // Здесь можно добавить дополнительную обработку данных
      }
    }
  }
  return structuredData;
}


// Основная функция для обработки писем
async function processEmails() {
  let imap;
  try {
    skippedLogger.info('Подключение к почтовому ящику...');
    imap = await connectToMailbox();
    skippedLogger.info('Подключение успешно установлено');

    const searchStructure = createImapSearchStructure(domains);    // if (process.env.ENVIRONMENT === 'production') {
    // Критерии поиска писем
    searchCriteria = [
      searchStructure,
      ['SINCE', new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()],
     ['SUBJECT', 'RFQ engine inspection'],
     // ['FLAGGED']
    ];


    // Поиск писем по критериям
    const uids = await searchEmails(imap, searchCriteria);
    skippedLogger.info(`Найдено ${uids.length} писем, соответствующих критериям`);

    // Обработка каждого найденного письма
    for (const uid of uids) {
      try {
        const email = await fetchEmail(imap, uid);
        const { from, subject, text, html, messageId, date, attachments } = email.parsed;
        logger.info(subject);

        
        // Пропускаем письма, которые являются ответами
        if (subject?.toUpperCase().startsWith('RE:') ||
            (subject && /(?:прошу.*(?:выслать|предоставить|направить).*сертификат|просьба.*(?:выслать|направить).*сертификат|прошу.*принять.*в.*работу.*новый.*заказ|квотация|планируем.*разместить.*заказ)/i.test(subject.replace(/\s+/g, ' '))) ||
            (text && /(?:прошу.*(?:выслать|предоставить|направить).*сертификат|просьба.*(?:выслать|направить).*сертификат|прошу.*заказ.*новый|планируем.*разместить.*заказ)/i.test(text.replace(/\s+/g, ' ')))
        ) {
          skippedLogger.info(`Пропускаем письмо ${subject}`);
          continue;
        }

        // Создаем объект с извлеченными данными
        const extractedData = {
          messageId: messageId,
          date: date,
          subject: subject,
          from: from?.value?.[0]?.address,
          text: text || html
        };

        let requestNumber = subject// + ' ' + date.toLocaleString('ru-RU', { timeZone: 'Europe/Moscow' })
       
        // Выводим извлеченные данные
        //---------------------------------------------------------------------------------
        let structuredData;
        let fromAddress = from.value?.[0]?.address;
        //----------------------------------------------------------------------------------------
        if ([
          'vd-technics.com',
        ].some(domain => fromAddress.includes(domain))) {
          logger.info('Парсинг письма от ' + fromAddress)
          logger.info(subject);
          structuredData = azurParser(cleanEmailText(html), subject);
          if (!structuredData || structuredData.length === 0) {
            structuredData = await processEmailWithDeepseek(cleanEmailText(html), subject)
          }
          if (
            structuredData?.some(part => part.error)
          ) {
            throw new Error('Найдены ошибки в структурированных данных после всех попыток');
          }
        }
          console.log(structuredData)
        //---------------------------------------------------------------------------------
        // проверяем на недопустимые символы в номере детали
        if (structuredData && containsCyrillic(structuredData.map(part => part.description).join(' '))) {
          logger.info('Заказ содержит кириллицу - передаем переводчику');
          let translationResult = await translateRequest(structuredData);
          if (translationResult) {
            structuredData = translationResult;
          }
        }

        // Убеждаемся, что structuredData - это массив
        if (structuredData && structuredData.some(part => !/^[A-Za-z0-9\-/]+$/.test(part.part_number))) {
          logger.info('Найдены недопустимые символы в номере детали - передаем в deepseek');

          let goodPart = structuredData.filter(part => /^[A-Za-z0-9\-/]+$/.test(part.part_number));
          let badPart = structuredData.filter(part => !/^[A-Za-z0-9\-/]+$/.test(part.part_number) || /[\r\n]/.test(JSON.stringify(part)));

          logger.info(badPart.map(part => part.part_number));

          let deepOutput = [];
          for (let item of badPart) {
            let deepInput = '';
            for (let field of Object.keys(item)) {
              deepInput += `${field}: ${item[field]}\n`;
            }
            logger.info('-----Deepinput-----' + deepInput);
            let resp = await processEmailWithDeepseek(deepInput, subject);
            if (Array.isArray(resp) && resp.length && !resp.error) {
              deepOutput.push(...resp);
            }
          }
          structuredData = [...goodPart, ...deepOutput];
          if (
            structuredData && structuredData.some(part => part.error)
          ) {
            throw new Error('Ошибка при парсинге письма с Deepseek');
          }
        }

        for (let item of structuredData) {
          let priorityField = item.priority?.toLowerCase().includes('urgent') ? 'AOG'
          : item.priority?.toLowerCase().includes('aog') ? 'AOG'
            : item.priority?.toLowerCase().includes('routine') ? 'RTN'
              : item.priority?.toLowerCase().includes('replenishment') ? 'USR'
                : item.priority?.toLowerCase().includes('crit') ? 'WSP' : item.priority
        item.priority =
          ['AOG', 'RTN', 'USR', 'WSP'].some(elem => elem === priorityField) ?
            priorityField : 'RTN'

        if ( fromAddress.toUpperCase().includes('AOG@')) {
          item.priority = 'AOG'
        }

        if (item.um?.toUpperCase() === 'RL') {
          item.um = 'RO';
        }
        if (item.um?.toUpperCase() === 'LT') {
          item.um = 'L';
        }
        if (!["EA", "FT", "M", "YD", "KG", "LB", "G", "L", "OZ", "RO", "KT", "CA", "QT"].includes(item.um?.toUpperCase())) {
          item.um = 'EA';
        }
      }
        logger.info(structuredData);



   //// Отправляем в Pantheon
   let pantheonResult = true//await sendCR({
   // rfq_details: structuredData
  //})
            //// Если отправка успешна, сохраняем в MongoDB и помечаем письмо как прочитанное
          if (pantheonResult) {
            if (pantheonResult.ok) {
              logger.info('Отправка в Pantheon имитирована')
              //await markEmailAsRead(imap, uid);
            } else {
              logger.info('Отправка в Pantheon с ошибкой')
              logger.error(pantheonResult)
              // if error: 'auth_failed' wait 10 seconds and try again

            }
          
          } else {
            logger.error('Отправка в Pantheon не успешна')
          }
       
        

      } catch (err) {
        logger.error(`Ошибка при обработке письма ${uid}:`, err);
      }
    }

  } catch (err) {
    logger.error('Произошла ошибка:', err);
  } finally {
    if (imap && imap.state !== 'disconnected') {
      imap.end();
      skippedLogger.info('Соединение закрыто - пауза 10 секунд');
      setTimeout(() => {
        skippedLogger.info('Перезапуск скрипта');
      }, 10000);
    }
  }
}

// Запуск скрипта
processEmails();

// Экспорт функций для тестирования
module.exports = {
  connectToMailbox,
  searchEmails,
  fetchEmail,
  processEmails
}; 