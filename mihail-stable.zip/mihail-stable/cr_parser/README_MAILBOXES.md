# Настройка нескольких почтовых ящиков

Скрипт поддерживает обработку нескольких почтовых ящиков последовательно.

## Переменные окружения

### Настройка почтовых ящиков
Можно настроить до 11 почтовых ящиков, используя переменные с номерами от 0 до 10:

```
# Ящик 0
EMAIL_USER0=user0@example.com
EMAIL_PASSWORD0=password0
EMAIL_HOST0=imap.example.com  # Опционально, если не указан - используется EMAIL_HOST
EMAIL_PORT0=993               # Опционально, если не указан - используется EMAIL_PORT

# Ящик 1
EMAIL_USER1=user1@example.com
EMAIL_PASSWORD1=password1
EMAIL_HOST1=imap.example.com
EMAIL_PORT1=993

# Ящик 2
EMAIL_USER2=user2@example.com
EMAIL_PASSWORD2=password2
EMAIL_HOST2=imap2.example.com
EMAIL_PORT2=993

# И так далее до EMAIL_USER10/EMAIL_PASSWORD10
```

### Общие настройки
```
# Используются как значения по умолчанию для HOST и PORT
EMAIL_HOST=imap.example.com
EMAIL_PORT=993

# Другие переменные
MONGODB_URL=mongodb://localhost:27018
MONGO_DB=vendorsDB
```

## Логика работы

1. Скрипт автоматически определяет количество настроенных ящиков (EMAIL_USER0, EMAIL_USER1, и т.д.)
2. Обрабатывает их последовательно в бесконечном цикле
3. После обработки всех ящиков делает паузу 10 секунд
4. Между обработкой отдельных ящиков - пауза 5 секунд
5. При ошибках в отдельном ящике - продолжает работу с остальными
6. При критических ошибках - пауза 30 секунд

## Логирование

В логах будет указываться:
- Название ящика (например, "Ящик 0", "Ящик 1")
- Email адрес ящика
- Статус обработки каждого ящика

## Пример настройки

```bash
# В файле .env
EMAIL_HOST=imap.gmail.com
EMAIL_PORT=993

EMAIL_USER0=orders@company.com
EMAIL_PASSWORD0=pass1

EMAIL_USER1=support@company.com
EMAIL_PASSWORD1=pass2

EMAIL_USER2=sales@company.com
EMAIL_PASSWORD2=pass3
EMAIL_HOST2=imap.outlook.com
```

Этот пример настроит обработку 3 почтовых ящиков. 