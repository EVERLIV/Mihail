require('dotenv').config()
require('dotenv').config({ path: '../.env' }); // загружает .env из родительской директории

// const { MongoClient } = require('mongodb');
const {
    saveVendorToMongoDB,
    saveStatistics,
    saveProcessedOrder,
    getUnprocessedOrders,
    getStatistics,
    getRecentStatistics
} = require('./db');

const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const express = require('express');
const app = express();
// app.use(bodyParser.json());
app.use(express.json({ limit: "10mb", extended: true }))
app.use(express.urlencoded({ limit: "10mb", extended: true, parameterLimit: 50000 }))

const {
    createLogger,
    randomDelay,
    //saveCookies,
    //loadCookies,
    addDaysToDate
} = require('./lib');

// Инициализация логгера
global.logger = createLogger();


const { hideHeadless } = require('./hideheadless')
puppeteer.use(StealthPlugin());

var STATE = {
    busy: true,
}

const blacklist = require('./blacklist');
// Configuration
const config = {
    baseUrl: process.env.PANTHEON_API_URL,
    getOrdersUrl: process.env.GETORDERSURL,
    authToken: process.env.API_AUTH_TOKEN,
    searchURL: process.env.STOCKMARKETURL,
    username: process.env.STOCKMARKETLOGIN,
    password: process.env.STOCKMARKETPASSWORD,
    outputDir: './output',
    dataFolder: './browsercache', // добавляем папку для данных браузера
    orderNumber: 'xxx', // номер заказа
    defaultQuantity: 3, // стандартное количество для заказа
    backInTimeDays: 7, // количество дней назад для заказа
    evenOrders: process.env.EVEN_ORDERS == 1 ? true : false, // Обрабатываем четные (true) или нечетные (false) заказы
    // Delay ranges in milliseconds
    proxyServer: "194.156.99.28",
    proxyport: "8000",
    proxyusername: "hkproxy",
    proxypassword: "fh9384hoF",
    delays: {
        typing: { min: 50, max: 100 },
        navigation: { min: 500, max: 2000 },
        clicking: { min: 100, max: 500 }
    },
    blacklist: blacklist
};

async function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

const getOrders = async () => {
    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 30000); // 30 секунд таймаут

        const response = await fetch(`${config.baseUrl}${config.getOrdersUrl}`, {
            method: 'GET',
            headers: {
                'Authorization': config.authToken,
                'Content-Type': 'application/json'
            },
            signal: controller.signal
        });

        clearTimeout(timeout);

        if (!response.ok) {
            throw new Error(`API returned status code ${response.status}`);
        }

        const data = await response.json();
        const filteredOrders = data.filter(order => order.quote_id > 0);
        const unprocessedOrders = await getUnprocessedOrders(filteredOrders);
        
        
            // Определяем порядок приоритетов
        const priorityOrder = {
            'AOG': 1,
            'WSP': 2,
            'USR': 3,
            'RTN': 4
        };

        // Сортируем заказы по приоритету
        const sortedOrders = unprocessedOrders.sort((a, b) => {
            const priorityA = priorityOrder[a.priority] || 5; // Если приоритет не определен, ставим в конец
            const priorityB = priorityOrder[b.priority] || 5;
            return priorityA - priorityB;
        });

        // Считаем статистику по приоритетам
        const stats = {
            'AOG': 0,
            'WSP': 0,
            'USR': 0,
            'RTN': 0,
            'OTHER': 0
        };

        sortedOrders.forEach(order => {
            if (order.priority in stats) {
                stats[order.priority]++;
            } else {
                stats.OTHER++;
            }
        });

        // Выводим статистику
        console.log('\nСтатистика заказов по приоритетам:');
        console.log('--------------------------------');
        console.log(`AOG: ${stats.AOG}`);
        console.log(`WSP: ${stats.WSP}`);
        console.log(`USR: ${stats.USR}`);
        console.log(`RTN: ${stats.RTN}`);
        console.log(`Другие приоритеты: ${stats.OTHER}`);
        console.log('--------------------------------\n');
        

        console.log(new Date(), `Получено ${filteredOrders.length} заказов`);
        console.log(new Date(), `Обрабатываем ${config.evenOrders ? 'четные' : 'нечетные'} заказы по ID`);
        let returnOrders = sortedOrders.filter(order => config.evenOrders ? order.id % 2 === 0 : order.id % 2 !== 0);
        console.log(new Date(), `Обрабатываем ${sortedOrders.length} заказов`);
        
        return returnOrders;

    } catch (error) {
        if (error.name === 'AbortError') {
            console.log(new Date(), 'Request timeout when fetching orders from API');
            throw new Error('Request timeout');
        }

        console.log(new Date(), 'Error fetching orders from API:', {
            error: error.message,
            stack: error.stack
        });
        throw error;
    }
}

// Извлекаемм данные из html таблыцы
async function extractTableData(page, order, orderIndex, totalOrders) {
    const vendorsResult = await page.evaluate(() => {
        let result = [];
        let currentVendor = null;
        let headers = null;
        const rows = Array.from(document.querySelectorAll('tr'));

        let counter = 0;
        for (let row of rows) {
            if (row.id && row.id.startsWith('grp')) {
                counter = 0;
                currentVendor = {
                    vendor: {
                        name: row.querySelector('.vendname')?.textContent.trim() || '',
                        location: row.querySelector('td[width="30%"] td[style*="width: 79%"]')?.textContent.trim() || ''
                    }
                };
                headers = null;
                console.log(new Date(), 'Processing vendor:', currentVendor.vendor.name);
            }
            else if (row.classList.length > 0 && row.querySelectorAll('td').length > 0 && !headers) {
                headers = Array.from(row.querySelectorAll('td'))
                    .map(td => td.textContent.trim())
                    .filter(header => header !== 'Send RFQ' && header !== 'Place PO Offer');
            }
            else if (row.classList.length > 0 && headers && currentVendor && !row.id && counter === 0) {
                counter = counter + 1;
                const cells = row.querySelectorAll('td.cell');
                if (cells.length > 0) {
                    const firstLink = cells[0]?.querySelector('a');
                    if (firstLink) {
                        currentVendor.clickSelector = `#${firstLink.id}`;
                        if (currentVendor) {
                            result.push(currentVendor);
                        }
                    }
                }
            }
        }
        return result.filter((vendor, index, self) =>
            index === self.findIndex(v => v.vendor.name === vendor.vendor.name)
        );
    });

    logger.info(`Заказ ${orderIndex} из ${totalOrders}: ${vendorsResult?.length} предложений поставщика`);

    if (vendorsResult.length > 0) {
        for (const [index, vendor] of vendorsResult.entries()) {
            try {
                if (vendor.clickSelector) {
                    await randomDelay(1000, 2000);
                    
                    // Добавляем проверку видимости элемента перед кликом
                    const element = await page.$(vendor.clickSelector);
                    if (!element) {
                        logger.info(`Элемент ${vendor.clickSelector} не найден`);
                        continue;
                    }

                    // Проверяем, видим ли элемент
                    const isVisible = await page.evaluate((selector) => {
                        const el = document.querySelector(selector);
                        if (!el) return false;
                        const style = window.getComputedStyle(el);
                        return style && style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0';
                    }, vendor.clickSelector);

                    if (!isVisible) {
                        logger.info(`Элемент ${vendor.clickSelector} не видим`);
                        continue;
                    }

                    // Прокручиваем к элементу перед кликом
                    await page.evaluate((selector) => {
                        const element = document.querySelector(selector);
                        if (element) {
                            element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        }
                    }, vendor.clickSelector);

                    await randomDelay(1000, 2000);

                    try {
                        // Пробуем кликнуть с помощью JavaScript
                        const clickSuccess = await page.evaluate((selector) => {
                            const element = document.querySelector(selector);
                            if (element) {
                                element.click();
                                return true;
                            }
                            return false;
                        }, vendor.clickSelector);

                        if (!clickSuccess) {
                            // Если JavaScript клик не сработал, пробуем через Puppeteer
                            await page.click(vendor.clickSelector, { 
                                delay: 100,
                                timeout: 5000 
                            }).catch(err => {
                                logger.info(`Ошибка при клике на ссылку vendor ${vendor.vendor.name}:`, err);
                                throw err;
                            });
                        }
                    } catch (err) {
                        logger.info(`Ошибка при клике на элемент ${vendor.clickSelector}:`, err);
                        continue; // Пропускаем текущего вендора и переходим к следующему
                    }

                    await randomDelay(1000, 2000);

                    // Ждем появления диалога
                    let uiDialog = await page.waitForSelector('div.ui-dialog')
                        .catch(async err => {
                            logger.info('Ошибка при ожидании появления диалога:', err)
                            await page.screenshot({
                                path: './screenshots/' + new Date().toISOString() + 'errordialogclick.png',
                                type: 'png',
                                fullPage: true
                            })
                            await browser.close();
                            process.exit(1);
                        });

                    // Получаем данные из vd div

                    if (uiDialog) {
                        const vdData = await uiDialog.evaluate(async () => {

                            // Кликаем по заголовку Contact Details
                            const contactHeader = await document.querySelector('h3[onclick*="displayVendorDetail"]');
                            if (contactHeader) {
                                await contactHeader.click();
                                await new Promise(resolve => setTimeout(resolve, 1000));
                            }

                            const vendorDiv = document.querySelector('#vendor');
                            if (vendorDiv) {
                                // Собираем все ячейки
                                const cells = Array.from(vendorDiv.querySelectorAll('td'));

                                // Создаем объект с данными
                                const contactData = {};
                                for (let i = 0; i < cells.length; i += 2) {
                                    // Убираем двоеточие из ключа и конвертируем в camelCase
                                    const key = cells[i].textContent.trim()
                                        .replace(':', '')
                                        .replace(/\s+(.)/g, (_, c) => c.toUpperCase());
                                    const value = cells[i + 1]?.textContent.trim() || '';

                                    // Добавляем только непустые значения
                                    if (value) {
                                        contactData[key] = value;
                                    }
                                }

                                return contactData;
                            }
                            return null;
                        });


                        if (vdData) {

                            // Сохраняем данные в MongoDB
                            await saveVendorToMongoDB(vdData);

                            //logger.info(new Date(), 'Detail data:', vdData);
                        } else {
                            return
                        }

                        // Заполняем форму RFQ
                        const hasRecentStatistics = await getRecentStatistics(
                            order.part_number,
                            vdData.EmailAddress
                        );
                            // Заполняем форму RFQ
                            await page.waitForSelector('#rfqdiv').catch(err => logger.info('Ошибка при ожидании появления #rfqdiv', err));
                            const formHeader = await page.waitForSelector('h3#rfqh3', { timeout: 15000 }).catch(err => logger.info('Ошибка при ожидании появления h3#rfqh3', err));
                            if (formHeader) {
                                {
                                    await randomDelay(2000, 3000);
                                    await formHeader.click().catch(async err => {
                                        logger.info('Ошибка при клике на заголовок формы:', err)
                                        await page.screenshot({
                                            path: './screenshots/' + new Date().toISOString() + 'errordialogclick.png',
                                            type: 'png',
                                            fullPage: true
                                        })
                                        await browser.close();
                                        console.log(new Date(), 'Закрываем браузер и перезапускаем скрипт')
                                        process.exit(1);
                                    });
                                    await randomDelay(2000, 3000);
                                }
                            }
                            //очищаем значения             
                       
                        await page.evaluate(({ orderNumber, quantity, needby }) => {
                            const refNumberInput = document.querySelector('input[name="refNumber"]');
                            const quantityInput = document.querySelector('input[name="quanitity"]'); //'#rfqdiv > table > tbody > tr:nth-child(5) > td:nth-child(2) > input'
                            const dateInput = document.querySelector('input#needBy');

                            if (refNumberInput) refNumberInput.value = orderNumber;
                            if (quantityInput) quantityInput.value = quantity; // устанавливаем новое значение
                            if (dateInput) dateInput.value = needby;
                        }, {
                            orderNumber: order.id,
                            quantity: order.qty,
                            needby: addDaysToDate(order.request_date, 21)
                        });


                        // Отправляем форму

                        const submitButton = await page.waitForSelector('input[type="submit"][value="Submit RFQ"]')
                            .catch(err => logger.info('Ошибка при ожидании появления кнопки Submit RFQ', err));
                        const closeButton = await page.waitForSelector('.ui-dialog-titlebar-close')
                            .catch(err => logger.info('Ошибка при ожидании появления кнопки Close', err));
                        if (submitButton && closeButton) {
                            await randomDelay(1000, 2000);

                            // Проверяем, отправлялся ли этот email ранее по этому заказу

                            let SentEmail;
                            console.log(new Date(), vdData)
                            if (vdData.EmailAddress) {
                                SentEmail = await getStatistics(vdData.EmailAddress?.toLowerCase(), order.id)
                            }
                            console.log(new Date(), `Заказ (${order.id})) - ${orderIndex} из ${totalOrders}: Отправляю ${vdData.EmailAddress}`)
                            console.log(new Date(), SentEmail ? '-----Уже отправлялся' : 'Еще не отправлялся', vdData.EmailAddress)

                            if (!config.blacklist.some(word =>
                                    vdData?.EmailAddress?.toLowerCase().includes(word.toLowerCase()))
                                && !SentEmail && !hasRecentStatistics
                            ) {
                        
                                await submitButton.click().then(async () => {
                                    console.log(new Date(), 'Заказ', orderIndex, 'из', totalOrders, 'Отправлено', vdData.EmailAddress)
                                    await saveStatistics(order.part_number, vdData.EmailAddress?.toLowerCase(), new Date(), order.id, vdData?.VendorName);
                                }).catch(err => logger.info('Ошибка при клике на кнопку Submit RFQ', err));
                                
                                await closeButton.click().catch(err => logger.info('Ошибка при клике на кнопку Close', err));
                            } else {
                                await closeButton.click().catch(err => logger.info('Ошибка при клике на кнопку Close', err));
                                console.log(new Date(), 'Заказ', orderIndex, 'из', totalOrders, 'Имитация отправки', vdData.EmailAddress)
                            }
                            //logger.info(new Date(), 'ok - sent');
                            // Сохраняем статистику


                            // Сохраняем информацию об обработанном заказе

                            await randomDelay(1000, 2000);
                        }

                        // Закрываем диалог
                        // const closeButton = await page.waitForSelector('button.ui-dialog-titlebar-close')
                        //     .catch(err => logger.info('Ошибка при ожидании появления кнопки Close', err));
                        // if (closeButton) {
                        //     await closeButton.click();
                        //     await randomDelay(500, 1000);
                        // }

                    }
                }

            } catch (err) {
                logger.info('ошибка извлечения данных из таблицы', err)
                await page.screenshot({
                    path: './screenshots/' + new Date().toISOString() + 'errordialogclick.png',
                    type: 'png',
                    fullPage: true
                })
                process.exit(1);
            }
        }
    }
    // Фильтруем результаты, исключая вендоров с запрещенными словами
    return vendorsResult.filter(vendor =>
        !config.blacklist.some(word =>
            vendor.vendor.name?.toLowerCase().replace(/ /g, '').includes(word.toLowerCase())
        )
    );
}

// Helper function for human-like typing
async function typeHumanLike(element, text) {
    for (const char of text) {
        await element.type(char);
        await randomDelay(config.delays.typing.min, config.delays.typing.max);
    }
}

async function processOrders(page, orders) {
    STATE.busy = true;

    let loginlink;
    console.log(new Date(), 'Обрабатываем', orders.length, 'заказов')
    try {
        await page.goto(config.searchURL)
        loginlink = await page.waitForSelector('a#loginid', { timeout: 1000 })
    } catch (err) {
        console.log(new Date(), 'Залогинены норм')
    }
    if (loginlink) {
        await login(page);
    }

    for (const [index, order] of orders.entries()) {
        let hasNextPage = true;
        console.log(new Date(), 'Обрабатываем заказ', order)
        let partNumber = await page.waitForSelector('input#partNumber', { timeout: 15000 }).catch(err => {
            logger.info('Ошибка при ожидании появления input#partNumber', err)
            return null;
        });
        if (partNumber) {
            await typeHumanLike(partNumber, order.part_number);
            await randomDelay(config.delays.clicking.min, config.delays.clicking.max);
            try {
                await page.$eval("input[value='Go']", el => el.click());
                await randomDelay(3000, 5000);
            } catch (err) {
                logger.info('Ошибка при клике на кнопку Go', err)
            }
        }

        while (hasNextPage) {
            await randomDelay(config.delays.navigation.min, config.delays.navigation.max);

            // Ждем загрузки таблицы
            await page.waitForSelector('tr[id^="grp"]', { timeout: 15000 })
                .catch(err => logger.info('Нет результатов поиска'));

            // Проверяем и кликаем кнопку expand
            try {
                await page.waitForSelector('#exp_plus', { timeout: 15000 });
                await randomDelay(config.delays.clicking.min, config.delays.clicking.max);
                await page.click('#exp_plus');
                // Ждем полной загрузки развернутой таблицы
                await randomDelay(2000, 3000);
            } catch (error) {
                console.log(new Date(), `No expand button for ${order.part_number}`);
                hasNextPage = false;
            }

            // Извлекаем и обрабатываем данные с текущей страницы
            await extractTableData(page, order, index, orders.length);

            // Проверяем наличие следующей страницы ТОЛЬКО после завершения обработки текущей
            await randomDelay(1000, 2000);

            let pagerb = await page.$('#pagerb').catch(() => null);
            if (!pagerb) {
                hasNextPage = false;
                continue;
            }

            const textPagerbList = await page.$$eval(
                "#pagerb", elements => elements.map(e => e.textContent)
            ).catch(err => {
                logger.info('ошибка pagerb', err);
                hasNextPage = false;
                return [];
            });

            const textPagerb = textPagerbList.join();

            if (!textPagerb?.includes('Next')) {
                hasNextPage = false;
                continue;
            }

            // Переход на следующую страницу
            const lastTd = await page.$('#pagerb table tbody tr td:last-child');
            if (lastTd) {
                await lastTd.click();
                // Ждем загрузки новой страницы
                await randomDelay(3000, 5000);
            } else {
                hasNextPage = false;
            }
        }

        // После обработки всех страниц сохраняем заказ
        try {
            await saveProcessedOrder(
                order
            );
            console.log(new Date(), `Заказ ${order.id} успешно обработан и сохранен`);
        } catch (error) {
            console.error(`Ошибка при сохранении заказа ${order.id}:`, error);
        }

        // Очищаем поле поиска для следующей детали
        try {
            // Ждем появления поля поиска
            const searchField = await page.waitForSelector('input#partNumber', { timeout: 5000 })
                .catch(() => null);
            
            if (searchField) {
                await page.evaluate(() => {
                    const input = document.querySelector('input#partNumber');
                    if (input) {
                        input.value = '';
                    }
                }).catch(() => {
                    logger.info('Не удалось очистить поле поиска - страница была перезагружена');
                });
            }
        } catch (err) {
            logger.info('Ошибка при очистке поля поиска:', err);
        }
    }
}


async function login(page) {

    logger.info('Loggin in...')
    await page.goto('https://www.stockmarket.aero/StockMarket/LoadLogin.do');
    await randomDelay(2000, 3000);
    await page.evaluate(({ username, password }) => {
        const usernameField = document.querySelector('input[name="username"]');
        const passwordField = document.querySelector('input[name="password"]');
        const rememberMeCheckbox = document.querySelector('input[name="rememberMe"]');

        if (usernameField && passwordField) {
            usernameField.value = username;
            passwordField.value = password;
            if (rememberMeCheckbox) {
                rememberMeCheckbox.checked = true;
            }
            document.forms['loginForm'].submit();
        } else {
            throw new Error('Login form fields not found');
        }
    }, {
        username: config.username,
        password: config.password
    })
    //await saveCookies(page, config.dataFolder); // сохраняем после успешного логина
    console.log(new Date(), 'Залогинились')
}

async function main() {

    
    // Обработка завершения процесса
    process.on('SIGINT', async () => {
        process.exit();
    });

    process.on('SIGTERM', async () => {
        process.exit();
    });

    let orders = await getOrders();

    if (!orders.length) {
        logger.info('Нет заказов для обработки')
        await delay(60000);
        process.exit(0);
    }

    const browser = await puppeteer.launch({
        headless: process.env.NODE_ENV === 'production'
            ? "new"
            : false,
        defaultViewport: null,
        // executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || "/usr/bin/chromium",
        args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            `--proxy-server=http://${config.proxyServer}:${config.proxyport}`
        ],
        //userDataDir: config.reverseOrder ? './stockmarket_browsercache1' : './stockmarket_browsercache',
        //persistentContext: true
    });

    //const page = await browser.newPage();
    const page = (await browser.pages())[0];
    await page.authenticate({
        username: config.proxyusername,
        password: config.proxypassword,
    }).catch(err => logger.info('Ошибка при аутентификации', err))

    // Включаем перехват всех запросов
    // await page.setRequestInterception(true);

    // // Обработчик перехвата запросов
    // page.on('request', (request) => {
    //     // Блокируем запросы на загрузку изображений
    //     if (request.resourceType() === 'image') {
    //         request.abort(); // Прерываем загрузку
    //     } else {
    //         request.continue(); // Разрешаем остальные запросы
    //     }
    // });
    //await loadCookies(page, config.dataFolder);

    // Отлавливаем появление алерта и нажимаем кнопку
    page.on('dialog', async dialog => {
        logger.info(`Пойман диалог: ${dialog.type()} - "${dialog.message()}"`);

        if (dialog.type() === 'confirm') {
            await dialog.accept(); // Нажать "OK"
            // await dialog.dismiss(); // Нажать "Cancel"
        } else {
            await dialog.accept(); // Для alert и prompt просто закрывает
        }
    });


    await hideHeadless(page);


    try {

        await page.goto(config.searchURL);
        await randomDelay(config.delays.navigation.min, config.delays.navigation.max);

        logger.info('проверяем нужен-ли login')
        let loginlink;
        try {
            loginlink = await page.waitForSelector('a#loginid', { timeout: 5000 })
        } catch (err) {
            logger.info('Уже залогинен')
            STATE.busy = false

        }
        if (loginlink) {
            // Login process
            await login(page);
            STATE.busy = false

        } else {
            STATE.busy = false
        }

        await processOrders(page, orders);
        await browser.close();
        process.exit(0);



    } catch (error) {
        console.error('An error occurred:', error);
        logger.info('Закрываем браузер и перезапускаем скрипт')
        await browser.close();
        process.exit(1);
    }
}

main().catch(console.error);
