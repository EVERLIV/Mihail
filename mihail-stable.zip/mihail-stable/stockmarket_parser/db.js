require('dotenv').config({ path: '../.env' }); // загружает .env из родительской директории

const { MongoClient } = require('mongodb');

const mongourl = process.env.MONGODB_URL
const dbName = process.env.MONGO_DB;
console.log(mongourl, dbName);


async function saveVendorToMongoDB(vendorData) {
    const client = new MongoClient(mongourl);
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('vendors');

        const filter = { EmailAddress: vendorData.EmailAddress };
        const update = { $set: vendorData };
        const options = { upsert: true };

        await collection.updateOne(filter, update, options);
        
        // Принудительно применяем изменения
        //await db.command({ fsync: 1 });
        
        console.log(`Vendor ${vendorData.EmailAddress} saved/updated in MongoDB`);
    } catch (error) {
        console.error('Error saving vendor to MongoDB:', error);
        throw error;
    } finally {
        await client.close();
    }
}

async function getStatistics(vendor_email, order_id) {
    let client;
    try {
        client = await MongoClient.connect(mongourl);
        const db = client.db(dbName);
        const statsCollection = db.collection('statistics');
        
        let emailDomain;
        if (vendor_email.split('@')[1] === 'app.partsrfq.com') {
            emailDomain = vendor_email.split('@')[0];
        } else {
            emailDomain = vendor_email.split('@')[1]; // Извлекаем домен из адреса электронной почты
        }

        
        const result = await statsCollection.findOne({
            vendor_email: { $regex: emailDomain, $options: 'i' }, // Ищем по совпадению домена
            order_id
        });
        return result ? true : false ; 
    } catch (error) {
        console.error('Error getting statistics:', error);
        throw error;
    } finally {
        if (client) {
            await client.close();
        }
    }
}

async function saveStatistics(part_number, vendor_email, timestamp, order_id, company_name) {
    const client = new MongoClient(mongourl);
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('statistics');
        
        await collection.insertOne({
            marketplace: 'stockmarket.aero',
            part_number,
            vendor_email: vendor_email?.toLowerCase() || company_name?.toLowerCase().replace(',', '').replace(/\s/g, ''),
            created_at: timestamp,
            order_id
        });
        
        console.log(`Statistics saved for part ${part_number}`);
    } catch (error) {
        console.error('Error saving statistics to MongoDB:', error);
        throw error;
    } finally {
        await client.close();
    }
}

async function saveProcessedOrder(order) {
    console.log(mongourl, dbName);
    const client = new MongoClient(mongourl);
    try {
        console.log(new Date(), 'Подключаемся к MongoDB для сохранения заказа:', order.id);
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('orders');
        
        const orderData = {
            ...order,
            marketplace: "stockmarket.aero",
            processedAt: new Date(),
            processing_status: 'success'
        };
        
        console.log(new Date(), 'Подготовленные данные для сохранения:', JSON.stringify(orderData, null, 2));
        
        // Пытаемся вставить новый заказ
        try {
            const result = await collection.insertOne(orderData);
            console.log(new Date(), `Заказ ${order.id} успешно сохранен в MongoDB. ID документа: ${result.insertedId}`);
            
            // Проверяем, что документ действительно сохранен
            const savedOrder = await collection.findOne({ _id: result.insertedId });
            if (savedOrder) {
                console.log(new Date(), 'Подтверждение сохранения - документ найден');
            } else {
                console.error(new Date(), 'Ошибка: документ не найден после сохранения');
            }
        } catch (error) {
            if (error.code === 11000) { // Код ошибки дубликата в MongoDB
                console.log(new Date(), `Заказ ${order.id} уже существует для marketplace stockmarket.aero, пропускаем...`);
            } else {
                throw error; // Пробрасываем другие ошибки
            }
        }
        
    } catch (error) {
        console.error(new Date(), 'Критическая ошибка при работе с MongoDB:', error);
        throw error;
    } finally {
        try {
            await client.close();
            console.log(new Date(), 'Соединение с MongoDB закрыто');
        } catch (closeError) {
            console.error(new Date(), 'Ошибка при закрытии соединения:', closeError);
        }
    }
}

async function getUnprocessedOrders(orders) {
    let client;
    try {
        client = await MongoClient.connect(mongourl);
        const db = client.db(dbName);
        const ordersCollection = db.collection('orders');

        // Находим заказы, которые уже обработаны (имеют marketplace stockmarket.aero)
        const processedOrders = await ordersCollection.find(
            {
                id: { $in: orders.map(o => o.id) },
                marketplace: "stockmarket.aero"
            },
            { projection: { id: 1 } }
        ).toArray();

        const processedIds = new Set(processedOrders.map(o => o.id));
        return orders
            .filter(order => !processedIds.has(order.id))
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)); // Сортировка по timestamp (новые сначала)
    } catch (error) {
        console.error('Error getting unprocessed orders:', error);
        throw error;
    } finally {
        if (client) {
            await client.close();
        }
    }
}

async function getRecentStatistics(part_number, email) {
    const client = new MongoClient(mongourl);
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('statistics');
        
        // Проверяем email на null/undefined
        if (!email) {
            return false;
        }
        
        // Извлекаем домен из email
        const emailDomain = email.split('@')[1] || email;
        
        // Находим записи за последние 3 дня
        const threeDaysAgo = new Date();
        threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);
        
        const result = await collection.findOne({
            part_number,
            vendor_email: { $regex: `.*${emailDomain}.*`, $options: 'i' },
            created_at: { $gte: threeDaysAgo }
        });
        
        return result !== null;
    } catch (error) {
        console.error('Error getting recent statistics:', error);
        throw error;
    } finally {
        await client.close();
    }
}


module.exports = {
    saveVendorToMongoDB,
    saveStatistics,
    saveProcessedOrder,
    getUnprocessedOrders,
    getStatistics,
    getRecentStatistics
}; 