const mongoose = require('mongoose');

const mailQuoteSchema = new mongoose.Schema({
    message_id: {
        type: String
    },
    condition: {
        type: String
    },
    currency: {
        type: String
    },
    customer_request_id: {
        type: Number
    },
    date: {
        type: String
    },
    delivery_condition: {
        type: String
    },
    delivery_place: {
        type: String
    },
    description: {
        type: String
    },
    email_subject: {
        type: String
    },
    from: {
        type: String
    },
    is_moq: {
        type: Boolean,
        default: false
    },
    item_note: {
        type: String
    },
    lead_time: {
        type: Number
    },
    part_number: {
        type: String
    },
    price: {
        type: Number
    },
    qty: {
        type: Number
    },
    quote_id: {
        type: Number,
    },
    stk_qty: {
        type: Number
    },
    supplier: {
        type: String
    },
    time_unit: {
        type: String
    },
    um: {
        type: String
    },
    valid_to: {
        type: String
    },
    sent_to_pantheon: {
        type: Boolean
    },
    certificates: {
        type: Array
    },
    pantheon_sent_at: {
        type: String
    },
    pantheon_results: {
        type: Array
    }
});

module.exports = mongoose.model('pantheon_quotes', mailQuoteSchema); 