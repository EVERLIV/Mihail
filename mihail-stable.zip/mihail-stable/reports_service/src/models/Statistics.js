const mongoose = require('mongoose');

const statisticsSchema = new mongoose.Schema({
    marketplace: {
        type: String,
        required: true
    },
    part_number: {
        type: String,
        required: true
    },
    vendor_email: {
        type: String,
        required: true
    },
    timestamp: {
        type: Date,
    },
    order_id: {
        type: Number,
        required: true
    },
    created_at: {
        type: Date,
        required: true
    }
});

module.exports = mongoose.model('Statistics', statisticsSchema); 