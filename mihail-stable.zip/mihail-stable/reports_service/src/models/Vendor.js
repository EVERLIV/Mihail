const mongoose = require('mongoose');

const vendorSchema = new mongoose.Schema({
    VendorName: {
        type: String,
        required: true
    },
    ContactName: {
        type: String,
        required: true
    },
    EmailAddress: {
        type: String,
        required: true,
        unique: true
    },
    PhoneNumber: {
        type: String,
        required: true
    },
    FaxNumber: {
        type: String,
        required: false
    },
    Address1: {
        type: String,
        required: true
    },
    Address2: {
        type: String,
        required: false
    },
    City: {
        type: String,
        required: true
    },
    State: {
        type: String,
        required: true
    },
    Zip: {
        type: String,
        required: true
    },
    Country: {
        type: String,
        required: true
    }
}, { timestamps: true });

module.exports = mongoose.model('Vendor', vendorSchema); 