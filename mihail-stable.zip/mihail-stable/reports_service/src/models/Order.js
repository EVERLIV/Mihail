const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    id: {
        type: Number,
        required: true
    },
    request_date: {
        type: Date,
        required: true
    },
    part_number: {
        type: String,
        required: true
    },
    description: {
        type: String
    },
    qty: {
        type: Number,
        required: true
    },
    alternatives: {
        type: Array,
        default: []
    },
    marketplace: {
        type: String,
        required: false
    },
    processedAt: {
        type: Date
    },
    processing_status: {
        type: String,
        enum: ['success', 'failed', 'pending'],
        default: 'pending'
    },
    failure_reason: {
        type: String
    },
    error_message: {
        type: String
    }
});

// Создаем составной уникальный индекс только для записей, где есть marketplace
orderSchema.index({ id: 1, marketplace: 1 }, { 
    unique: true,
    partialFilterExpression: { 
        marketplace: { $exists: true }
    }
});

// Добавляем составной индекс для необработанных заказов
orderSchema.index({ 
    id: 1, 
    processed: 1 
}, { 
    unique: true,
    partialFilterExpression: { 
        processed: false,
        marketplace: { $exists: true }
    }
});

module.exports = mongoose.model('Orders', orderSchema); 