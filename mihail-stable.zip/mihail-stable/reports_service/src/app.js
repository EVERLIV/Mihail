require('dotenv').config({ path: '../.env' });
// Импортируем модель MailQuote, которая экспортируется как 'pantheon_quotes'

const express = require('express');
const mongoose = require('mongoose');
const path = require('path');

const app = express();

// Подключаем EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(express.static(path.join(__dirname, '../public')));
app.use(express.json());

console.log(process.env.MONGODB_URL);
// Подключение к MongoDB
mongoose.connect(process.env.MONGODB_URL, {
  dbName: process.env.MONGO_DB
});

// Роуты
app.use('/', require('./routes/reports'));


const PORT = 3010;
app.listen(PORT, () => {
  console.log(`Сервис отчетов запущен на порту ${PORT}`);
}); 