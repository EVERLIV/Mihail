const express = require('express');
const router = express.Router();
const Orders = require('../models/Order');
const Vendors = require('../models/Vendor');
const Statistics = require('../models/Statistics');
const Excel = require('exceljs');
const { format } = require('date-fns');
const ru = require('date-fns/locale/ru');
const Mail_Quotes = require('../models/MailQuote');


// Главная страница со списком заказов
router.get('/orders', async (req, res) => {
  try {
    const { orderId, partNumber, processing_status, marketplace, dateFrom, dateTo, page = 1, limit = 10 } = req.query;
    let query = {};

    if (orderId && orderId.trim() !== '') {
      query.id = parseInt(orderId);
    }

    if (partNumber && partNumber.trim() !== '') {
      query.part_number = new RegExp(partNumber.trim(), 'i');
    }

    // Добавляем фильтр по дате
    if (dateFrom || dateTo) {
      query.processedAt = {};
      if (dateFrom) {
        query.processedAt.$gte = new Date(dateFrom);
      }
      if (dateTo) {
        // Добавляем 1 день к dateTo чтобы включить весь день
        const endDate = new Date(dateTo);
        endDate.setHours(23, 59, 59, 999);
        query.processedAt.$lte = endDate;
      }
    }

    // Обновляем фильтр по статусу обработки
    if (processing_status && processing_status.trim() !== '') {
      query.processing_status = processing_status;
    }

    // Добавляем фильтр по marketplace
    if (marketplace && marketplace.trim() !== '') {
      query.marketplace = marketplace;
    }

    // Пагинация
    const currentPage = parseInt(page);
    const perPage = parseInt(limit);
    const skip = (currentPage - 1) * perPage;

    // Получаем уникальные значения для селектора
    const uniqueMarketplaces = await Orders.distinct('marketplace', { marketplace: { $exists: true } });

    // Получаем общее количество записей
    const totalOrders = await Orders.countDocuments(query);
    const totalPages = Math.ceil(totalOrders / perPage);

    const orders = await Orders.find(query)
      .sort({ processedAt: -1, id: -1 })
      .skip(skip)
      .limit(perPage);

    const filters = {
      ...(orderId && orderId.trim() !== '' && { orderId }),
      ...(partNumber && partNumber.trim() !== '' && { partNumber }),
      ...(processing_status && processing_status.trim() !== '' && { processing_status }),
      ...(marketplace && marketplace.trim() !== '' && { marketplace }),
      ...(dateFrom && dateFrom.trim() !== '' && { dateFrom }),
      ...(dateTo && dateTo.trim() !== '' && { dateTo }),
      limit: perPage
    };

    res.render('orders', { 
      orders,
      filters,
      format,
      uniqueMarketplaces,
      pagination: {
        currentPage,
        totalPages,
        perPage,
        totalOrders
      }
    });
  } catch (error) {
    console.error('Ошибка при получении заказов:', error);
    res.status(500).send('Ошибка при получении заказов');
  }
});

// Экспорт в Excel
router.get('/export', async (req, res) => {
  try {
    const { orderId, partNumber, dateFrom, dateTo, processing_status, marketplace } = req.query;
    let query = {};

    // Добавляем фильтр по ID заказа
    if (orderId && orderId.trim() !== '') {
      query.id = parseInt(orderId);
    }

    // Добавляем фильтр по номеру детали
    if (partNumber && partNumber.trim() !== '') {
      query.part_number = new RegExp(partNumber.trim(), 'i');
    }

    // Добавляем фильтр по дате
    if (dateFrom || dateTo) {
      query.processedAt = {};
      if (dateFrom) {
        query.processedAt.$gte = new Date(dateFrom);
      }
      if (dateTo) {
        const endDate = new Date(dateTo);
        endDate.setHours(23, 59, 59, 999);
        query.processedAt.$lte = endDate;
      }
    }

    if (processing_status) {
      query.processing_status = processing_status;
    }

    if (marketplace) {
      query.marketplace = marketplace;
    }

    const orders = await Orders.find(query)
      .sort({ processedAt: -1 });

    const workbook = new Excel.Workbook();
    const worksheet = workbook.addWorksheet('Заказы');

    worksheet.columns = [
      { header: 'ID', key: 'id', width: 10 },
      { header: 'Дата запроса', key: 'processedAt', width: 20 },
      { header: 'Номер детали', key: 'part_number', width: 15 },
      { header: 'Описание', key: 'description', width: 30 },
      { header: 'Количество', key: 'qty', width: 12 },
      { header: 'Статус обработки', key: 'processing_status', width: 15 },
      { header: 'Площадка', key: 'marketplace', width: 15 },
      { header: 'Причина ошибки', key: 'failure_reason', width: 30 },
      { header: 'Дата обработки', key: 'processedAt', width: 20 }
    ];

    orders.forEach(order => {
      worksheet.addRow({
        id: order.id,
        processedAt: order.processedAt ? format(order.processedAt, 'dd.MM.yyyy HH:mm', { locale: ru }) : '',
        part_number: order.part_number,
        description: order.description,
        qty: order.qty,
        processing_status: order.processing_status || 'pending',
        marketplace: order.marketplace || 'Не указана',
        failure_reason: order.failure_reason || '',
        processedAt: order.processedAt ? format(order.processedAt, 'dd.MM.yyyy HH:mm', { locale: ru }) : ''
      });
    });

    res.setHeader(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    );
    res.setHeader(
      'Content-Disposition',
      `attachment; filename=orders-${format(new Date(), 'dd-MM-yyyy')}.xlsx`
    );

    await workbook.xlsx.write(res);
    res.end();
  } catch (error) {
    console.error('Ошибка при экспорте данных:', error);
    res.status(500).send('Ошибка при экспорте данных');
  }
});

// Детали заказа
router.get('/order/:id', async (req, res) => {
  try {
    const order = await Orders.findById(req.params.id);
    console.log(JSON.stringify(order));
    if (!order) {
      return res.status(404).render('error', { 
        message: 'Заказ не найден' 
      });
    }

    // Получаем статистику запросов для данного заказа
    const statistics = await Statistics.find({ 
      order_id: order.id,
      marketplace: order.marketplace 
    }).sort({ created_at: -1 });

    console.log(JSON.stringify(statistics));

    res.render('order-details', { 
      order,
      statistics,
      format
    });
  } catch (error) {
    console.error('Ошибка при получении деталей заказа:', error);
    res.status(500).send('Ошибка при получении деталей заказа');
  }
});

// Маршрут для получения списка поставщиков
router.get('/suppliers', async (req, res) => {
  try {
    const { query = '', page = 1, limit = 10 } = req.query;
    const currentPage = parseInt(page);
    const perPage = parseInt(limit);
    const skip = (currentPage - 1) * perPage;

    let searchQuery = {};
    if (query && query.trim() !== '') {
      const regex = new RegExp(query.trim(), 'i');
      const lowercasedQuery = query.trim().toLowerCase();
      searchQuery = {
        $or: [
          { VendorName: regex },
          { EmailAddress: regex },
          { ContactName: regex },
          { Address1: regex },
          { EmailAddress: new RegExp(lowercasedQuery, 'i') },
          { ContactName: new RegExp(lowercasedQuery, 'i') }
        ]
      };
    }

    const totalSuppliers = await Vendors.countDocuments(searchQuery);
    const totalPages = Math.ceil(totalSuppliers / perPage);

    const suppliers = await Vendors.find(searchQuery)
      .skip(skip)
      .limit(perPage);

    const filters = {
      query: query || '',  // Явно устанавливаем пустую строку если query отсутствует
      page: currentPage,
      limit: perPage
    };

    res.render('suppliers', { 
      suppliers,
      filters,
      pagination: {
        currentPage,
        totalPages,
        perPage,
        totalSuppliers
      }
    });
  } catch (error) {
    console.error('Ошибка при получении поставщиков:', error);
    res.status(500).send('Ошибка при получении поставщиков');
  }
});

// Маршрут для просмотра предложений
router.get('/', async (req, res) => {
  try {
    const { quoteId, customerId, partNumber, page = 1, limit = 10, sortBy = 'quote_id', sortOrder = 'desc', notSentOnly } = req.query;
    let query = {
      // Фильтруем предложения с некорректными значениями quote_id
      quote_id: { $ne: null, $ne: 0 }
    };

    if (quoteId && quoteId.trim() !== '') {
      query.quote_id = parseInt(quoteId);
      console.log('фильтруем по quote_id', quoteId);
    }

    if (customerId && customerId.trim() !== '') {
      query.customer_request_id = parseInt(customerId);
      console.log('фильтруем по customer_request_id', customerId);
    }
    
    if (partNumber && partNumber.trim() !== '') {
      query.part_number = partNumber.trim();
      console.log('фильтруем по part_number', partNumber);
    }
    
    // Добавляем фильтр для неотправленных предложений
    if (notSentOnly === 'true') {
      query.$or = [
        { sent_to_pantheon: { $ne: true } },
        { sent_to_pantheon: { $exists: false } }
      ];
      console.log('фильтруем только неотправленные в Pantheon');
    }

    // Пагинация
    const currentPage = parseInt(page);
    const perPage = parseInt(limit);
    
    // Получаем все предложения без пагинации для группировки
    const allQuotes = await Mail_Quotes.find(query);
    console.log('Найдено предложений',allQuotes.length);

    // Группируем предложения по quote_id, исключая некорректные значения
    const groupedQuotes = {};
    allQuotes.forEach(quote => {
      if (quote.quote_id && quote.quote_id !== 0) {
        if (!groupedQuotes[quote.quote_id]) {
          groupedQuotes[quote.quote_id] = [];
        }
        groupedQuotes[quote.quote_id].push(quote);
      }
    });
    
    // Сортируем предложения внутри каждой группы по цене (от меньшей к большей)
    Object.keys(groupedQuotes).forEach(quote_id => {
      groupedQuotes[quote_id].sort((a, b) => {
        // Преобразуем цены в числа для корректного сравнения
        const priceA = parseFloat(a.price) || 0;
        const priceB = parseFloat(b.price) || 0;
        return priceA - priceB;
      });
    });
    
    // Получаем отсортированные ключи (quote_id) в соответствии с выбранным параметром сортировки
    const sortedQuoteIds = Object.keys(groupedQuotes)
      .map(Number)
      .sort((a, b) => {
        // Получаем первое предложение из каждой группы для сравнения
        const quoteA = groupedQuotes[a][0];
        const quoteB = groupedQuotes[b][0];
        
        let comparison = 0;
        
        // Сортировка в зависимости от выбранного параметра
        if (sortBy === 'price') {
          // Сортировка по цене первого предложения в группе
          const priceA = parseFloat(quoteA.price) || 0;
          const priceB = parseFloat(quoteB.price) || 0;
          comparison = priceA - priceB;
        } else if (sortBy === 'date') {
          // Сортировка по дате
          const dateA = new Date(quoteA.date || 0);
          const dateB = new Date(quoteB.date || 0);
          comparison = dateA - dateB;
        } else {
          // По умолчанию сортировка по quote_id
          comparison = a - b;
        }
        
        // Применяем порядок сортировки
        return sortOrder === 'desc' ? -comparison : comparison;
      });
    
    const totalQuoteGroups = sortedQuoteIds.length;
    const totalPages = Math.ceil(totalQuoteGroups / perPage);
    
    // Применяем пагинацию к отсортированным группам
    const paginatedQuoteIds = sortedQuoteIds.slice((currentPage - 1) * perPage, currentPage * perPage);
    
    // Формируем окончательный список групп для отображения в отсортированном порядке
    const paginatedGroupedQuotes = {};
    paginatedQuoteIds.forEach(id => {
      paginatedGroupedQuotes[id] = groupedQuotes[id];
    });

    const filters = {
      ...(quoteId && quoteId.trim() !== '' && { quoteId }),
      ...(customerId && customerId.trim() !== '' && { customerId }),
      ...(partNumber && partNumber.trim() !== '' && { partNumber }),
      ...(notSentOnly && { notSentOnly }),
      sortBy,
      sortOrder,
      limit: perPage
    };
    
    res.render('quotes', { 
      groupedQuotes: paginatedGroupedQuotes,
      filters,
      format,
      pagination: {
        currentPage,
        totalPages,
        perPage,
        totalItems: totalQuoteGroups
      }
    });
  } catch (error) {
    console.error('Ошибка при получении предложений:', error);
    res.status(500).send('Ошибка при получении предложений');
  }
});

// Детали предложения
router.get('/quote/:id', async (req, res) => {
  try {
    const quote = await Mail_Quotes.findById(req.params.id);
    
    if (!quote) {
      return res.status(404).render('error', { 
        message: 'Предложение не найдено' 
      });
    }

    console.log(JSON.stringify(quote));
    
    res.render('quote-details', { 
      quote,
      format
    });
  } catch (error) {
    console.error('Ошибка при получении деталей предложения:', error);
    res.status(500).send('Ошибка при получении деталей предложения');
  }
});

// Маршрут для удаления предложения
router.delete('/quote/:id', async (req, res) => {
  try {
    const quoteId = req.params.id;
    const result = await Mail_Quotes.findByIdAndDelete(quoteId);
    
    if (!result) {
      return res.status(404).json({ 
        success: false, 
        error: 'Предложение не найдено' 
      });
    }

    return res.status(200).json({ 
      success: true, 
      message: 'Предложение успешно удалено' 
    });
  } catch (error) {
    console.error('Ошибка при удалении предложения:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Ошибка при удалении предложения' 
    });
  }
});

// Маршрут для получения списка предложений для массовой отправки
router.get('/quotes-to-send', async (req, res) => {
  try {
    // Получаем дату 5 дней назад
    const daysAgo = new Date();
    daysAgo.setDate(daysAgo.getDate() - 5);
    const daysAgoFormatted = format(daysAgo, 'yyyy-MM-dd');
    
    // Ищем предложения, которые еще не были отправлены в Pantheon
    // и были созданы не ранее 5 дней назад
    const quotes = await Mail_Quotes.find({
      $or: [
        { sent_to_pantheon: { $ne: true } },
        { sent_to_pantheon: { $exists: false } }
      ], 
      date: { $gte: daysAgoFormatted } // Сравниваем с отформатированной датой
    }).sort({ date: -1 });
    
    res.json(quotes);
  } catch (error) {
    console.error('Ошибка при получении списка предложений для отправки:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Ошибка при получении списка предложений' 
    });
  }
});

module.exports = router; 