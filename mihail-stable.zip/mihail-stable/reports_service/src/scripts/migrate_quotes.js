const mongoose = require('mongoose');
const MailQuote = require('../models/MailQuote');

async function migrateQuotes() {
    try {
        // Подключаемся к базе данных
        await mongoose.connect(process.env.MONGODB_URL || 'mongodb://localhost:27018/vendorsDB');
        console.log('Подключено к базе данных');

        // Находим все записи с полем quoteID
        const quotes = await MailQuote.find({ quoteID: { $exists: true } });
        console.log(`Найдено ${quotes.length} записей для миграции`);

        // Обновляем каждую запись
        for (const quote of quotes) {
            if (quote.quoteID) {
                // Сохраняем значение quoteID
                const quoteIdValue = quote.quoteID;
                
                // Удаляем старое поле
                quote.quoteID = undefined;
                
                // Добавляем новое поле
                quote.quote_id = quoteIdValue;
                
                // Сохраняем обновленную запись
                await quote.save();
                console.log(`Обновлена запись ${quote._id}`);
            }
        }

        console.log('Миграция завершена успешно');
        process.exit(0);
    } catch (error) {
        console.error('Ошибка при миграции:', error);
        process.exit(1);
    }
}

migrateQuotes(); 