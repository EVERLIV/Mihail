 // reports_service/src/scripts/create_indexes.js
const mongoose = require('mongoose');

async function createIndex(collection, indexSpec, name) {
    try {
        await collection.createIndex(indexSpec);
        console.log(`✓ ${name} индекс создан`);
    } catch (error) {
        if (error.message.includes('existing index') || error.code === 85) {
            console.log(`- ${name} индекс уже существует`);
        } else {
            console.error(`✗ Ошибка создания ${name} индекса:`, error.message);
        }
    }
}

async function createIndexes() {
    try {
        await mongoose.connect(process.env.MONGODB_URL || 'mongodb://localhost:27018/vendorsDB');
        console.log('Подключено к БД');

        const db = mongoose.connection.db;

        // Orders индексы
        console.log('\n--- Orders коллекция ---');
        const ordersCollection = db.collection('orders');
        await createIndex(ordersCollection, { "processedAt": -1, "id": -1 }, "processedAt+id");
        await createIndex(ordersCollection, { "id": 1 }, "id");
        await createIndex(ordersCollection, { "part_number": 1 }, "part_number");
        await createIndex(ordersCollection, { "processing_status": 1 }, "processing_status");
        await createIndex(ordersCollection, { "marketplace": 1 }, "marketplace");
        await createIndex(ordersCollection, { "processedAt": -1, "marketplace": 1, "processing_status": 1 }, "processedAt+marketplace+status");

        // Vendors индексы
        console.log('\n--- Vendors коллекция ---');
        const vendorsCollection = db.collection('vendors');
        await createIndex(vendorsCollection, { 
            "VendorName": "text", 
            "EmailAddress": "text", 
            "ContactName": "text", 
            "Address1": "text" 
        }, "text search");
        await createIndex(vendorsCollection, { "VendorName": 1 }, "VendorName");
        // await createIndex(vendorsCollection, { "EmailAddress": 1 }, "EmailAddress");

        // Mail_Quotes индексы
        console.log('\n--- Pantheon_quotes коллекция ---');
        const quotesCollection = db.collection('pantheon_quotes');
        await createIndex(quotesCollection, { "quote_id": 1 }, "quote_id");
        await createIndex(quotesCollection, { "customer_request_id": 1 }, "customer_request_id");
        await createIndex(quotesCollection, { "part_number": 1 }, "part_number");
        await createIndex(quotesCollection, { "sent_to_pantheon": 1, "date": -1 }, "sent_to_pantheon+date");
        await createIndex(quotesCollection, { "quote_id": 1, "date": -1 }, "quote_id+date");

        // Statistics индексы
        console.log('\n--- Statistics коллекция ---');
        const statisticsCollection = db.collection('statistics');
        await createIndex(statisticsCollection, { "order_id": 1, "created_at": -1 }, "order_id+created_at");

        console.log('\n🎉 Обработка индексов завершена');
        process.exit(0);
    } catch (error) {
        console.error('Критическая ошибка:', error);
        process.exit(1);
    }
}

createIndexes();