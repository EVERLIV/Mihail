const mongoose = require('mongoose');
const MailQuote = require('../models/MailQuote');

async function migrateFields() {
    try {
        // Подключаемся к базе данных
        await mongoose.connect(process.env.MONGODB_URL || 'mongodb://localhost:27018/vendorsDB');
        console.log('Подключено к базе данных');

        // Находим все записи с полями старого формата
        const quotes = await MailQuote.find({
            $or: [
                { partNumber: { $exists: true } },
                { leadTime: { $exists: true } }
            ]
        });
        
        console.log(`Найдено ${quotes.length} записей для миграции`);

        // Обновляем каждую запись
        for (const quote of quotes) {
            const updates = {};
            
            if (quote.quoteID !== undefined) {
                updates.quote_id = quote.quoteID;
                quote.quoteID = undefined;
            }
            // Проверяем и обновляем partNumber -> part_number
            if (quote.partNumber !== undefined) {
                updates.part_number = quote.partNumber;
                quote.partNumber = undefined;
            }
            
            // Проверяем и обновляем leadTime -> lead_time
            if (quote.leadTime !== undefined) {
                updates.lead_time = quote.leadTime;
                quote.leadTime = undefined;
            }
            
            // Если есть что обновлять
            if (Object.keys(updates).length > 0) {
                await quote.save();
                console.log(`Обновлена запись ${quote._id}:`, updates);
            }
        }

        console.log('Миграция завершена успешно');
        process.exit(0);
    } catch (error) {
        console.error('Ошибка при миграции:', error);
        process.exit(1);
    }
}

migrateFields(); 