To use and test the platform if its a match step :

Go to : https://www.partsbase.com/integrations

 Implementation Notes

Service consumer does a request to get an access token. With that token, service consumer does a request to the RealTimeSearch operation and gets a parts list as response.
CLICK the link to access features token.

AUTHORISATION
POST /connect/token
Example
POST https://auth.partsbase.com/connect/token HTTP/1.1
Content-Type: application/x-www-form-urlencoded
Request Body: grant_type=password&client_id=TestClientId&client_secret=0F8F-D9CB-469F7086&scope=api&username=TestUserName&password=TestPassword


PARTS REAL TIME SEARCH
GET /api/v1/search/RealTimeSearch
Example
GET https://apiservices.partsbase.com/api/v1/search/RealTimeSearch?FilterType=PartNumber&Filter=1000&Location=246&XrefType=UsMcrlXref&Quantity=10&SortBy=Seller&ConditionCode=SV,NS HTTP/1.1
Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6ImEzck1VZ01Gdjl0
Content-Type: application/json
Accept: application/json v=1.0
success response:
{
  "Items": [
    {
      "Index": 0,
      "InventoryId": 0,
      "AlternatePartNumber": "string",
      "Cage": "string",
      "ConditionCode": "string",
      "Currency": "string",
      "LastUpdateDate": "yyyy-MM-ddTHH:mm:ss EST",
      "Manufacturer": "string",
      "PartDescription": "string",
      "PartNumber": "string",
      "Quantity": "string",
      "Seller": {
        "Certificates": [
          {
            "Name": "string"
          }
        ],
        "CompanyOfferUrl": "string",
        "CompanyVideoUrl": "string",
        "Extension": "string",
        "Fax": "string",
        "HasMoreCertificates": true,
        "Phone": "string",
        "Seller": "string",
        "City": "string",
        "State": "string",
        "Country": "string",
        "SpecialInstruction": "string",
        "SellerId": 0,
        "ContactName": "string",
        "Email": "string",
        "Address": "string",
        "PostalCode": "string",
        "WebSite": "string",
        "Cage": "string"
      },
      "UnitPrice": 0,
      "UoM": "string"
    }
  ]
}



SEND RFQs

POST /api-sendrfq
This service Send a request for Quotes for Parts and Capabilities
Service costumer does a request to get an access token. With that token, service costumer does a Send RFQ "GET" request to get RFQ status and RFQ Items status by the RFQ Identifier.
This service send a Request for Quotes in the PartsBase system and returns the RFQ identifier and a List of those Parts that were considered as not qualified.
*Note:
-This service uses the base URL: https://services.partsbase.com, please consider it in your implementation.
-Duplicated Inventory IDs per RFQ will be ignored.

Example
POST https://services.partsbase.com/api-sendrfq HTTP/1.1
Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6ImEzck1VZ01Gdjl0
Accept: application/json
Example Request Body
 {
    "Parts":[
        {
            "InventoryId" : integer,
            "Quantity": integer,
            "UoM": string
        },
        {
            "InventoryId" : integer,
            "Quantity": integer,
            "UoM": string
        },
      ],
    "ResponseByDate": string,
    "LeadTime": integer,
    "RFQTrackingNo": string,
    "Comments": string,
    "MRO": boolean
    }


1   Parts	        Array	List of Parts/Capabilities data.	Req:True	Min Items Count: 1  Max Items Count: 20
2	InventoryId:	Int	    Inventory/Capability identifier.	Req:True	Min value: 1
3	Quantity:	    Int	    Amount	                            Req:True	Min value: 1  Max value: 99999
4	UoM:	        String  Nullable	Unit of Measure	        Req:False	Pattern: ^[A-Z0-9]{2}$
5	ResponseByDate:	String	Requested Response Date	            Req:True	Format:"YYYY-MM-DD"  Min. Date: Tomorrow
6	LeadTime:	    Int	    Requested Delivery Days.	        Req:True	Min value: 1  -Max value: 365
7	RFQTrackingNo:	String	Tracking Number.	                Req:False	Min lenght: 1  Max lenght: 50
8	Comments:	    String	Comments	                        Req:False	Min lenght: 1  Max lenght: 255
9	MRO:	        Boolean	Identify if RFQ Send request 
                    belongs to Parts (MRO = False) or 
                    Capabilities (MRO= True)	                Req:False	Default value: False




Implementation Notes
Service costumer does a request to get an access token. With that token, service costumer does a Send RFQ "GET" request to get RFQ status and RFQ Items status by the RFQ Identifier.
*Note: This service uses the base URL: https://services.partsbase.com, please consider it in your implementation.
Example


GET /api-sendrfq
This service returns RFQ status and RFQ Items associated status.
GET https://services.partsbase.com/api-sendrfq?rfqId=7923453 HTTP/1.1
s
Implementation Notes
This service send a Request for Quotes in the PartsBase system and returns the RFQ identifier and a List of those Parts that were considered as not qualified.
*Note:
-This service uses the base URL: https://services.partsbase.com, please consider it in your implementation.
-Duplicated Inventory IDs per RFQ will be ignored.




400	
Bad request

ModelExample Value
{
    "message": "string",
}
401	
Unauthorized

string
404	
Not Found

string
500	
InternalServerError

string