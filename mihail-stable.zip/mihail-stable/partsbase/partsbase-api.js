const fetch = require('node-fetch');
const { HttpsProxyAgent } = require('https-proxy-agent');
const fs = require('fs').promises;
const path = require('path');

class PartsBaseAPI {
  constructor(config = {}) {
    this.config = {
      baseUrl: 'https://apiservices.partsbase.com',
      rfqUrl: 'https://services.partsbase.com',
      authUrl: 'https://auth.partsbase.com/connect/token',
      clientId: config.clientId,
      clientSecret: config.clientSecret,
      username: config.username,
      password: config.password,
      proxy: config.proxy
    };
    
    this.token = null;
    this.agent = new HttpsProxyAgent(this.config.proxy);
    this.authRetryCount = 0;
    this.maxAuthRetries = 3;
    this.searchRequestsCount = 0;
    this.rfqRequestsCount = 0;
    this.isFrozen = false;
  }

  async #getToken() {
    const params = new URLSearchParams();
    params.append('grant_type', 'password');
    params.append('client_id', this.config.clientId);
    params.append('client_secret', this.config.clientSecret);
    params.append('scope', 'api');
    params.append('username', this.config.username);
    params.append('password', this.config.password);

    const fetchOptions = {
      method: 'POST',
      body: params,
      agent: this.agent
    };

    const response = await fetch(this.config.authUrl, fetchOptions);

    if (!response.ok) {
      throw new Error(`Auth failed: ${response.statusText}`);
    }

    const data = await response.json();
    this.token = data.access_token;
    return this.token;
  }

  async #request(url, options = {}) {
    if (!this.token) {
      await this.#getToken();
    }

    const headers = {
      'Authorization': `Bearer ${this.token}`,
      'Accept': 'application/json v=1.0',
      'Connection': 'keep-alive',
      ...options.headers
    };

    const fetchOptions = {
      ...options,
      headers,
      httpVersion: '1.1',
      agent: this.agent
    };

    try {
      const response = await fetch(url, fetchOptions);

      if (response.status === 400) {
        this.isFrozen = true;
        console.error('Bad Request detected, waiting 10 minutes before restart...');
        console.error(`Frozen request counters - Search: ${this.searchRequestsCount}, RFQ: ${this.rfqRequestsCount}`);
        await new Promise(resolve => setTimeout(resolve, 10 * 60 * 1000));
        process.exit(1); // Restart service through exit code
      }

      if (response.status === 403) {
        console.log('Token expired, refreshing...');
        
        if (this.authRetryCount >= this.maxAuthRetries) {
          throw new Error('Maximum number of authentication attempts exceeded');
        }
        
        this.authRetryCount++;
        this.token = null;
        await this.#getToken();
        return this.#request(url, options);
      }

      this.authRetryCount = 0;

      if (!response.ok) {
        throw new Error(`Request failed: ${response.statusText}`);
      }

      return response.json();
    } catch (error) {
      throw new Error(`API request failed: ${error.message}`);
    }
  }

  async searchParts(params = {}) {
    if (this.isFrozen) {
      console.log('[PartsBase API] Counters frozen due to Bad Request');
      return;
    }
    this.searchRequestsCount++;
    console.log(`[PartsBase API] Search request #${this.searchRequestsCount}`);
    
    const searchParams = new URLSearchParams();
    
    if (params.filterType) searchParams.append('filterType', params.filterType);
    if (params.filter) searchParams.append('filter', params.filter);
    //if (params.conditionCode) searchParams.append('conditionCode', params.conditionCode);
    if (params.xrefType) searchParams.append('xrefType', params.xrefType);
    if (params.quantity) searchParams.append('quantity', params.quantity);
    if (params.location) searchParams.append('location', params.location);
    if (params.sortBy) searchParams.append('sortBy', params.sortBy);

    console.log(`${this.config.baseUrl}/api/v1/search/RealTimeSearch?${searchParams.toString()}&conditionCode=${params.conditionCode}`)
    return this.#request(`${this.config.baseUrl}/api/v1/search/RealTimeSearch?${searchParams.toString()}&conditionCode=${params.conditionCode}`);
  }

  async sendRFQ(rfqData) {
    if (this.isFrozen) {
      console.log('[PartsBase API] Counters frozen due to Bad Request');
      return;
    }
    this.rfqRequestsCount++;
    console.log(`[PartsBase API] RFQ request #${this.rfqRequestsCount}`);
    
    return this.#request(`${this.config.rfqUrl}/api-sendrfq`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(rfqData)
    });
  }

  async getRFQStatus(rfqId) {
    return this.#request(`${this.config.rfqUrl}/api-sendrfq?rfqId=${rfqId}`);
  }

  async login() {
    return this.#getToken();
  }
}

module.exports = PartsBaseAPI; 

