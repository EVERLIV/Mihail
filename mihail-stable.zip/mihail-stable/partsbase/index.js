const dotenv = require('dotenv');
dotenv.config();
require('dotenv').config({ path: '../.env' }); // загружает .env из родительской директории

const blacklist = require('./blacklist');


const hkproxy = 'http://' + process.env.PROXY_USERNAME +
  ':' + process.env.PROXY_PASSWORD +
  '@' + process.env.PROXY_SERVER +
  ':' + process.env.PROXY_PORT


const {
  getUnprocessedOrders,
  saveProcessedOrder,
  saveStatistics,
  getStatistics,
  saveVendorToMongoDB,
  getTodaysProcessedOrdersCount
} = require('./db');

const oneday = 1000 * 60 * 60 * 24

const PartsBaseAPI = require('./partsbase-api');

const api = new PartsBaseAPI({
  clientId: process.env.PARTSBASE_CLIENT_ID,
  clientSecret: process.env.PARTSBASE_CLIENT_SECRET,
  username: process.env.PARTSBASE_USERNAME,
  password: process.env.PARTSBASE_PASSWORD,
  proxy: hkproxy
});

const baseUrl = process.env.PANTHEON_API_URL;
const getOrdersUrl = process.env.GETORDERSURL;
const authToken = process.env.API_AUTH_TOKEN;

// Добавляем счетчик запросов и логику времени
let dailyRequestCount = 0;
const DAILY_REQUEST_LIMIT = 350;

// Функция для инициализации счетчика из базы данных
async function initializeDailyCounter() {
  try {
    const count = await getTodaysProcessedOrdersCount();
    dailyRequestCount = count;
    console.log(new Date(), `Initialized daily request counter from database: ${dailyRequestCount}/${DAILY_REQUEST_LIMIT}`);
  } catch (error) {
    console.error('Error initializing daily counter from database:', error);
    dailyRequestCount = 0;
  }
}

// Функция для сброса счетчика в 6:00 утра (начало дневного времени)
function resetDailyCounterIfNeeded() {
  const now = new Date();
  const hour = now.getHours();
  const today = now.toDateString();
  const lastResetDate = global.lastResetDate || '';
  
  // Сбрасываем счетчик в 4:00 утра, а не в полночь
  if (lastResetDate !== today && hour >= 4) {
    dailyRequestCount = 0;
    global.lastResetDate = today;
    console.log(new Date(), 'Daily request counter reset to 0 at 6:00 AM');
  }
}

// Функция для проверки ночного времени (22:00-6:00)
function isNightTime() {
  const now = new Date();
  const hour = now.getHours();
  return hour >= 22 || hour < 4;
}

// Функция для подсчета оставшихся запросов
function getRemainingRequests() {
  return DAILY_REQUEST_LIMIT - dailyRequestCount;
}

// Функция для инкремента счетчика запросов
function incrementRequestCount() {
  dailyRequestCount++;
  console.log(new Date(), `API requests used today: ${dailyRequestCount}/${DAILY_REQUEST_LIMIT}`);
}

async function getOrders() {
  // Сбрасываем счетчик если нужно
  resetDailyCounterIfNeeded();
  
  const isNight = isNightTime();
  const remainingRequests = getRemainingRequests();
  
  console.log(new Date(), `Current time: ${new Date().toLocaleTimeString()}`);
  console.log(new Date(), `Night time: ${isNight}`);
  console.log(new Date(), `Remaining requests: ${remainingRequests}`);
  
  // Проверяем, не превышен ли лимит
  if (remainingRequests <= 0) {
    console.log(new Date(), 'Daily API request limit exceeded. Waiting until tomorrow.');
    return [];
  }
  
  console.log(new Date(), baseUrl + getOrdersUrl);
  console.log(new Date(), authToken);
  
  // Инкрементируем счетчик перед запросом
  incrementRequestCount();
  
  const response = await fetch(baseUrl + getOrdersUrl, {
    headers: {
      'Authorization': `${authToken}`
    }
  });
  const data = await response.json();
  console.log(new Date(), 'Received: ' + data.length + ' orders');
  const unprocessedOrders = await getUnprocessedOrders(data);
  
  // Определяем порядок приоритетов
  const priorityOrder = {
    'AOG': 1,
    'WSP': 2,
    'USR': 3,
    'RTN': 4
  };

  // Сортируем заказы по приоритету
  const sortedOrders = unprocessedOrders.sort((a, b) => {
    const priorityA = priorityOrder[a.priority] || 5;
    const priorityB = priorityOrder[b.priority] || 5;
    return priorityA - priorityB;
  });

  // Считаем статистику по приоритетам
  const stats = {
    'AOG': 0,
    'WSP': 0,
    'USR': 0,
    'RTN': 0,
    'OTHER': 0
  };

  sortedOrders.forEach(order => {
    if (order.priority in stats) {
      stats[order.priority]++;
    } else {
      stats.OTHER++;
    }
  });

  // Выводим статистику
  console.log(new Date(), '\nOrders statistics by priority:');
  console.log(new Date(), '--------------------------------');
  console.log(new Date(), `AOG: ${stats.AOG}`);
  console.log(new Date(), `WSP: ${stats.WSP}`);
  console.log(new Date(), `USR: ${stats.USR}`);
  console.log(new Date(), `RTN: ${stats.RTN}`);
  console.log(new Date(), `Other priorities: ${stats.OTHER}`);
  console.log(new Date(), '--------------------------------\n');

  // Логика фильтрации в зависимости от времени и лимитов
  let filteredOrders;
  
  if (isNight) {
    // Ночное время (22:00-6:00): обрабатываем все заказы используя оставшиеся запросы
    console.log(new Date(), 'Night time (22:00-4:00): processing all material types with remaining requests');
    filteredOrders = sortedOrders;
  } else {
    // Дневное время (6:00-22:00): обрабатываем ВСЕ заказы типа 'R' без лимита
    console.log(new Date(), 'Day time (4:00-22:00): processing ALL material_type R orders');
    filteredOrders = sortedOrders.filter(order => order.material_type === 'R');
  }
  
  console.log(new Date(), `Filtered orders count: ${filteredOrders.length}`);
  console.log(new Date(), `Material types in filtered orders: ${[...new Set(filteredOrders.map(o => o.material_type))].join(', ')}`);
  
  return filteredOrders;
}

async function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function main() {
  try {
    // Инициализируем счетчик из базы данных при запуске
    await initializeDailyCounter();
    
    const orders = await getOrders();
    const unprocessedOrders = await getUnprocessedOrders(orders);

    if (unprocessedOrders.length === 0) {
      console.log(new Date(), 'No unprocessed orders');
      return;
    }
    console.log(new Date(), `Found ${unprocessedOrders.length} unprocessed orders`);

    await api.login();
    console.log(new Date(), 'successful login');

    let counter = 0;
    for (const order of unprocessedOrders) {
      // Проверяем лимит запросов перед обработкой каждого заказа
      if (getRemainingRequests() <= 0) {
        console.log(new Date(), 'Daily API request limit reached. Stopping processing.');
        break;
      }

      counter++;
      console.log(new Date(), '-------------------------------------------------------------------------------------');
      console.log(new Date(), 'Searching parts for order: ' + counter + '/' + unprocessedOrders.length + ' ' + order.id + ', part number: ' + order.part_number);

      let response;
      
      try {
        // Инкрементируем счетчик перед поиском
        incrementRequestCount();
        
        response = await api.searchParts({
          filterType: 'PartNumber',
          filter: order.part_number,
          quantity: 100,
          conditionCode: 'NS,NE,OH,SV,IN,FN'
        });
      } catch (err) {
        console.log(new Date(), err)
        continue
      }

      if (!response || response.items?.length === 0) {
        console.log(new Date(), 'No parts found for order: ' + order.id + ', part number: ' + order.part_number);
        await saveProcessedOrder(order);
        continue;
      }

      for (const result of response.items) {
        if (result.quantity < order.qty * 1.2) continue;

        const supplierData = conformSuppData(result);
        if (supplierData.blacklisted) {
          console.log(new Date(), '----Supplier is blacklisted:' + supplierData.VendorName + '!!!!----');
          continue;
        }

        // Сохраняем данные поставщика
        try {
          await saveVendorToMongoDB(supplierData);
        } catch (error) {
          console.error(`Error saving supplier data ${supplierData.VendorName}:`, error);
        }

        // Проверяем, не отправляли ли уже RFQ для этого заказа
        const statistics = await getStatistics(result.seller?.email, order.id);
        if (statistics) {
          console.log(new Date(), `RFQ already sent for order ${order.id}, part ${order.part_number}`);
          continue;
        }

        const rfqData = {
          Parts: [{
            InventoryId: result.inventoryId,
            Quantity: order.qty,
            UoM: result.unitOfMeasure || 'EA'
          }],
          ResponseByDate: getResponseDateByPriority(order.priority),
          LeadTime: 60,
          RFQTrackingNo: 'SSS' + order.id,
          Comments: order.priority + ' RFQ ' + result.partNumber,
          MRO: false
        };

        try {
          console.log(new Date(), 'Sending RFQ to ' + supplierData.VendorName);
          const rfqResponse = await api.sendRFQ(rfqData);
          console.log(new Date(), 'RFQ response: ' + JSON.stringify(rfqResponse, null, 2));

          if (rfqResponse.rfqId) {
            await saveStatistics(
              order.part_number,
              result.seller?.email || null,
              result.seller?.seller || null,
              order.id,
              rfqResponse.rfqId
            );
            console.log(new Date(), `RFQ sent for order: ${order.id}`);
          }
        } catch (error) {
          console.error(`Error sending RFQ to ${supplierData.VendorName}:`, error);
        }
      }

      await saveProcessedOrder(order);
      console.log(new Date(), 'Order ' + order.id + ' processed');

    }
  } catch (error) {
    console.error('Error:', error.message);
  }
}

function getResponseDateByPriority(priority) {
  const days = {
    'AOG': 7,
    'WSP': 10,
    'USR': 12,
    'RTN': 14
  };
  return new Date(Date.now() + (days[priority] || 5) * oneday).toISOString().split('T')[0];
}

function conformSuppData(result) {
  return {
    VendorName: result.seller.seller || '',
    ContactName: result.seller.contactName || '',
    EmailAddress: result.seller.email || '',
    PhoneNumber: result.seller.phone || '',
    FaxNumber: result.seller.fax || '',
    Address1: result.seller.address || '',
    // Address2: result.seller.address2 || '',
    City: result.seller.city || '',
    State: result.seller.state || '',
    Zip: result.seller.postalCode || '',
    Country: result.seller.country || '',
    blacklisted: blacklist.some(item => result.seller.seller.replace(/\s+/g, '').toLowerCase()
      .includes(item.toLowerCase()))
  };
}

main();
