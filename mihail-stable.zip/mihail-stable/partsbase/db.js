require('dotenv').config({ path: '../.env' }); // загружает .env из родительской директории

const { MongoClient } = require('mongodb');

const mongourl = process.env.MONGODB_URL
const dbName = process.env.MONGO_DB;
console.log(mongourl, dbName);


async function saveVendorToMongoDB(vendorData) {
    const client = new MongoClient(mongourl);
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('vendors');

        const filter = { EmailAddress: vendorData.EmailAddress };
        const update = { $set: vendorData };
        const options = { upsert: true };

        await collection.updateOne(filter, update, options);
        
        // Принудительно применяем изменения
        //await db.command({ fsync: 1 });
        
        console.log(`Supplier ${vendorData.EmailAddress} saved/updated in MongoDB`);
    } catch (error) {
        console.error('Error saving supplier to MongoDB:', error);
        throw error;
    } finally {
        await client.close();
    }
}

async function getStatistics(vendor_email, order_id) {
    let client;
    try {
        client = await MongoClient.connect(mongourl);
        const db = client.db(dbName);
        const statsCollection = db.collection('statistics');
        
        let emailDomain;
        if (vendor_email.split('@')[1] === 'app.partsrfq.com') {
            emailDomain = vendor_email.split('@')[0];
        } else {
            emailDomain = vendor_email.split('@')[1]; // Извлекаем домен из адреса электронной почты
        }

        const result = await statsCollection.findOne({
            vendor_email: { $regex: emailDomain, $options: 'i' }, // Ищем по совпадению домена
            order_id
        });
        return result ? true : false ; 
    } catch (error) {
        console.error('Error getting statistics:', error);
        throw error;
    } finally {
        if (client) {
            await client.close();
        }
    }
}

async function saveStatistics(part_number, vendor_email, company_name, order_id, reference_no) {
    const client = new MongoClient(mongourl);
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('statistics');
        
        await collection.insertOne({
            marketplace: 'PARTSBASE',
            part_number,
            vendor_email: vendor_email?.toLowerCase() || company_name?.toLowerCase().replace(',', '').replace(/\s/g, ''),
            created_at: new Date(),
            order_id,
            reference_no
        });
        
    } catch (error) {
        console.error('Error saving statistics to MongoDB:', error);
        throw error;
    } finally {
        await client.close();
    }
}

async function saveProcessedOrder(order, status = 'success') {
    console.log(mongourl, dbName);
    const client = new MongoClient(mongourl);
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('orders');
        
        const orderData = {
            ...order,
            marketplace: "PARTSBASE",
            processedAt: new Date(),
            processing_status: status
        };
        
        
        // Пытаемся вставить новый заказ
        try {
            const result = await collection.insertOne(orderData);
            console.log(new Date(), `Order ${order.id} successfully saved in MongoDB. Document ID: ${result.insertedId}`);
            
            // Проверяем, что документ действительно сохранен
            const savedOrder = await collection.findOne({ _id: result.insertedId });
            if (savedOrder) {
                console.log(new Date(), 'Confirmation of saving - document found');
            } else {
                console.error(new Date(), 'Error: document not found after saving');
            }
        } catch (error) {
            if (error.code === 11000) { // Код ошибки дубликата в MongoDB
                console.log(new Date(), `Order ${order.id} already exists for marketplace PARTSBASE, skipping...`);
            } else {
                throw error; // Пробрасываем другие ошибки
            }
        }
        
    } catch (error) {
        console.error(new Date(), 'Critical error working with MongoDB:', error);
        throw error;
    } finally {
        try {
            await client.close();
            console.log(new Date(), 'Connection to MongoDB closed');
        } catch (closeError) {
            console.error(new Date(), 'Error closing connection:', closeError);
        }
    }
}

async function getUnprocessedOrders(orders) {
    console.log('getUnprocessedOrders');
    console.log(mongourl, dbName);
    const client = new MongoClient(mongourl);
    try {
        if (!orders || !Array.isArray(orders) || orders.length === 0) {
            console.log('No orders to process');
            return [];
        }

        await client.connect();
        const db = client.db(dbName);
        const ordersCollection = db.collection('orders');

        // Находим заказы, которые уже обработаны (имеют marketplace PARTSBASE)
        const processedOrders = await ordersCollection.find(
            {
                id: { $in: orders.map(o => o.id) },
                marketplace: "PARTSBASE"
            },
            { projection: { id: 1 } }
        ).toArray();
        console.log('processedOrders: ', processedOrders.length);
        const processedIds = new Set(processedOrders?.map(o => o.id));
        return orders
            .filter(order => !processedIds.has(order.id))
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)) // Сортировка по timestamp (новые сначала)
    } catch (error) {
        console.error('Error getting unprocessed orders:', error);
        throw error;
    } finally {
        if (client) {
            await client.close();
        }
    }
}

async function getRecentStatistics(part_number, email) {
    const client = new MongoClient(mongourl);
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('statistics');
        
        // Проверяем email на null/undefined
        if (!email) {
            return false;
        }
        
        // Извлекаем домен из email и экранируем специальные символы
        const emailDomain = email.split('@')[1] || email;
        const escapedDomain = emailDomain.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        
        // Находим записи за последние 3 дня
        const threeDaysAgo = new Date();
        threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);
        
        const result = await collection.findOne({
            part_number,
            vendor_email: { $regex: `.*${escapedDomain}.*`, $options: 'i' },
            created_at: { $gte: threeDaysAgo }
        });
        
        return result !== null;
    } catch (error) {
        console.error('Error getting recent statistics:', error);
        throw error;
    } finally {
        await client.close();
    }
}

// Новая функция для подсчета обработанных заказов за сегодня
async function getTodaysProcessedOrdersCount() {
    const client = new MongoClient(mongourl);
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('orders');
        
        // Получаем начало текущего дня (00:00)
        const startOfDay = new Date();
        startOfDay.setHours(0, 0, 0, 0);
        
        // Получаем текущее время
        const now = new Date();
        
        // Считаем количество обработанных заказов PARTSBASE с полуночи до сейчас
        const count = await collection.countDocuments({
            marketplace: "PARTSBASE",
            processedAt: {
                $gte: startOfDay,
                $lte: now
            }
        });
        
        console.log(`Found ${count} PARTSBASE orders processed today`);
        return count;
        
    } catch (error) {
        console.error('Error getting today\'s processed orders count:', error);
        return 0;
    } finally {
        await client.close();
    }
}

module.exports = {
    saveVendorToMongoDB,
    saveStatistics,
    saveProcessedOrder,
    getUnprocessedOrders,
    getStatistics,
    getRecentStatistics,
    getTodaysProcessedOrdersCount
}; 