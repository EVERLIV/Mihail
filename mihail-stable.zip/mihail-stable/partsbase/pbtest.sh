TOKEN="eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6ImEzck1VZ01Gdjl0UGNsTGE2eUYzekFrZnF1RSIsImtpZCI6ImEzck1VZ01Gdjl0UGNsTGE2eUYzekFrZnF1RSJ9.eyJpc3MiOiJodHRwczovL2F1dGgucGFydHNiYXNlLmNvbSIsImF1ZCI6Imh0dHBzOi8vYXV0aC5wYXJ0c2Jhc2UuY29tL3Jlc291cmNlcyIsImV4cCI6MTc0NjgxOTc1MywibmJmIjoxNzQ2ODE0NzUzLCJjbGllbnRfaWQiOiJTU1NMQVBJIiwic2NvcGUiOiJhcGkiLCJzdWIiOiI1NTIiLCJhdXRoX3RpbWUiOjE3NDY4MTQ3NTIsImlkcCI6Imlkc3J2IiwicHJlZmVycmVkX3VzZXJuYW1lIjoibGl6YS53dSIsIkFwaVNjb3BlIjpbIkludmVudG9yeUltcG9ydCIsIlNlbmRRdW90ZSIsIkludmVudG9yeUV4cG9ydCIsIlJlYWxUaW1lU2VhcmNoIiwiU2VuZFJGUSJdLCJyb2xlIjoiUGFydHNCYXNlIFB1YmxpYyBBcGkgVXNlciIsIkVtcGxveWVlSWQiOiIzNTkwMDQiLCJJUFJlc3RyaWN0ZWQiOiJGYWxzZSIsIlRocm90dGxpbmciOiJGYWxzZSIsImp0aSI6ImRmM2Y5ODdkNjE2MDBkNjM1NTQ1NWVlMWMxZjM4MjY1IiwiYW1yIjpbInBhc3N3b3JkIl19.IL-9F2mV2MEM7A8Sl0LRzu_nj7pWrvNQUNoXLERa4XPJyQ-kMc_t3bEeDu0drjWoJfV0V99d9qJoDiKkI9hTNih_1FAGTXNJCQJl7MezFxacO8-0Tti9VEqTg8XW4ZMvu5lE8uHVFMEveDlkK3bzkoB5mjo_NQlLMcmxabZF7_f6aqyfdr9FKOhoxJ7ZJd2kNcxFm5HTXwlCjHVyCQDhYH_XCDqo0pQhc85ODgqOMYouJGVHV39AlYErcL6t6dD8HSqbP75eIquhJ6IvoNHQpIjQO0j2v9TePGU752Tm4G98LYZMerro6Udf1nuJAkLbLXtI0GcINt9uOK9pR-y3gQ"

curl --http1.1 -X POST \
 -H "Content-Type: application/json" \
 -H "Authorization: Bearer ${TOKEN}" \
 -d '{
  "Parts": [ { "InventoryId": 1620821965, "Quantity": 2, "UoM": "EA" } ],
  "ResponseByDate": "2025-05-16",
  "LeadTime": 60,
  "RFQTrackingNo": "SSS96222",
  "Comments": "AOG RFQ 36-092-0001",
  "MRO": false
}' "https://services.partsbase.com/api-sendrfq"
