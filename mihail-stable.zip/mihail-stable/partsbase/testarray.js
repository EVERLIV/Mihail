const myarray =[
    { InventoryId: 2383496541, Quantity: 1, UoM: 'EA' },
    { InventoryId: 2383496541, Quantity: 1, UoM: 'EA' }
  ]

  let  myparts = myarray.map(part => JSON.stringify(part))
  myparts = Array.from(new Set(myparts))
  myparts = myparts.map(part => JSON.parse(part))
  console.log(
    myparts
  )