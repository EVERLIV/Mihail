// s7index.js
require('dotenv').config();
require('dotenv').config({ path: '../.env' });
const puppeteer = require('puppeteer');
const { MongoClient } = require('mongodb');
const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
const fs = require('fs');

const apiUrl = process.env.PANTHEON_API_URL;
const getCustPropS7 = process.env.GET_CUST_PROP_S7;
const token = process.env.API_AUTH_TOKEN;

const getCustPropS7Url = `${apiUrl}${getCustPropS7}`;
const getCustPropS7Headers = {
    'Content-Type': 'application/json',
    'Authorization': `${token}`
};

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
var started = new Date()
var status = "New";

const getCustPropS7Data = async () => {

    let respData = [];
    try {

        let response = await fetch(getCustPropS7Url, {
            method: 'GET',
            headers: getCustPropS7Headers,
        });

        console.log(new Date().toLocaleString(), 'Response status:', {
            status: response.status,
            statusText: response.statusText
        });

        respData = await response.json();
        console.log(new Date().toLocaleString(), 'Загружено из пантеона: ' +  respData.length + ' предложений');

    } catch (error) {
        console.error('Error fetching data from S7:', error);
        return [];
    }

    // Оптимизированная фильтрация через MongoDB
    const client = new MongoClient(config.mongoUrl);
    try {
        await client.connect();
        const db = client.db(config.dbName);
        const s7cpCollection = db.collection('s7_cp');

        // Создаем индекс если его нет (выполняется только один раз)
        await s7cpCollection.createIndex({
            status: 1,
            "data.proposal_id": 1
        }, {
            background: true,
            name: "status_proposal_id"
        });

        // Получаем только ID входящих предложений
        const incomingIds = respData.map(p => p.proposal_id);

        // Оптимизированный запрос только по нужным ID
        const processedProposals = await s7cpCollection.aggregate([
            {
                $match: {
                    //status: "Success",
                    "data.proposal_id": { $in: incomingIds }
                }
            },
            {
                $project: {
                    _id: 0,
                    "proposal_id": "$data.proposal_id"
                }
            }
        ]).toArray();

        const processedIds = new Set(processedProposals.map(p => p.proposal_id));

        // Фильтруем локально
        respData = respData.filter(proposal => !processedIds.has(proposal.proposal_id));

        console.log(new Date().toLocaleString(), `Filtered out ${processedIds.size} already processed proposals from ${incomingIds.length} incoming`);
    } catch (error) {
        console.error('Error filtering processed proposals:', error);
    } finally {
        await client.close();
    }

    // this should run only on development
    // if (process.env.NODE_ENV === 'development') {
    // respData = respData.filter(item => 
    //     item.parts.some(part => part.cert_file_name))
    //     .map(item => ({
    //         ...item,
    //         parts: item.parts.filter(part => part.cert_file_name)
    //     }));
    // }

    return respData;
}



// Configuration
const config = {
    portalUrl: 'https://profile.airquotation.com/',
    credentials: {
        email: process.env.USERLOGIN,
        password: process.env.USERPASSWORD
    },
    mongoUrl: process.env.MONGODB_URL,
    dbName: process.env.MONGO_DB,
    supportedCurrencies: ['USD', 'CNY', 'RUR', 'EUR', 'INR', 'AED', 'BYN', 'CAD'],
    // supportedRegions: ['USA', 'EU&UK', 'UAE', 'China', 'HKG', 'Turkey', 'India', 'Russia'],
    // regionMapping: {
    //     'US': 'USA',
    //     'USA': 'USA',
    //     'EU': 'EU&UK',
    //     'Paris, Fra': 'EU&UK',
    //     'Netherland': 'EU&UK',
    //     'BE': 'EU&UK',
    //     'DE': 'EU&UK',
    //     'AE': 'UAE',
    //     'CN': 'China',
    //     'China': 'China',
    //     'HK': 'HKG',
    //     'TR': 'Turkey',
    //     'IN': 'India',
    //     'RU': 'Russia'
    // },
    conditionMapping: {
        'NF': 'Factory New',
        'NS': 'New Surplus',
        'NE': 'New',
        'OH': 'Overhauled',
        'SV': 'Serviceable',
        'IT': 'Inspected/Tested',
        'RP': 'Repaired'
    }
};

// Helper function to wait for element with timeout
async function waitForElement(page, selector, timeout = 30000) {
    try {
        await page.waitForSelector(selector, { timeout });
        return true;
    } catch (error) {
        console.error(`Element not found: ${selector}`);
        return false;
    }
}

// Main function to process a single proposal
async function processProposal(browser, page, proposal) {

    console.log(new Date().toLocaleString(), 'Processing proposal:');
    console.log(new Date().toLocaleString(), proposal);

    for (const part of proposal.parts) {
        console.log(new Date().toLocaleString(), 'Processing part:', part.part_number);


        try {
            // Search for RFQ
            await waitForElement(page, '[data-testid="requirements-registry-filters-filters-pane-search-input-input"]').catch(async error => {
                console.error('Error waiting for selector:', error);
                await page.reload({ waitUntil: 'networkidle0' });
            

            });
            await page.click('[data-testid="requirements-registry-filters-filters-pane-search-input-input"]').catch(async error => {
                console.error('Error clicking selector:', error);
                console.log(new Date().toLocaleString(), 'Exiting, cant click selector...');
                
                process.exit(1);
            });
            // await page.keyboard.press('Control+A');
            // await page.keyboard.press('Backspace');
            await page.evaluate(() => {
                document.querySelector('[data-testid="requirements-registry-filters-filters-pane-search-input-input"]').value = '';
            });
            await page.type('[data-testid="requirements-registry-filters-filters-pane-search-input-input"]',
                part.requested_part_number || part.part_number);


            await delay(15000);
            
            // Проверяем, есть ли на странице текст "went wrong"
            const bodyText = await page.evaluate(() => document.body.textContent);
            if (bodyText.includes('went wrong')) {
                console.log(new Date().toLocaleString(), 'Обнаружена ошибка "went wrong", обновляем страницу...');
                await page.reload({ waitUntil: 'networkidle0' });
            }

            // Wait for search results 
            await waitForElement(page, `[data-testid="number-navigate"]`);
            // Ждем появления таблицы результатов
            await waitForElement(page, '[data-testid="requirements-registry-table"]');

            // Получаем все строки таблицы
            const rows = await page.$$('[data-testid="requirements-registry-table"] tbody tr');
            console.log(new Date().toLocaleString(), 'Найдено строк:', rows.length);

            let newPagePromise;
            let newPage;
            let foundRow = false;
            const searchNumber = proposal.request_number.split(' ')[0];
            console.log(new Date().toLocaleString(), `Ищем запрос: ${searchNumber}`);

            // Проходим по строкам и ищем нужную
            for (const row of rows) {
                if (foundRow) break;

                try {
                    // Проверяем статус (должен быть Open)
                    const statusElement = await row.$('[class*="actualityRequirementView"] [class*="actuality"]');
                    if (!statusElement) {
                        status = "Not found";
                        console.log(new Date().toLocaleString(), 'Статус не найден для строки, пропускаем');
                        continue;
                    }
                    const addstatus = await statusElement.evaluate(el => el.textContent);
                    console.log(new Date().toLocaleString(), 'Найден статус:', addstatus);

                    if (addstatus !== 'Open') {
                        console.log(new Date().toLocaleString(), 'Пропускаем строку со статусом:', addstatus);
                        continue;
                    }

                    // Получаем все номера запросов из колонки Requests
                    const requestsCell = await row.$('[data-id="requests"]');
                    const requestNumbers = await requestsCell.$$eval('[class*="listClamp"] span',
                        spans => spans.map(span => span.textContent.trim())
                    );
                    console.log(new Date().toLocaleString(), 'Найденные номера запросов:', requestNumbers);

                    // Проверяем каждый номер запроса
                    if (requestNumbers.some(num => num === searchNumber)) {
                        console.log(new Date().toLocaleString(), 'Нашли нужную строку с номером запроса:', searchNumber);
                        foundRow = true;
                        // Нашли нужную строку, кликаем по ссылке
                        newPagePromise = new Promise(resolve => browser.once('targetcreated', target => resolve(target)));
                        const link = await row.$('[data-testid="number-navigate"]');
                        if (link) {
                            console.log(new Date().toLocaleString(), 'Кликаем по ссылке...');
                            await link.click();
                            newPage = await newPagePromise;
                            await delay(2000);
                            newPage = await newPage.page();
                            console.log(new Date().toLocaleString(), 'Новая страница открыта');
                        } else {
                            console.log(new Date().toLocaleString(), 'Ссылка не найдена');
                        }
                    }
                } catch (error) {
                    console.error(`Error processing row:`, error);
                    console.error('Stack trace:', error.stack);
                    continue;
                }
            }

            if (!foundRow) {
                console.log(new Date().toLocaleString(), `Не найдена строка для запроса: ${searchNumber}`);
                status = "Not found";
                await saveResultToDB(proposal, part);//--------------------------------------------------------------------------------------------------
                continue;
            }

            await delay(2000);//newPage.waitForNavigation({ waitUntil: 'networkidle0' });
            const requirementData = await newPage.waitForSelector('[data-testid="requirement-card-actual-info-requirement-actuality"]').catch(async error => {
                console.error('Error waiting for selector:', error);
                await newPage.reload({ waitUntil: 'networkidle0' });
            });
            const requirementText = await requirementData.evaluate(el => el.textContent);
            if (requirementText.includes('Closed')) {
                console.log(new Date().toLocaleString(), 'Requirement is closed');
                await newPage.close();
                //proces mongodb record with response
                continue;
            }



            // Wait for Add Quote button and click it
            await waitForElement(newPage, '[data-testid="requirement-card-actual-info-requirement-add-quote"]');
            await newPage.click('[data-testid="requirement-card-actual-info-requirement-add-quote"]');

            await delay(1000);
            // Fill the form
            await newPage.click('[data-testid="requirement-card-offer-form-part-number"]');
            for (let i = 0; i < 20; i++) {
                await newPage.keyboard.press('Backspace');
            }
            await newPage.type('[data-testid="requirement-card-offer-form-part-number"]', part.part_number);

            await waitForElement(newPage, '[data-testid="requirement-card-offer-form-part-number"]');
            const currentValue = await newPage.evaluate(() => document.querySelector('[data-testid="requirement-card-offer-form-part-number"]').value);
            if (!currentValue) {
                await newPage.type('[data-testid="requirement-card-offer-form-part-number"]', part.part_number);
            }
            //await newPage.type('[data-testid="requirement-card-offer-form-part-number"]', part.part_number);

            // Select condition
            await newPage.click('[data-testid="requirement-card-offer-form-condition"]');
            await waitForElement(newPage, '[data-testid="requirement-card-offer-form-condition-list"]');
            const conditionOptions = await newPage.$$('[data-testid="requirement-card-offer-form-condition-list"] div');
            const mappedCondition = config.conditionMapping[part.condition] || 'New';
            for (const option of conditionOptions) {
                const text = await option.evaluate(el => el.textContent);
                if (text.trim() === mappedCondition) {
                    await option.click();
                    break;
                }
            }

            // Fill other fields
            await newPage.click('[data-testid="requirement-card-offer-form-quantity"]');
            for (let i = 0; i < 10; i++) {
                await newPage.keyboard.press('Backspace');
            }
            await newPage.type('[data-testid="requirement-card-offer-form-quantity"]', part.qty.toString());
            await newPage.type('[data-testid="requirement-card-offer-form-price"]', part.price.toString());
            await newPage.type('[data-testid="requirement-card-offer-form-lead-time"]', (part.lead_time + 3).toString());
            await newPage.type('[data-testid="requirement-card-offer-form-incoterms"]', 'EXW');

            // Select currency and shipment country
            const currency = part.currency || 'USD';
            if (!config.supportedCurrencies.includes(currency)) {
                throw new Error(`Unsupported currency: ${currency}`);
            }
            await newPage.click('[data-testid="requirement-card-offer-form-currency"]');
            await waitForElement(newPage, '[data-testid="requirement-card-offer-form-currency-list"]');
            const currencyOptions = await newPage.$$('[data-testid="requirement-card-offer-form-currency-list"] div');
            for (const option of currencyOptions) {
                const text = await option.evaluate(el => el.textContent);
                if (text.trim() === currency) {
                    await option.click();
                    break;
                }
            }


            //<input type="checkbox" name="isLogisticCostsIncluded" class="input-0-1-744" data-testid="requirement-card-offer-form-logistic-costs-included-input" checked="">
            await newPage.evaluate(() => {
                document.querySelector('[data-testid="requirement-card-offer-form-logistic-costs-included-input"]').checked = true;
            });

            //Postpayment <input data-testid"requirement-card-offer-form-percent-net" class="input-0-1-751 withFloatingLabel-0-1-757 withIcons-0-1-783 withControls-0-1-784" type="text" value="">
            await newPage.type('[data-testid="requirement-card-offer-form-percent-net"]', '0');

            // Select shipment region
            //const region = config.regionMapping[part.shipmentCountry] || part.shipmentCountry || 'USA';
            //<div class="list-0-1-766" data-testid="requirement-card-offer-form-shipment-region-list"><div class="cell-0-1-767 focused-0-1-770" data-disabled="false" data-active="false" data-focused="true">USA</div><div class="cell-0-1-767" data-disabled="false" data-active="false" data-focused="false">EU&amp;UK</div><div class="cell-0-1-767" data-disabled="false" data-active="false" data-focused="false">UAE</div><div class="cell-0-1-767" data-disabled="false" data-active="false" data-focused="false">China</div><div class="cell-0-1-767" data-disabled="false" data-active="false" data-focused="false">HKG</div><div class="cell-0-1-767" data-disabled="false" data-active="false" data-focused="false">Turkey</div><div class="cell-0-1-767" data-disabled="false" data-active="false" data-focused="false">India</div><div class="cell-0-1-767" data-disabled="false" data-active="false" data-focused="false">Russia</div></div>
            await waitForElement(newPage, '[data-testid="requirement-card-offer-form-shipment-region"]');
            await newPage.click('[data-testid="requirement-card-offer-form-shipment-region"]');
            await delay(1000);
            // await waitForElement(newPage, '[data-testid="requirement-card-offer-form-shipment-region-list"]');
            // const regionOptions = await newPage.$$('[data-testid="requirement-card-offer-form-shipment-region-list"] div');
            // if (!config.supportedRegions.includes(region)) {
            await newPage.type('[data-testid="requirement-card-offer-form-shipment-region"]', part.delivery_place);
            await delay(1000);

            
            // await newPage.evaluate((deliveryPlace) => {
            //     document.querySelector('[data-testid="requirement-card-offer-form-shipment-region"]').value = deliveryPlace;
            // }, part.delivery_place);
            // } else {
            //     for (const option of regionOptions) {
            //         const text = await option.evaluate(el => el.textContent);
            //         if (text.trim() === region) {
            //             await option.click();
            //             break;
            //         }
            //     }

            // }

            let comment = `${part.comment ?? ''} | MOV $100`.replace(/^\s*\|\s*/, '');
            await newPage.click('[data-testid="requirement-card-offer-form-incoterms"]');
            await newPage.type('[data-testid="requirement-card-offer-form-supplier-note"]', comment);

            if (part.cert_file_name) {
                try {
                    console.log(new Date().toLocaleString(), 'Downloading file from S3:', part.cert_file_name);
                    const fileData = await downloadFileFromS3(part.cert_file_name);
                    console.log(new Date().toLocaleString(), 'File data size:', fileData.length);

                    const uploadResult = await newPage.evaluate(async (fileName, data) => {
                        return new Promise(async (resolve) => {
                            try {
                                const fileInput = document.querySelector('[data-testid="requirement-card-offer-form-files-input"]');
                                console.log(new Date().toLocaleString(), 'File input found:', !!fileInput);

                                // Проверяем данные
                                console.log(new Date().toLocaleString(), 'Data array length:', data.length);
                                if (!data || data.length === 0) {
                                    throw new Error('Empty file data');
                                }

                                // Создаем File из Uint8Array
                                const uint8Array = new Uint8Array(data);
                                console.log(new Date().toLocaleString(), 'Uint8Array created, length:', uint8Array.length);

                                const file = new File([uint8Array], fileName, { type: 'application/pdf' });
                                console.log(new Date().toLocaleString(), 'File created, size:', file.size);

                                if (file.size === 0) {
                                    throw new Error('Created file is empty');
                                }

                                // Создаем FileList
                                const dataTransfer = new DataTransfer();
                                dataTransfer.items.add(file);

                                // Устанавливаем files напрямую
                                Object.defineProperty(fileInput, 'files', {
                                    value: dataTransfer.files,
                                    writable: true
                                });

                                // Вызываем событие change
                                const changeEvent = new Event('change', { bubbles: true });
                                fileInput.dispatchEvent(changeEvent);
                                console.log(new Date().toLocaleString(), 'change event dispatched');

                                // Проверяем результат
                                setTimeout(() => {
                                    const result = {
                                        filesCount: fileInput.files.length,
                                        fileName: fileInput.files[0]?.name,
                                        fileSize: fileInput.files[0]?.size,
                                        fileType: fileInput.files[0]?.type
                                    };
                                    console.log(new Date().toLocaleString(), 'Upload result:', result);
                                    resolve(result);
                                }, 2000);
                            } catch (error) {
                                console.error('Error in evaluate:', error);
                                resolve({
                                    error: error.message,
                                    filesCount: 0
                                });
                            }
                        });
                    }, 'cert_' + part.part_number + '.pdf', Array.from(new Uint8Array(fileData)));

                    console.log(new Date().toLocaleString(), 'File upload verification:', uploadResult);
                    if (uploadResult.error || uploadResult.filesCount === 0) {
                        throw new Error(`File upload failed: ${uploadResult.error || 'No files uploaded'}`);
                    }

                    // Ждем появления индикатора загрузки файла
                    // await newPage.waitForSelector('[class*="upload-progress"]', { timeout: 30000 }).catch(() => {
                    //     console.log(new Date().toLocaleString(), 'No upload progress indicator found, continuing...');
                    //     throw new Error('No upload progress indicator found');
                    // });

                    // Ждем завершения загрузки
                    await delay(15000);
                } catch (certError) {
                    console.error('Certificate upload error:', certError);
                    status = "Failed";
                    
                    // Добавляем текущий part в конец массива для повторной обработки
                    proposal.parts.push(part);
                                        
                    // Закрываем страницу парта
                    await newPage.close();
                    
                    continue; // Переходим к следующему part
                }
            }

            await delay(2000);

            // Submit the form
            await waitForElement(newPage, 'button[data-testid="requirement-card-offer-form-submit"]');
            await newPage.click('button[data-testid="requirement-card-offer-form-submit"]');//----------------------------------------------------------

            // Ждем подтверждения отправки
            await delay(5000);

            status = "New";
            // Проверяем, что форма действительно отправилась
            const submitButton = await newPage.$('button[data-testid="requirement-card-offer-form-submit"]');
            if (submitButton) {
                const isDisabled = await submitButton.evaluate(button => button.disabled);
                if (!isDisabled) {
                    status = "Failed";
                    console.log(new Date().toLocaleString(), 'Form submission failed, adding part to retry queue...');
                    
                    // Добавляем текущий part в конец массива для повторной обработки
                    proposal.parts.push(part);
                    
                    // Закрываем страницу парта
                    await newPage.close();
                    
                    // Обновляем главную страницу
                    //await page.reload({ waitUntil: 'networkidle0' });
                    await delay(3000);
                    
                    continue; // Переходим к следующему part
                } else {
                    status = "Success";
                }
            } else {
                status = "Success";
            }

            // Сохраняем результат в MongoDB
            await saveResultToDB(proposal, part);//----------------------------------------------------------------------------------------------------

            await delay(2000);

            // Закрываем страницу парта
            await newPage.close();
        } catch (error) {
            console.error(`Error processing proposal ${proposal.request_number}:`, error);
        }
    }
}

async function saveResultToDB(proposal, part) {
    const client = new MongoClient(config.mongoUrl);
    try {
        await client.connect();
        const db = client.db(config.dbName);
        const s7cpCollection = db.collection('s7_cp');

        const now = new Date();
        const record = {
            name: `${proposal.proposal_id} ${part.part_number} ${part.price}`,
            status: status,
            created: now.toLocaleString(),
            started: started.toLocaleString(),
            updated: now.toLocaleString(),
            // priority: part.priority,
            data: {
                proposal_id: proposal.proposal_id,
                request_number: proposal.request_number,
                part_number: part.part_number,
                requested_part_number: part.requested_part_number || part.part_number,
                condition: part.condition,
                price: part.price,
                currency: part.currency,
                qty: part.qty,
                comment: part.comment || "",
                lead_time: part.lead_time,
                time_unit: part.time_unit,
                delivery_condition: part.delivery_condition,
                delivery_place: part.delivery_place,
                is_moq: part.is_moq,
                cert_file_name: part.cert_file_name || ""
            }
        };

        await s7cpCollection.insertOne(record);
        console.log(new Date().toLocaleString(), `Saved proposal result to MongoDB: ${record.name}`);
    } catch (error) {
        console.error('Error saving to MongoDB:', error);
    } finally {
        await client.close();
    }
}

async function downloadFileFromS3(fileName) {
    try {
        const s3Client = new S3Client({
            region: process.env.S3_REGION,
            credentials: {
                accessKeyId: process.env.S3_ACCESS_KEY,
                secretAccessKey: process.env.S3_SECRET_KEY
            },
            endpoint: process.env.S3_ENDPOINT_URL
        });

        const params = {
            Bucket: process.env.S3_BUCKET_NAME,
            Key: fileName
        };
        const command = new GetObjectCommand(params);
        const response = await s3Client.send(command);

        // Преобразуем поток в Buffer
        const chunks = [];
        for await (const chunk of response.Body) {
            chunks.push(chunk);
        }
        const buffer = Buffer.concat(chunks);

        console.log(new Date().toLocaleString(), 'File size downloaded from S3:', buffer.length);
        return buffer;
    } catch (error) {
        console.error('Error downloading file from S3:', error);
        throw error;
    }
}

// Main execution function
async function main() {
    let custPropS7Data = await getCustPropS7Data();
    console.log(new Date().toLocaleString(), 'Cust prop S7 data length:', custPropS7Data.length);


    if (custPropS7Data.length === 0) {
        console.log(new Date().toLocaleString(), 'No data to process, delaying 10 seconds...');
        await delay(10000);
        return;
    }

    const browser = await puppeteer.launch({
        headless: process.env.NODE_ENV === 'development' ? false : "new",
        userDataDir: './s7_browsercache',
        persistentContext: true,
        defaultViewport: null,
        args: [
            '--start-maximized',
            '--no-sandbox',
            //'--disable-setuid-sandbox'
        ]
    });
    const page = await browser.newPage();
    await page.setViewport({ width: 1920, height: 1080 });

    // Block images
    await page.setRequestInterception(true);
    page.on('request', (request) => {
        if (request.resourceType() === 'image') {
            request.abort();
        } else {
            request.continue();
        }
    });

    try {
        // Login
        await page.goto(config.portalUrl);
        await delay(10000);

        let userInput = await page.$('#usernameUserInput');
        if (userInput) {
            await userInput.type(config.credentials.email);
        }
        let passwordInput = await page.$('#password');
        if (passwordInput) {
            await passwordInput.type(config.credentials.password);  
            await page.click('[data-testid="login-page-continue-login-button"]');
        }   


        // Process each proposal
        // if (process.env.NODE_ENV === 'development') {
        //     custPropS7Data = custPropS7Data.slice(0, 1);
        // }
        await delay(10000);

        for (const proposal of custPropS7Data) {
            await processProposal(browser, page, proposal);
        }

    } catch (error) {
        console.error('Main execution error:', error);
        await page.screenshot({ path: `main_error_${Date.now()}.png` });
    } finally {
        await browser.close();
    }
}

main().catch(console.error);
