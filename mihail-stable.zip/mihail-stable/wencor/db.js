require('dotenv').config({ path: '../.env' }); // загружает .env из родительской директории

const { MongoClient } = require('mongodb');

// Используем тот же URL, но добавляем параметры подключения
const mongourl = process.env.MONGODB_URL;
const dbName = process.env.MONGO_DB;
console.log(mongourl, dbName);

// Добавляем опции для повышения надежности подключения



async function saveVendorToMongoDB(vendorData) {
    let client;
    try {
        client = await MongoClient.connect(mongourl);
        const db = client.db(dbName);
        const vendorsCollection = db.collection('vendors');

        const existingVendor = await vendorsCollection.findOne({
            EmailAddress: vendorData.EmailAddress
        });

        if (existingVendor) {
            const result = await vendorsCollection.updateOne(
                { EmailAddress: vendorData.EmailAddress },
                { $set: vendorData }
            );
            //logger.info(`Vendor data updated, matched: ${result.matchedCount}`);
        } else {
            const result = await vendorsCollection.insertOne(vendorData);
            //logger.info(`New vendor data saved with id: ${result.insertedId}`);
        }
    } catch (error) {
        console.error('Error saving to MongoDB:', error);
        throw error;
    } finally {
        if (client) {
            await client.close();
        }
    }
}

async function saveStatistics(part_number, vendor_email, timestamp) {
    let client;
    try {
        client = await MongoClient.connect(mongourl);
        const db = client.db(dbName);
        const statsCollection = db.collection('statistics');

        await statsCollection.insertOne({
            marketplace: 'WENCOR',
            part_number,
            vendor_email,
            timestamp,
            created_at: new Date()
        });
    } catch (error) {
        console.error('Error saving statistics:', error);
    } finally {
        if (client) {
            await client.close();
        }
    }
}

// Обновляем функции для использования единого подключения
async function saveProcessedOrder(order) {
    let client;
    try {
        client = new MongoClient(mongourl);
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('orders');
        
        // Пытаемся вставить новый документ
        try {
            const orderData = {
                ...order,
                marketplace: "WENCOR", // Устанавливаем marketplace
                processedAt: new Date(),
                processing_status: 'success' // Добавляем статус обработки
            };
            
            //console.log(new Date(), 'Подготовленные данные для сохранения:', JSON.stringify(orderData, null, 2));
            
            const result = await collection.insertOne(orderData);
            
            console.log(new Date(), `Заказ ${order.id} успешно сохранен в MongoDB. ID документа: ${result.insertedId}`);
            
            // Проверяем, что документ действительно сохранен
     
            
        } catch (error) {
            if (error.code === 11000) { // Код ошибки дубликата в MongoDB
                console.log(new Date(), `Заказ ${order.id} уже существует для marketplace wencor, пропускаем...`);
            } else {
                console.error(new Date(), 'Ошибка при сохранении заказа:', error);
                throw error; // Пробрасываем другие ошибки
            }
        }
    } catch (error) {
        console.error(new Date(), 'Критическая ошибка при работе с MongoDB:', error);
        throw error;
    } finally {
        try {
            await client.close();
            console.log(new Date(), 'Соединение с MongoDB закрыто');
        } catch (closeError) {
            console.error(new Date(), 'Ошибка при закрытии соединения:', closeError);
        }
    }
}

async function getUnprocessedOrders(orders) {
    let client;
    try {
        client = new MongoClient(mongourl);
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('orders');
        
        // Получаем список уже обработанных заказов для данного вендора
        const processedOrders = await collection.find(
            {
                id: { $in: orders.map(o => o.id) },
                marketplace: "WENCOR"
            },
            { projection: { id: 1 } }
        ).toArray();
        
        const processedIds = new Set(processedOrders.map(o => o.id));
        
        // Фильтруем только необработанные заказы
        const unprocessedOrders = orders
            .filter(order => !processedIds.has(order.id))
            .filter(order => order.quote_id > 0)
            .filter(order => order.quote_id !== undefined)
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)); // Сортировка по timestamp (новые сначала);
        
        // Ограничиваем количество возвращаемых заказов до 50
        const limitedOrders = unprocessedOrders.slice(0, 20);
        
        console.log(new Date(), `Найдено ${unprocessedOrders.length} необработанных заказов из ${orders.length}, возвращаем ${limitedOrders.length}`);
        return limitedOrders;
    } catch (error) {
        console.error(new Date(), 'Критическая ошибка при работе с MongoDB:', error);
        throw error;
    } finally {
        try {
            await client.close();
            console.log(new Date(), 'Соединение с MongoDB закрыто');
        } catch (closeError) {
            console.error(new Date(), 'Ошибка при закрытии соединения:', closeError);
        }
    }
}



module.exports = {
    saveVendorToMongoDB,
    saveStatistics,
    saveProcessedOrder,
    getUnprocessedOrders,
}; 