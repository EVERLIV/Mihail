require('dotenv').config();
require('dotenv').config({ path: '../.env' }); // загружает .env из родительской директории


const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');

const { hideHeadless } = require('./hideheadless')
puppeteer.use(StealthPlugin());

const { saveProcessedOrder, getUnprocessedOrders, closeMongoConnection } = require('./db');


const fs = require('fs').promises;


// Configuration
const config = {
    homeUrl: process.env.HOMEURL,
    loginURL: process.env.LOGINURL,
    searchURL: process.env.SEARCHURL,
    serverURL: process.env.PANTHEON_API_URL, //TODO - change to production
    postQuoteUrl: process.env.POSTQUOTEURL,
    getOrdersUrl: process.env.GETORDERSURL,
    authToken: process.env.API_AUTH_TOKEN,
    login: process.env.LOGIN,
    password: process.env.PASSWORD,
    outputDir: './output',
    dataFolder: './browsercache', // добавляем папку для данных браузера
    // Delay ranges in milliseconds
    proxyServer: process.env.PROXY_SERVER,
    proxyport: process.env.PROXY_PORT,
    proxyusername: process.env.PROXY_USERNAME,
    proxypassword: process.env.PROXY_PASSWORD,
    delays: {
        typing: { min: 50, max: 100 },
        navigation: { min: 500, max: 2000 },
        clicking: { min: 100, max: 500 }
    }
};

console.log(config.serverURL)
// Добавляем глобальную переменную для хранения заказов
let currentOrders = [];
// let currentQuotes = new Map();
// let PROCESSING = false;

// Добавляем константу для имени вендора
const VENDOR = 'WENCOR';

let completionTimer = null;
const COMPLETION_TIMEOUT = 5 * 60 * 1000; // 3 минуты в миллисекундах

function resetCompletionTimer(browser) {
    if (completionTimer) {
        clearTimeout(completionTimer);
    }
    
    completionTimer = setTimeout(async () => {
        console.log(new Date(), 'Нет новых ответов в течение 3 минут, завершаем работу');
        for(let order of currentOrders) {
            await saveProcessedOrder(order);
        }
            await browser.close();
            await delay(60000);
            process.exit(0);
        
    }, COMPLETION_TIMEOUT);
}

// Функция получения заказов
async function getOrders() {
    console.log(new Date(),`${config.serverURL}${config.getOrdersUrl}`)
    try {
        const response = await fetch(`${config.serverURL}${config.getOrdersUrl}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': config.authToken
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const orders = await response.json();

        currentOrders = await getUnprocessedOrders(orders, VENDOR);
        console.log(new Date(),'В обработку:', currentOrders.length, 'заказов')
        let altParts = [];
        for (let order of currentOrders) {
            if (order.alternatives.length > 0) {
                for (let alt of order.alternatives) {
                    altParts.push(
                        {   
                            id: order.id,
                            part_number: alt,
                            qty: order.qty,
                            quote_id: order.quote_id,
                            alternatives: []
                        }
                    );
                }
            }
        }
        currentOrders = currentOrders.concat(altParts);
        console.log(new Date(),'В обработку с альтернативными номерами:', currentOrders.length, 'заказов')

        return currentOrders;

    } catch (error) {
        console.error(new Date(),'Ошибка при получении заказов:', error.message);
        return null;
    }
}

async function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}



async function processProposal(proposal) {
    const matchingOrder = currentOrders.find(order => 
        order.part_number === proposal.name
    );

    if (matchingOrder) {
        
        // Округляем цену до целого числа в большую сторону
        const roundedPrice = Math.ceil(proposal.gross);
        
        let notEA;
        if (["EA", "FT", "M", "YD", "KG", "LB", "G", "L", "OZ", "RO", "KT", "CA"].some(unit => unit === proposal.unitCode)) {
            notEA = 'Unit codes are' + proposal.unitCode;
            proposal.unitCode = 'EA';
        } else {
            notEA = '';
        }
        
        const quoteData = {
            part_number: proposal.name.replace(/\//g, '-'),
            qty: Math.ceil(matchingOrder.qty),
            delivery_place: "USA",
            delivery_condition: "EXW",
            item_note: notEA + ' | Quantity available: ' + proposal.stock,
            customer_request_id: matchingOrder.id,
            price: roundedPrice, // Используем округленную цену
            supplier: VENDOR, // Используем константу вместо строки
            quote_id: matchingOrder.quote_id,
            date: new Date().toISOString().split('T')[0],
            valid_to: new Date(new Date().getTime() + 21 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            condition: "NE",
            lead_time: 1,
            time_unit: "D",
            currency: proposal.currency,
            is_moq: false,
            um: proposal.unitCode,
            email_subject: matchingOrder.id + ' ' + matchingOrder.description
        }

        console.log(new Date(),'Sending quote data', quoteData)

        if (matchingOrder.qty <= parseInt(proposal.stock) * 1.2) {
            const sendResult = await sendQuoteData(quoteData);
            if (sendResult) {
                // Сохраняем заказ как обработанный только после успешной отправки
                await saveProcessedOrder(matchingOrder);
                console.log(new Date(), 'Заказ сохранен как обработанный:', matchingOrder.id);
            }
        } else {
            console.log(new Date(),'Не хватает на складе, отменяем', proposal.name, proposal.stock, matchingOrder.qty)
        }
    } else {
        console.log(new Date(),`Нет соответствующего заказа для предложения: ${proposal.name}`);
    }
}

async function sendQuoteData(quoteData) {
    try {
        console.log(`${config.serverURL}${config.postQuoteUrl}`)
        const response = await fetch(`${config.serverURL}${config.postQuoteUrl}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': config.authToken
            },
            body: JSON.stringify(quoteData)
        });

        // if (!response.ok) {
        //     console.log(new Date(), 'Ошибка при отправке данных в пантеон: ', response.status, response.error, response.message);
        //     throw new Error();
        // }

        // const result = await response.json();
        // console.log(new Date() + 'Данные успешно отправлены в пантеон: QuoteID:', quoteData.quote_id, 'Result:', result);
        // return true;
        try {
            const result = await response.json();
            console.log(new Date(), 'Данные успешно отправлены:', 'quote_id:', quoteData.quote_id, 'Result:', result);
            return result;
        } catch (error) {
            console.error(new Date(), 'Ошибка при разборе JSON ответа:', error);
            const textResponse = await response.text();
            console.log(new Date(), 'Текстовый ответ:', textResponse);
            throw error;
        }

    } catch (error) {
        console.error(new Date());
        return false;
    }
}



async function getAllTextFromPage(page) {
    const text = await page.evaluate(() => {
        return document.body.innerText; // Получаем текст из body страницы
    });
    return text.trim().replace(/ /g, '').toLowerCase(); // Убираем лишние пробелы в начале и конце
}

async function login(page) {
    try {
        // Добавляем проверку и скриншот перед попыткой логина
        console.log(new Date(), 'Пытаемся войти в систему');
        
        // Сделаем скриншот для диагностики
        //await page.screenshot({ path: './login_before.png' });
        
        // Проверяем наличие кнопки логина
        const loginButtonExists = await page.evaluate(() => {
            return !!document.querySelector('#util-item-login');
        });
        
        if (!loginButtonExists) {
            console.log(new Date(), 'Кнопка логина не найдена, перезагружаем страницу');
            await page.reload({ waitUntil: 'networkidle2' });
            await delay(5000);
            
            // Еще один скриншот после перезагрузки
            //await page.screenshot({ path: './login_after_reload.png' });
        }
        
        const loginButton = await page.waitForSelector('#util-item-login', { timeout: 10000 })
            .catch(err => {
                console.error(new Date(), 'Не удалось найти кнопку логина:', err.message);
                return null;
            });
            
        if (!loginButton) {
            throw new Error('Кнопка логина не найдена после ожидания');
        }
        
        await loginButton.click();
        
        const loginInput = await page.waitForSelector('input[placeholder="Email Address"]');
        await loginInput.type(config.login);
        
        const loginPassword = await page.waitForSelector('input[placeholder="Password"]');
        await loginPassword.type(config.password);

        const loginCheckbox = await page.waitForSelector('.input-checkbox.rememberme-checkbox[type="checkbox"]');
        await loginCheckbox.click();
        
        const submitButton = await page.waitForSelector('.btn.btn-primary.login-btn[type="submit"]');
        await submitButton.click();
        console.log(new Date(),'Login successful')
        await delay(15000);
    } catch (error) {
        console.error(new Date(), 'Ошибка при входе в систему:', error.message);
        // Делаем скриншот при ошибке
        //await page.screenshot({ path: './login_error.png' });
        await page.goto(config.searchURL);
        throw error;
    }
}

// Основная функция
const main = async () => {
    let orders = await getOrders()

    let ordersText = orders.map(order => `${order.part_number} ${order.qty}`).join('\n')
      
    if (!ordersText) {
            console.log(new Date(),'No orders found - exiting')
            await delay(60000);
            process.exit(0)
        }

    const browser = await puppeteer.launch({
        headless: process.env.NODE_ENV === 'production' ? "new" : false,
        defaultViewport: null,
        args: ['--start-maximized',
            `--proxy-server=http://${config.proxyServer}:${config.proxyport}`,
            '--start-maximized',
            '--disable-session-crashed-bubble',
            '--no-sandbox',
            '--disable-notifications',
            '--disable-dev-shm-usage'
        ],
        userDataDir: './wencor_browsercache',
        persistentContext: true
    });

    //const page = await browser.newPage();
    const page = (await browser.pages())[0];

    await page.authenticate({
        username: config.proxyusername,
        password: config.proxypassword,
    }).catch(err => console.log(new Date(), err))


    // Устанавливаем дату и время в Гонконге
    const hongKongDate = new Date().toLocaleString('en-US', { timeZone: 'Asia/Hong_Kong' });
    const customDate = new Date(hongKongDate).toISOString();

    // Устанавливаем часовой пояс Гонконга
    await page.evaluateOnNewDocument(() => {
        Object.defineProperty(Intl.DateTimeFormat.prototype, 'resolvedOptions', {
            value: function () {
                return { timeZone: 'Asia/Hong_Kong' };
            }
        });

        Object.defineProperty(navigator, 'timezone', {
            value: 'Asia/Hong_Kong'
        });

        Object.defineProperty(Intl, 'defaultLocale', {
            value: 'zh-Hant-HK'
        });
    });


    await page.evaluateOnNewDocument((customDate) => {
        const originalDate = window.Date;
        const offset = new originalDate(customDate).getTime() - originalDate.now();

        window.Date = function () {
            return new originalDate(Date.now() + offset);
        };

        window.Date.now = function () {
            return originalDate.now() + offset;
        };

        const originalPerformanceNow = performance.now.bind(performance);
        performance.now = function now() {
            return originalPerformanceNow() + offset;
        };

        // Переопределяем методы для получения времени
        Intl.DateTimeFormat.prototype.format = function (date) {
            if (!(date instanceof Date)) {
                date = new Date(date);
            }
            return new originalDate(date.getTime() + offset).toLocaleString('en-US', { timeZone: 'Asia/Hong_Kong' });
        };
    }, customDate);

    try {
        await page.emulateTimezone('Asia/Hong_Kong');
    } catch (e) {
        console.warn('Timezone setting not supported:', e.message);
    }

    // Включаем перехват всех запросов
    await page.setRequestInterception(true);

    // Обработчик перехвата запросов
    page.on('request', (request) => {
    // Блокируем запросы на загрузку изображений
    if (request.resourceType() === 'image') {
        request.abort(); // Прерываем загрузку
    } else {
        request.continue(); // Разрешаем остальные запросы
    }
    });



    // Добавим обработку сигналов завершения
    process.on('SIGTERM', async () => {
        console.log(new Date(),'SIGTERM received. Shutting down gracefully');
        await closeMongoConnection();
        process.exit(0);
    });

    process.on('SIGINT', async () => {
        console.log(new Date(),'SIGINT received. Shutting down gracefully');
        await closeMongoConnection();
        process.exit(0);
    });
  


    let parts = []
    let stock = []
    let price = []

    page.on('response', async (response) => {
        try {
            const responseBody = await response.json();
            if(response.url().includes('items/itemcode')) {
                resetCompletionTimer(browser);
                //console.log(new Date(),'Item:', responseBody)
                parts.push(responseBody)
            } else if (response.url().includes('items/stocklevel')) {
                resetCompletionTimer(browser);
                //console.log(new Date(),'Stock:',responseBody)
                if(responseBody.length) {
                    responseBody.forEach(item => {
                        // console.log(JSON.stringify(item))
                        let foundItem = parts.find(part => part.itemNumber === item.itemNumber)
                        if(foundItem && item.stockLevels[0].quantity) {
                            foundItem.stock = item.stockLevels[0].quantity
                            foundItem.unit = item.stockLevels[0].unitCode
                            foundItem.warehouse = item.stockLevels[0].warehouse
                            foundItem.warehouseDetails = item.stockLevels[0].warehouseDetails
                            console.log(new Date(),'Found item with stock', foundItem.name, foundItem.stock, foundItem.unit)
                        } else {
                            stock.push(item)
                        }
                    })
                }
            } else if (response.url().includes('items/price')) {
                //console.log(new Date(),'Price:',responseBody)
                resetCompletionTimer(browser);
                if(responseBody[0].price.gross || responseBody[0].price.net) {
                    let foundItem = parts.find(part => part.itemNumber === responseBody[0].itemNumber)
                    if(foundItem) {
                        foundItem.gross = responseBody[0].price.gross || 0
                        foundItem.net = responseBody[0].price.net || 0
                        foundItem.currency = responseBody[0].price.currencyCode
                    }
                    //console.log(new Date(),'Found item with price', foundItem)
                    await processProposal(foundItem)

                } else {
                    price.push(responseBody)
                }
            }
            

            // [
            //     {
            //       itemNumber: '10008296',
            //       price: {
            //         gross: 21846.87,
            //         grossLocalized: '$21,846.87',
            //         net: 21846.87,
            //         netLocalized: '$21,846.87',
            //         discount: 0,
            //         discountLocalized: '$0.00',
            //         isConsistentDiscountPercentage: null,
            //         discountPercentage: 0,
            //         discountPercentageLocalized: '0%',
            //         exceptionInfo: null,
            //         message: null,
            //         msrpAmount: null,
            //         msrpAmountLocalized: null,
            //         unitPricePerQuantity: null,
            //         unitPricePerQuantityUOM: null,
            //         unitPricePerQuantityUOMCode: null,
            //         priceBreaks: null,
            //         dealerPricesHidden: false,
            //         specialPricePerQuantity: null,
            //         specialPricePerQuantityLocalized: null,
            //         specialPricePerQuantityUOM: null,
            //         specialPricePerQuantityUOMCode: null,
            //         conversionFactor: null,
            //         blanketAgreementId: null,
            //         currencyCode: 'USD'
            //       },
            //       ribbons: null,
            //       unitCode: null,
            //       unit: null
            //     }
            //   ]




           
        } catch (err) {
            //console.log(new Date(),'not json')
        }
    })

    await hideHeadless(page);


    try {
        await page.goto(config.homeUrl);
        await delay(5000);

        // Добавляем скриншот для диагностики
        //await page.screenshot({ path: './homepage.png' });
        
        let pageText = await getAllTextFromPage(page);        
        if (pageText.includes('login')) {
            await login(page);
            await delay(5000);
        } else {
            console.log(new Date(), 'Login button not found');
            // Делаем скриншот, если кнопка не найдена
        }
        
        // Добавляем повторную попытку перехода на страницу поиска
        let maxAttempts = 3;
        let searchPageLoaded = false;
        
        for (let attempt = 1; attempt <= maxAttempts; attempt++) {
            console.log(new Date(), `Попытка ${attempt} перехода на страницу поиска`);
            await page.goto(config.searchURL);
            await delay(15000);
            pageText = await getAllTextFromPage(page);
            //console.log(pageText)
            if (pageText.toLowerCase().includes('powersearch')) {
                console.log(new Date(), 'search page loaded');
                searchPageLoaded = true;
                break;
            } else {
                console.log(new Date(), 'search page not found - trying again');
                //await page.screenshot({ path: `./search_attempt_${attempt}.png` });
                
                
                
                try {

                    await login(page);
                    // Пробуем перезагрузить страницу и снова войти
                    await delay(15000);
                    pageText = await getAllTextFromPage(page);
                    if (pageText.toLowerCase().includes('powersearch')) {
                        searchPageLoaded = true;
                        break;
                    }
                } catch (loginError) {
                    console.error(new Date(), `Ошибка при попытке ${attempt} входа:`, loginError.message);
                    if (attempt === maxAttempts) {
                        throw loginError;
                    }
                }
            }
        }
        
        if (!searchPageLoaded) {
            throw new Error('Не удалось загрузить страницу поиска после нескольких попыток');
        }

        // Добавляем проверку готовности страницы
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 30000 })
            .catch(err => console.log(new Date(), 'Ошибка ожидания загрузки страницы:', err.message));

        // Добавляем скриншот перед ожиданием селектора
        console.log(new Date(), 'Ожидаем селектор #itemnumberinputbox');

        // Проверяем наличие селектора без ожидания
        const selectorExists = await page.evaluate(() => !!document.querySelector('#itemnumberinputbox'))
            .catch(() => false);

        if (!selectorExists) {
            console.log(new Date(), 'Селектор #itemnumberinputbox не найден на странице');
            // Пробуем перезагрузить страницу
            await page.reload({ waitUntil: 'networkidle0' });
            await delay(5000);
        }

        let bulkSearch = await page.waitForSelector('#itemnumberinputbox', { 
            timeout: 30000,
            visible: true 
        }).catch(async (err) => {
            console.log(new Date(), err.message);
            return null;
        });

        if (bulkSearch) {
            await bulkSearch.type(ordersText);
            await delay(10000)
            let submitSearch = await page.waitForSelector('#addToQuickEntry', { timeout: 10000 })
                .catch(async (err) => {
                    console.log(new Date(), 'Кнопка поиска не найдена:', err.message);
                    //await page.screenshot({ path: './submit_button_error.png' });
                    return null;
                });
                
            if (submitSearch) await submitSearch.click();
            else console.log(new Date(), 'Не удалось найти кнопку отправки поиска');
        } else {
            console.log(new Date(), 'Не удалось найти поле ввода для поиска');
        }
            
    } catch (error) {
        console.error('An error occurred:', error);
        // Делаем скриншот при критической ошибке
        //await page.screenshot({ path: './wencor_critical_error.png' });
        await browser.close();
        process.exit(0);
    }



    //await browser.close();
    //process.exit(0);
};

// Запуск приложения
main().catch(error => {
    console.error(new Date(),'Fatal error:', error);
    process.exit(1);
});

