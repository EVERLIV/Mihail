const { listBucketContents } = require('./s3');

async function listDirectory(bucketName, prefix = 'certificates/', level = 0) {
    try {
        const { folders, files } = await listBucketContents(bucketName, prefix);
        
        // Выводим текущую папку
        const indent = '  '.repeat(level);
        console.log(`\n${indent}📁 ${prefix}`);
        
        // Выводим файлы в текущей папке
        if (files.length > 0) {
            files.forEach(file => {
                console.log(`${indent}  📄 ${file.Key.replace(prefix, '')} (${file.Size} bytes, Last modified: ${file.LastModified})`);
            });
        } else {
            console.log(`${indent}  (нет файлов)`);
        }
        
        // Рекурсивно обходим подпапки
        for (const folder of folders) {
            await listDirectory(bucketName, folder, level + 1);
        }
        
        return { folders, files };
    } catch (error) {
        console.error('Ошибка при просмотре содержимого:', error);
        throw error;
    }
}

async function main() {
    try {
        const bucketName = process.env.S3_BUCKET_NAME;
        if (!bucketName) {
            console.error('S3_BUCKET_NAME не установлен в переменных окружения');
            return;
        }

        // Получаем аргумент командной строки для префикса (если есть)
        const prefix = process.argv[2] || 'certificates/';
        
        console.log(`Содержимое папки ${prefix}:`);
        await listDirectory(bucketName, prefix);
    } catch (error) {
        console.error('Ошибка:', error);
    }
}

main(); 