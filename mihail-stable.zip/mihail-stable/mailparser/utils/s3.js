// Загрузка переменных окружения из .env файла
require('dotenv').config();
require('dotenv').config({ path: '../.env' }); 
const { S3Client, ListObjectsV2Command, GetObjectCommand, PutObjectCommand } = require('@aws-sdk/client-s3');
const fs = require('fs');
const path = require('path');

const s3Client = new S3Client({
    region: process.env.S3_REGION,
    credentials: {
      accessKeyId: process.env.S3_ACCESS_KEY,
      secretAccessKey: process.env.S3_SECRET_KEY
    },
    endpoint: process.env.S3_ENDPOINT_URL
});



async function listBucketContents(bucketName, prefix = '') {
    try {
        const command = new ListObjectsV2Command({
            Bucket: bucketName,
            Prefix: prefix,
            Delimiter: '/'
        });
        
        const response = await s3Client.send(command);
        
        // Получаем список подпапок
        const folders = response.CommonPrefixes ? response.CommonPrefixes.map(prefix => prefix.Prefix) : [];
        
        // Получаем список файлов
        const files = response.Contents ? response.Contents.map(item => ({
            Key: item.Key,
            Size: item.Size,
            LastModified: item.LastModified
        })) : [];
        
        return {
            folders,
            files
        };
    } catch (error) {
        console.error('Error listing bucket contents:', error);
        throw error;
    }
}

async function downloadFile(bucketName, key, outputPath) {
    try {
        const command = new GetObjectCommand({
            Bucket: bucketName,
            Key: key
        });

        const response = await s3Client.send(command);
        
        // Создаем директорию, если она не существует
        const dir = path.dirname(outputPath);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }

        // Создаем поток для записи файла
        const writeStream = fs.createWriteStream(outputPath);
        
        // Записываем данные из S3 в файл
        response.Body.pipe(writeStream);

        return new Promise((resolve, reject) => {
            writeStream.on('finish', resolve);
            writeStream.on('error', reject);
        });
    } catch (error) {
        console.error('Error downloading file:', error);
        throw error;
    }
}

async function uploadPdfToS3(pdfBuffer, filename) {
    try {
      // Создаем клиент S3 с использованием переменных окружения
    
      
      // Генерируем уникальное имя файла, используя messageId и оригинальное имя файла
      //const sanitizedMessageId = messageId.replace(/[<>]/g, '').replace(/[^a-zA-Z0-9]/g, '_');
      const uniqueFilename = `certificates/${filename}`;
      
      // Загружаем файл в S3
      const command = new PutObjectCommand({
        Bucket: process.env.S3_BUCKET_NAME,
        Key: uniqueFilename,
        Body: pdfBuffer,
        ContentType: 'application/pdf'
      });
      
      const response = await s3Client.send(command);
      
      // Формируем URL для доступа к файлу (для логирования)
      const fileUrl = `${process.env.S3_ENDPOINT_URL}/${process.env.S3_BUCKET_NAME}/${uniqueFilename}`;
      
      console.log(`PDF-сертификат успешно загружен в S3: ${fileUrl}`);
      return {
        success: true,
        url: filename, // Возвращаем только имя файла вместо полного URL
        key: uniqueFilename
      };
    } catch (error) {
      console.error('Ошибка при загрузке PDF в S3:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }


module.exports = {
    s3Client,
    listBucketContents,
    downloadFile
};