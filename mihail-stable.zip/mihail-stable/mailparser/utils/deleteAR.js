// Загрузка переменных окружения из .env файла
require('dotenv').config();
const { MongoClient } = require('mongodb');

// Функция для удаления записей с condition содержащим AR
async function deleteRecordsWithARCondition() {
  let client;
  let deletedCount = 0;
  
  try {
    // Подключаемся к MongoDB
    const url = process.env.MONGODB_URL;
    client = new MongoClient(url);

    await client.connect();
    console.log('Подключение к базе данных установлено');
    
    const db = client.db('vendorsDB');
    
    // Находим все записи, где condition содержит AR
    const cursor = db.collection('mail_quotes').find({ 
      condition: { $regex: /\b(AR|AR\/GR|AS REMOVED|AS IS|AI|AS|Exchange)\b/i }
    });
    
    // Подсчитываем общее количество записей для удаления
    const totalRecords = await db.collection('mail_quotes').countDocuments({ 
      condition: { $regex: /\b(AR|AR\/GR|AS REMOVED|AS IS|AI|AS|Exchange)\b/i }
    });
    
    console.log(`Найдено ${totalRecords} записей с condition содержащим AR, AR/GR, AS REMOVED, AS IS, AI или AS для удаления`);
    
    // Добавим отладочную информацию
    console.log('Примеры найденных записей:');
    const sampleRecords = await db.collection('mail_quotes').find({ 
      condition: { $regex: /\b(AR|AR\/GR|AS REMOVED|AS IS|AI|AS|Exchange)\b/i }
    }).limit(5).toArray();
    console.log(JSON.stringify(sampleRecords, null, 2));
    
    // Обрабатываем каждую запись
    for (const quote of sampleRecords) {
      console.log(`Удаление записи ${quote._id}, condition: ${quote.condition}`);
      
      // Удаляем запись
      const result = await db.collection('mail_quotes').deleteOne({ _id: quote._id });
      
      if (result.deletedCount === 1) {
        deletedCount++;
        console.log(`Запись ${quote._id} успешно удалена`);
      } else {
        console.log(`Не удалось удалить запись ${quote._id}`);
      }
      
      console.log('-----------------------------------');
    }
    
    console.log(`\nОбработка завершена!`);
  } catch (error) {
    console.error('Ошибка при обработке записей:', error);
  } finally {
    if (client) {
      await client.close();
      console.log('Соединение с базой данных закрыто');
    }
  }
}

// Запуск функции
deleteRecordsWithARCondition(); 