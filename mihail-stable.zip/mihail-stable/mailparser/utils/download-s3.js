const { downloadFile } = require('./s3');
const path = require('path');

async function main() {
    try {
        const bucketName = process.env.S3_BUCKET_NAME;
        if (!bucketName) {
            console.error('S3_BUCKET_NAME is not set in environment variables');
            return;
        }

        // URL файла
        const fileUrl = 'https://storage.yandexcloud.net/pant/certificates/PH0PR12MB80514C669EB1F032D4F3436ABAB72_PH0PR12MB8051_namprd12_prod_outlook_com/quote000810386_332810.pdf';
        
        // Извлекаем ключ из URL
        const key = fileUrl.split('storage.yandexcloud.net/')[1];
        
        // Определяем путь для сохранения файла
        const outputPath = path.join(__dirname, 'downloads', path.basename(key));

        console.log(`Downloading file from S3...`);
        await downloadFile(bucketName, key, outputPath);
        console.log(`File downloaded successfully to: ${outputPath}`);
    } catch (error) {
        console.error('Error:', error);
    }
}

main(); 