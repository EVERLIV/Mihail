let mystring = "MIN PO $250";
console.log(mystring.replace(/MIN PO\s*:?\s*\$?\d+\$?,?\s*/gi, ''))