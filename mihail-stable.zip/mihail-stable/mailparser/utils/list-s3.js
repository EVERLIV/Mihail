const { listBucketContents } = require('./s3');

async function main() {
    try {
        const bucketName = process.env.S3_BUCKET_NAME;
        if (!bucketName) {
            console.error('S3_BUCKET_NAME is not set in environment variables');
            return;
        }

        const contents = await listBucketContents(bucketName);
        console.log('S3 Bucket Contents:');
        contents.forEach(item => {
            console.log(`- ${item.Key} (${item.Size} bytes, Last modified: ${item.LastModified})`);
        });
    } catch (error) {
        console.error('Error:', error);
    }
}

main(); 