const { s3Client } = require('./s3');
const { ListObjectsV2Command } = require('@aws-sdk/client-s3');

async function main() {
    try {
        const bucketName = process.env.S3_BUCKET_NAME;
        if (!bucketName) {
            console.error('S3_BUCKET_NAME is not set in environment variables');
            return;
        }

        const folderPath = 'pant/certificates/';
        
        const command = new ListObjectsV2Command({
            Bucket: bucketName,
            Prefix: folderPath
        });

        console.log(`Listing contents of folder: ${folderPath}`);
        const response = await s3Client.send(command);
        
        if (response.Contents && response.Contents.length > 0) {
            console.log('Files in folder:');
            response.Contents.forEach(item => {
                console.log(`- ${item.Key} (${item.Size} bytes, Last modified: ${item.LastModified})`);
            });
        } else {
            console.log('No files found in the specified folder');
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

main(); 
