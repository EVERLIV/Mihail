require('dotenv').config();
require('dotenv').config({ path: '../.env' });
const Imap = require('imap');
const { simpleParser } = require('mailparser');
const { PBextractQuotationData } = require('../suppliers/partsbase.js');
const { ABextractQuotationData } = require('../suppliers/aerobay.js');
const OpenAI = require('openai');
const promptTemplate = require('../prompt.js'); // Загружаем промпт из отдельного файла
const systemPrompt = require('../system.js');

// Конфигурация IMAP из updateMessageIds.js
const imapConfig = {
  user: process.env.EMAIL_USER,
  password: process.env.EMAIL_PASSWORD,
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT || 993,
  tls: true,
  tlsOptions: { rejectUnauthorized: false }
};

// Функция для очистки текста от лишних элементов
function cleanEmailText(text) {
    return text
      // Удаляем встроенные изображения (base64)
      .replace(/data:image\/[^;]+;base64,[^\s]+/g, '')
      // Удаляем ссылки на изображения
      .replace(/https?:\/\/[^\s]+\.(jpg|jpeg|png|gif|bmp|svg)/gi, '')
      // Удаляем HTML-теги для изображений
      .replace(/<img[^>]+>/g, '')
      // Удаляем style-блоки вместе с содержимым
      .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
      // Удаляем любые URL в угловых скобках
      .replace(/<https?:\/\/[^>]+>/gi, '')
      // Удаляем всё после "Original Message"
      .replace(/Original Message[\s\S]*$/i, '')
      .replace(/This document may contain[\s\S]*$/i, '')
      .replace(/The stock is reconfirmed at the time[\s\S]*?www\.brooks-maldini\.com under the \(Terms\) section\./i, '')
      .replace(/PLEASE NOTE THE FOLLOWING TERMS OF SALE[\s\S]*?www\.brooks-maldini\.com under the \(Terms\) section\./i, '')
      // Удаляем множественные пробелы и переносы строк
      // .replace(/\s+/g, ' ')
      // Удаляем специальные символы Unicode
      .replace(/[\u0000-\u001F\u007F-\u009F]/g, '')
      .trim();
  }

  

async function processEmailsWithDeepseek(emailContent, subject) {
    const openai = new OpenAI({
        baseURL: process.env.DEEPSEEK_API_URL,
        apiKey: process.env.DEEPSEEK_API_KEY
    });

    // Очищаем текст перед отправкой в API
    const cleanedEmailContent = cleanEmailText(emailContent);

    try {
        const completion = await openai.chat.completions.create({
            model: "deepseek-chat",
            messages: [
                {
                    role: "system",
                    content: "Вы являетесь помощником по обработке коммерческих предложений (квотаций) для системы " +
                        "управления продажами. Ваша задача — извлечь и преобразовать данные из текста письма в JSON-модель, " +
                        "строго следуя указанным правилам."
                },
                {
                    role: "user",
                    content: `Извлеки информацию из следующего предложения и верни её в JSON формате не прибавляя ни одного символа снаружи объекта JSON в предоставленной структуре:\n\n
                    Используй следующую структуру (удали комментарии после полей, когда будешь подставлять значения)
                    JSON:\n${promptTemplate}\
                    строго выполняй все указания: ${systemPrompt}\n\n
                    Вот источник данных для заполнения полей в JSON темплейте - это тема и текст письма:
                    Тема письма: ${subject}\n\n
                    Текст письма:\n${cleanedEmailContent}\n\n`
                }
            ],
            temperature: 1, // Низкая температура для более предсказуемых результатов
            max_tokens: 5000
        });

        //console.log(completion.choices);
        let responseText = completion.choices[0].message.content;

        // Обработка ответа аналогично Claude
        if (responseText.substring(0, 1) != '[') {
            const bracketIndex = responseText.indexOf('[');
            responseText = responseText.substring(bracketIndex).replace('```', '');
        }
        var parsedResponse = JSON.parse(responseText);
        
        if (!Array.isArray(parsedResponse)) {
            console.log('Ответ от Deepseek не является массивом, преобразуем в массив');
            parsedResponse = [parsedResponse];
        }
        
        for (const item of parsedResponse) {
            item.email_subject = subject;
            if (item.delivery_place?.toUpperCase() === 'HONG KONG') {
                item.delivery_place = '';
            }
        }
        
        console.log(parsedResponse);
        return parsedResponse;

    } catch (error) {
        console.error('Ошибка при обработке письма через Deepseek API:', error);
        throw error;
    }
}


async function testAerobayParser() {
    let imap;
    try {
        // Подключаемся к почтовому ящику
        console.log('Подключение к почтовому ящику...');
        imap = new Imap(imapConfig);
        
        await new Promise((resolve, reject) => {
            imap.once('ready', resolve);
            imap.once('error', reject);
            imap.connect();
        });

        // Открываем папку PROCESSED
        await new Promise((resolve, reject) => {
            imap.openBox('INBOX.PROCESSED', false, (err, box) => {
                if (err) reject(err);
                else resolve(box);
            });
        });

        // Ищем письма с паттерном в теме
        const searchCriteria = [
           [ 'FROM',  'mailer.aero-bay.com'], //['Quote request #',
        ];
        const emails = await new Promise((resolve, reject) => {
            imap.search(searchCriteria, (err, results) => {
                if (err) reject(err);
                else resolve(results);
            });
        });

        console.log(`Найдено писем: ${emails.length}`);

        // Обрабатываем каждое письмо
        for (const uid of emails.slice(0, 1000)) {
            console.log(`\nОбработка письма ${uid}`);
            
            // Получаем содержимое письма
            const email = await new Promise((resolve, reject) => {
                const fetch = imap.fetch(uid, { bodies: '' });
                
                fetch.on('message', (msg) => {
                    let buffer = '';
                    
                    msg.on('body', (stream) => {
                        stream.on('data', (chunk) => {
                            buffer += chunk.toString('utf8');
                        });
                        
                        stream.on('end', () => {
                            simpleParser(buffer)
                                .then(parsed => resolve(parsed))
                                .catch(err => reject(err));
                        });
                    });
                });
                
                fetch.once('error', reject);
            });

            // Извлекаем данные из текста письма
            console.log('Тема письма:', email.subject);
            console.log('От:', email.from?.text);
            console.log('Дата:', email.date);
            
            // Парсим содержимое
            if (email.text === undefined) {
                console.log(email)

            }

            const quotationData = await ABextractQuotationData(email.text);

//            const quotationData = PBextractQuotationData(email.text);
            
            console.log('\nИзвлеченные данные:');
            console.log(JSON.stringify(quotationData, null, 2));
        }

    } catch (err) {
        console.error('Ошибка:', err);
    } finally {
        if (imap && imap.state !== 'disconnected') {
            imap.end();
            console.log('\nСоединение с почтовым ящиком закрыто');
        }
    }
}

async function testPartsBaseParser() {
    let imap;
    try {
        // Подключаемся к почтовому ящику
        console.log('Подключение к почтовому ящику...');
        imap = new Imap(imapConfig);
        
        await new Promise((resolve, reject) => {
            imap.once('ready', resolve);
            imap.once('error', reject);
            imap.connect();
        });

        // Открываем папку PROCESSED
        await new Promise((resolve, reject) => {
            imap.openBox('INBOX.PROCESSED', false, (err, box) => {
                if (err) reject(err);
                else resolve(box);
            });
        });

        // Ищем письма с паттерном в теме
        const searchCriteria = [
           [ 'SUBJECT',  'from Partsbase.com'], //['Quote request #',
        ];
        const emails = await new Promise((resolve, reject) => {
            imap.search(searchCriteria, (err, results) => {
                if (err) reject(err);
                else resolve(results);
            });
        });

        console.log(`Найдено писем: ${emails.length}`);

        // Обрабатываем каждое письмо
        for (const uid of emails.slice(0, 1000)) {
            console.log(`\nОбработка письма ${uid}`);
            
            // Получаем содержимое письма
            const email = await new Promise((resolve, reject) => {
                const fetch = imap.fetch(uid, { bodies: '' });
                
                fetch.on('message', (msg) => {
                    let buffer = '';
                    
                    msg.on('body', (stream) => {
                        stream.on('data', (chunk) => {
                            buffer += chunk.toString('utf8');
                        });
                        
                        stream.on('end', () => {
                            simpleParser(buffer)
                                .then(parsed => resolve(parsed))
                                .catch(err => reject(err));
                        });
                    });
                });
                
                fetch.once('error', reject);
            });

            // Извлекаем данные из текста письма
            console.log('Тема письма:', email.subject);
            console.log('От:', email.from?.text);
            console.log('Дата:', email.date);
            
            // Парсим содержимое
            if (email.text === undefined) {
                console.log(email)

            }

            const quotationData = await processEmailsWithDeepseek(email.text, email.subject);
//            const quotationData = PBextractQuotationData(email.text);
            
            //console.log('\nИзвлеченные данные:');
            //console.log(JSON.stringify(quotationData, null, 2));
        }

    } catch (err) {
        console.error('Ошибка:', err);
    } finally {
        if (imap && imap.state !== 'disconnected') {
            imap.end();
            console.log('\nСоединение с почтовым ящиком закрыто');
        }
    }
}

// Запускаем тест
testAerobayParser();
