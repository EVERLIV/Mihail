
const promptTemplate = `[{
  "supplier": "",            // Supplier name
  "quote_id": null,          // Leave empty
  "date": "",                // Proposal date in YYYY-MM-DD format
  "part_number": "",         // Part number
  "qty": 0,                  // Quantity (number only)
  "is_moq": false,           // Is this a minimum order quantity
  "um": "",                  // Unit of measure - allowed values: EA, M, FT, YD, KG, LB, G, L, OZ, RO, KT, CA, PR, PK, ML, IN
  "condition": "",           // Condition codes: NE, NS, OH, SV, IT, FN, RP (replace "IN" with "IT")
  "lead_time": 0,            // Delivery time (number only). If "Stock"/"STK", use 1. For ranges, use the higher value.
  "time_unit": "",           // Time unit: D (days), W (weeks), M (months). Default: D
  "price": 0.0,              // Price per unit (floating point)
  "currency": "",            // Currency (USD, EUR, etc.) - 3 character code
  "valid_to": "",            // Validity period in YYYY-MM-DD format
  "customer_request_id": null, // Leave empty
  "delivery_condition": "",  // Delivery terms: EXW, FCA, CPT, CIP, DPU, DAP, DDP, FAS, FOB, CFR, CIF
  "delivery_place": "",      // Delivery location (country)
  "item_note": "",           // Item notes
  "email_subject": "",       // Email subject
  "stk_qty": 0,              // Stock quantity (number only)
  "description": "",         // Item description
  "from": "" ,
  "moq": 1,                  // Minimum order quantity (number only)
}]`;


module.exports = promptTemplate;




