const cheerio = require('cheerio');

const ABextractQuotationData = (html) => {
    // Создаем объект для хранения результатов
    const result = [];  

    // Загружаем HTML в Cheerio
    const $ = cheerio.load(html);
    
   
    
    // Если не нашли предложения по основному селектору, попробуем альтернативный подход
        // Ищем все блоки с предложениями по альтернативному селектору
        $('div:contains("Quotation for")').each((index, element) => {
            const $element = $(element).closest('table');
            
            // Извлечение номера детали и описания
            const partNumberText = $element.find('a[href*="searchType=PART_NUMBER"], a[href*="q?searchType=PART_NUMBER"]').text().trim();
            const partNumberMatch = partNumberText.match(/^([^\s\(]+)/);
            const partNumber = partNumberMatch ? partNumberMatch[1] : '';
            
            // Извлечение описания из строки с P/N
            const pnLine = $element.find('li:contains("P/N"), li:contains("P/N:")').text();
            const descriptionMatch = pnLine.match(/P\/N\s*:\s*[^\s\(]+\s*\(([^\)]+)\)/i);
            const description = descriptionMatch ? descriptionMatch[1].trim() : '';
            
            // Извлечение состояния
            const conditionText = $element.find('li:contains("Condition"), li:contains("Condition:")').text();
            const conditionMatch = conditionText.match(/Condition\s*:\s*([^-]+)/i);
            const condition = conditionMatch ? conditionMatch[1].trim() : '';
            
            // Извлечение количества
            const qtyText = $element.find('li:contains("Quantity Available"), li:contains("Quantity Available:")').text();
            const qtyMatch = qtyText.match(/Quantity Available\s*:\s*(\d+)/i);
            const qty = qtyMatch ? parseInt(qtyMatch[1]) : 0;
            
            // Извлечение цены
            const priceText = $element.find('li:contains("Unit Price"), li:contains("Unit Price:")').text();
            
            // Проверяем, есть ли ссылка "Make an Offer"
            const makeOfferLink = $element.find('li:contains("Unit Price") a[href^="mailto:"]').length > 0;
            
            let price = 0;
            
            if (!makeOfferLink) {
                // Извлекаем цену из HTML-структуры
                const priceElement = $element.find('li:contains("Unit Price") strong');
                if (priceElement.length > 0) {
                    // Получаем целую часть цены
                    const wholePart = priceElement.find('span:contains("$")').next('span').text().replace(/\s/g, '');
                    // Получаем десятичную часть из тега sup
                    const decimalPart = priceElement.find('sup').text().replace(/\s/g, '');
                    
                    // Собираем цену
                    const priceStr = wholePart + (decimalPart ? '.' + decimalPart : '');
                    price = parseFloat(priceStr);
                    console.log(price);
                } else {
                    // Запасной вариант - извлечение из текста
                    const priceMatch = priceText.match(/\$\s*([\d\s,]+)(?:\s*00)?/);
                    if (priceMatch) {
                        // Удаляем пробелы и запятые, затем преобразуем в число
                        const priceStr = priceMatch[1].replace(/[\s,]/g, '');
                        price = parseFloat(priceStr);
                    }
                }
            }
            
            // Извлечение времени поставки
            const leadTimeText = $element.find('li:contains("Estimated lead time"), li:contains("Estimated lead time:")').text();
            const leadTimeMatch = leadTimeText.match(/Estimated lead time\s*:\s*(\d+)/i);
            const leadTime = leadTimeMatch ? parseInt(leadTimeMatch[1]) : 1;
            
            // Извлечение условий поставки
            const deliveryText = $element.find('li:contains("Shipping Policy"), li:contains("Shipping Policy:")').text();
            const deliveryMatch = deliveryText.match(/Shipping Policy\s*:\s*([^(]+)\s*\(([^)]+)\)/i);
            const deliveryCondition = deliveryMatch ? deliveryMatch[1].trim() : 'EXW';
            const deliveryPlace = deliveryMatch ? deliveryMatch[2].trim().replace(/\s*\([^)]*\)/g, '').trim() : '';
            
            // Извлечение гарантии
            const warrantyText = $element.find('li:contains("Warranty"), li:contains("Warranty:")').text();
            const warrantyMatch = warrantyText.match(/Warranty\s*:\s*([^\n]+)/i);
            const warranty = warrantyMatch ? warrantyMatch[1].trim() : '';
            
            // Извлечение дополнительной информации
            const itemNoteText = $element.find('li:contains("Additional information"), li:contains("Additional information:")').text();
            const itemNoteMatch = itemNoteText.match(/Additional information\s*:\s*([^\n]+)/i);
            let itemNote = itemNoteMatch ? itemNoteMatch[1].trim() : '';
            itemNote = itemNote
                    .replace(/Delivered with /g, ' ')
                    .replace(/Additional information: /, ' ')
                    .replace(/Will be delivered with /, '')
                    .replace(/Attached with : /, '')
                    .replace(/MOV\s*=\s*\$?\d+(?:\s*\/\s*)?/g, '')
                    .replace(/\s+/g, ' ')
                    .trim();
            
            // Создаем объект опции
            const option = {
                part_number: partNumber,
                description: description,
                condition: condition,
                qty: qty,
                price: price,
                lead_time: leadTime,
                time_unit: 'D',
                delivery_place: deliveryPlace.split('(')[0].trim(),
                delivery_condition: deliveryCondition.includes('EXW') ? 'EXW' : deliveryCondition,
                item_note: itemNote,
                supplier: 'AEROBAY',
                currency: 'USD',
                un: "EA"
            };
            
            // Добавляем опцию в массив результатов только если есть номер детали
            if (partNumber && partNumber.trim() !== '') {
                if (condition != 'AR') {
                    result.push(option);
                }
            }
        });
    
    
    
    // Удаляем дубликаты из массива options
    const uniqueOptions = [];
    const seen = new Set();
    
    for (const option of result) {
        const key = `${option.part_number}-${option.condition}-${option.delivery_place}`;
        if (!seen.has(key)) {
            seen.add(key);
            uniqueOptions.push(option);
        }
    }
    
    return uniqueOptions.filter(option => option.price > 0);
};

module.exports = {
    ABextractQuotationData
};


    // // Находим все блоки с предложениями - исправленный селектор
    // $('table.w320, table[cellspacing="0"][cellpadding="0"][width="100%"]').each((index, element) => {
    //     const $element = $(element);
        
    //     // Извлечение номера детали и описания - исправленный селектор
    //     const partNumberText = $element.find('a[href*="searchType=PART_NUMBER"], a[href*="q?searchType=PART_NUMBER"]').text().trim();
    //     const partNumberMatch = partNumberText.match(/^([^\s\(]+)/);
    //     const partNumber = partNumberMatch ? partNumberMatch[1] : '';
        
    //     // Извлечение описания из строки с P/N - исправленный селектор
    //     const pnLine = $element.find('li:contains("P/N"), li:contains("P/N:")').text();
    //     const descriptionMatch = pnLine.match(/P\/N\s*:\s*[^\s\(]+\s*\(([^\)]+)\)/i);
    //     const description = descriptionMatch ? descriptionMatch[1].trim() : '';
        
    //     // Извлечение состояния - исправленный селектор
    //     const conditionText = $element.find('li:contains("Condition"), li:contains("Condition:")').text();
    //     const conditionMatch = conditionText.match(/Condition\s*:\s*([^-]+)/i);
    //     const condition = conditionMatch ? conditionMatch[1].trim() : '';
        
    //     // Извлечение количества - исправленный селектор
    //     const qtyText = $element.find('li:contains("Quantity Available"), li:contains("Quantity Available:")').text();
    //     const qtyMatch = qtyText.match(/Quantity Available\s*:\s*(\d+)/i);
    //     const qty = qtyMatch ? parseInt(qtyMatch[1]) : 0;
        
    //     // Извлечение цены - исправленный селектор
    //     const priceText = $element.find('li:contains("Unit Price"), li:contains("Unit Price:")').text();
        
    //     // Проверяем, есть ли ссылка "Make an Offer"
    //     const makeOfferLink = $element.find('li:contains("Unit Price") a[href^="mailto:"]').length > 0;
        
    //     let price = 0;
        
    //     if (!makeOfferLink) {
    //         // Извлекаем цену из HTML-структуры
    //         const priceElement = $element.find('li:contains("Unit Price") strong');
    //         if (priceElement.length > 0) {
    //             // Получаем целую часть цены
    //             const wholePart = priceElement.find('span:contains("$")').next('span').text().replace(/\s/g, '');
    //             console.log(wholePart);

    //             // Получаем десятичную часть из тега sup
    //             const decimalPart = priceElement.find('sup').text().replace(/\s/g, '');
                
    //             // Собираем цену
    //             const priceStr = wholePart + (decimalPart ? '.' + decimalPart : '');
    //             price = parseFloat(priceStr);
    //             console.log(price);
    //         } else {
    //             // Запасной вариант - извлечение из текста
    //             const priceMatch = priceText.match(/\$\s*([\d\s,]+)(?:\s*00)?/);
    //             if (priceMatch) {
    //                 // Удаляем пробелы и запятые, затем преобразуем в число
    //                 const priceStr = priceMatch[1].replace(/[\s,]/g, '');
    //                 price = parseFloat(priceStr);
    //             }
    //         }
    //     }
        
    //     // Извлечение времени поставки - исправленный селектор
    //     const leadTimeText = $element.find('li:contains("Estimated lead time"), li:contains("Estimated lead time:")').text();
    //     const leadTimeMatch = leadTimeText.match(/Estimated lead time\s*:\s*(\d+)/i);
    //     const leadTime = leadTimeMatch ? parseInt(leadTimeMatch[1]) : 1;
        
    //     // Извлечение условий поставки - исправленный селектор
    //     const deliveryText = $element.find('li:contains("Shipping Policy"), li:contains("Shipping Policy:")').text();
    //     const deliveryMatch = deliveryText.match(/Shipping Policy\s*:\s*([^(]+)\s*\(([^)]+)\)/i);
    //     const deliveryCondition = deliveryMatch ? deliveryMatch[1].trim() : 'EXW';
    //     const deliveryPlace = deliveryMatch ? deliveryMatch[2].trim().replace(/\s*\([^)]*\)/g, '').trim() : '';
        
    //     // Извлечение гарантии - исправленный селектор
    //     const warrantyText = $element.find('li:contains("Warranty"), li:contains("Warranty:")').text();
    //     const warrantyMatch = warrantyText.match(/Warranty\s*:\s*([^\n]+)/i);
    //     const warranty = warrantyMatch ? warrantyMatch[1].trim() : '';
        
    //     // Извлечение дополнительной информации - исправленный селектор
    //     const itemNoteText = $element.find('li:contains("Additional information"), li:contains("Additional information:")').text();
    //     const itemNoteMatch = itemNoteText.match(/Additional information\s*:\s*([^\n]+)/i);
    //     let itemNote = itemNoteMatch ? itemNoteMatch[1].trim() : '';
    //     itemNote = itemNote
    //             .replace(/Delivered with /g, ' ')
    //             .replace(/Additional information: /, ' ')
    //             .replace(/Will be delivered with /, '')
    //             .replace(/Attached with : /, '')
    //             .replace(/MOV\s*=\s*\$?\d+(?:\s*\/\s*)?/g, '')
    //             .replace(/\s+/g, ' ')
    //             .trim();
        
    //     // Создаем объект опции
    //     const option = {
    //         part_number: partNumber,
    //         description: description,
    //         condition: condition,
    //         stk_qty: qty,
    //         price: price,
    //         lead_time: leadTime,
    //         time_unit: 'D',
    //         delivery_place: deliveryPlace.split('(')[0].trim(),
    //         delivery_condition: deliveryCondition.includes('EXW') ? 'EXW' : deliveryCondition,
    //         item_note: itemNote,
    //         supplier: 'AEROBAY',
    //         currency: 'USD',
    //         un: "EA"
    //     };
    // });
    

    // Если все еще не нашли предложения, попробуем еще один подход
    // if (result.length === 0) {
    //     // Ищем все блоки с предложениями по еще одному альтернативному селектору
    //     $('div:contains("Quotation for")').each((index, element) => {
    //         const $element = $(element).parent();
            
    //         // Извлечение номера детали и описания
    //         const partNumberText = $element.find('a[href*="searchType=PART_NUMBER"], a[href*="q?searchType=PART_NUMBER"]').text().trim();
    //         const partNumberMatch = partNumberText.match(/^([^\s\(]+)/);
    //         const partNumber = partNumberMatch ? partNumberMatch[1] : '';
            
    //         // Извлечение описания из строки с P/N
    //         const pnLine = $element.find('li:contains("P/N"), li:contains("P/N:")').text();
    //         const descriptionMatch = pnLine.match(/P\/N\s*:\s*[^\s\(]+\s*\(([^\)]+)\)/i);
    //         const description = descriptionMatch ? descriptionMatch[1].trim() : '';
            
    //         // Извлечение состояния
    //         const conditionText = $element.find('li:contains("Condition"), li:contains("Condition:")').text();
    //         const conditionMatch = conditionText.match(/Condition\s*:\s*([^-]+)/i);
    //         const condition = conditionMatch ? conditionMatch[1].trim() : '';
            
    //         // Извлечение количества
    //         const qtyText = $element.find('li:contains("Quantity Available"), li:contains("Quantity Available:")').text();
    //         const qtyMatch = qtyText.match(/Quantity Available\s*:\s*(\d+)/i);
    //         const qty = qtyMatch ? parseInt(qtyMatch[1]) : 0;
            
    //         // Извлечение цены
    //         const priceText = $element.find('li:contains("Unit Price"), li:contains("Unit Price:")').text();
            
    //         // Проверяем, есть ли ссылка "Make an Offer"
    //         const makeOfferLink = $element.find('li:contains("Unit Price") a[href^="mailto:"]').length > 0;
            
    //         let price = 0;
            
    //         if (!makeOfferLink) {
    //             // Извлекаем цену из HTML-структуры
    //             const priceElement = $element.find('li:contains("Unit Price") strong');
    //             if (priceElement.length > 0) {
    //                 // Получаем целую часть цены
    //                 const wholePart = priceElement.find('span:contains("$")').next('span').text().replace(/\s/g, '');
    //                 console.log(wholePart);
    //                 // Получаем десятичную часть из тега sup
    //                 const decimalPart = priceElement.find('sup').text().replace(/\s/g, '');
                    
    //                 // Собираем цену
    //                 const priceStr = wholePart + (decimalPart ? '.' + decimalPart : '');
    //                 price = parseFloat(priceStr);
    //                 console.log('1',price);
    //             } else {
    //                 // Запасной вариант - извлечение из текста
    //                 const priceMatch = priceText.match(/\$\s*([\d\s,]+)(?:\s*00)?/);
    //                 if (priceMatch) {
    //                     // Удаляем пробелы и запятые, затем преобразуем в число
    //                     const priceStr = priceMatch[1].replace(/[\s,]/g, '');
    //                     price = parseFloat(priceStr);
    //                 }
    //             }
    //         }
            
    //         // Извлечение времени поставки
    //         const leadTimeText = $element.find('li:contains("Estimated lead time"), li:contains("Estimated lead time:")').text();
    //         const leadTimeMatch = leadTimeText.match(/Estimated lead time\s*:\s*(\d+)/i);
    //         const leadTime = leadTimeMatch ? parseInt(leadTimeMatch[1]) : 1;
            
    //         // Извлечение условий поставки
    //         const deliveryText = $element.find('li:contains("Shipping Policy"), li:contains("Shipping Policy:")').text();
    //         const deliveryMatch = deliveryText.match(/Shipping Policy\s*:\s*([^(]+)\s*\(([^)]+)\)/i);
    //         const deliveryCondition = deliveryMatch ? deliveryMatch[1].trim() : 'EXW';
    //         const deliveryPlace = deliveryMatch ? deliveryMatch[2].trim().replace(/\s*\([^)]*\)/g, '').trim() : '';
            
    //         // Извлечение гарантии
    //         const warrantyText = $element.find('li:contains("Warranty"), li:contains("Warranty:")').text();
    //         const warrantyMatch = warrantyText.match(/Warranty\s*:\s*([^\n]+)/i);
    //         const warranty = warrantyMatch ? warrantyMatch[1].trim() : '';
            
    //         // Извлечение дополнительной информации
    //         const itemNoteText = $element.find('li:contains("Additional information"), li:contains("Additional information:")').text();
    //         const itemNoteMatch = itemNoteText.match(/Additional information\s*:\s*([^\n]+)/i);
    //         let itemNote = itemNoteMatch ? itemNoteMatch[1].trim() : '';
    //         itemNote = itemNote
    //                 .replace(/Delivered with /g, ' ')
    //                 .replace(/Additional information: /, ' ')
    //                 .replace(/Will be delivered with /, '')
    //                 .replace(/Attached with : /, '')
    //                 .replace(/MOV\s*=\s*\$?\d+(?:\s*\/\s*)?/g, '')
    //                 .replace(/\s+/g, ' ')
    //                 .trim();
            
    //         // Создаем объект опции
    //         const option = {
    //             part_number: partNumber,
    //             description: description,
    //             condition: condition,
    //             stk_qty: qty,
    //             price: price,
    //             lead_time: leadTime,
    //             time_unit: 'D',
    //             delivery_place: deliveryPlace.split('(')[0].trim(),
    //             delivery_condition: deliveryCondition.includes('EXW') ? 'EXW' : deliveryCondition,
    //             item_note: itemNote,
    //             supplier: 'AEROBAY',
    //             currency: 'USD',
    //             un: "EA"
    //         };
            
    //         // Добавляем опцию в массив результатов только если есть номер детали
    //         if (partNumber && partNumber.trim() !== '') {
    //             result.push(option);
    //         }
    //     });
    // }