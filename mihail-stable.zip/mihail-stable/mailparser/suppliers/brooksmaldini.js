const BMextractQuotationData = (text) => {
    const result = {
        companyName: '',
        referenceNumber: '',
        recipient: '',
        options: [],
        additionalTerms: {},
        contactInfo: {}
    };

    // Регулярные выражения для извлечения данных
    const companyNameRegex = /^([A-Z\s&]+)\sTEXT QUOTATION/i;
    const referenceRegex = /REF#\s+(\w+)/i;
    const recipientRegex = /Dear\s+([\w\s]+)/i;
    const optionBlockRegex = /Option\s+\d+(.*?)(?=Option\s+\d+|$)/gs;
    const optionDetailsRegex = {
        part_number: /Partnumber:\s*([^,\s\n]+)/i,
        description: /Description:\s*(.+)/i,
        condition: /Condition:\s*(.+)/i,
        qty: /QTY Req\.:\s*(\d+)/i,
        stk_qty: /QTY avail\.:\s*(\d+)/i,
        price: /Price Each:\s*\$([\d,.]+)/i,
        totalPrice: /Total Price:\s*\$([\d,.]+)/i,
        moq: /MOQ:\s*([^]*?)(?=Lead|$)/i,
        lead_time: /Lead Time.*?:\s*([^]*?)(?=Comments:|$)/i,
        item_note: /Comments:\s*(.+)/i
    };
    const additionalTermsRegex = {
        processingFee: /\$([\d,.]+)\s+fee is added to any order under \$([\d,.]+)/i,
        salesTerms: /All PURCHASES ARE NC\/NR unless otherwise agreed upon/i,
        hazmatFee: /HAZMAT fee of \$([\d,.]+)/i,
        warranty: /(\d+)\s+day warranty/i,
        estimatedLeadTime: /Estimated lead time is the time it takes for the part to arrive at our distribution center in FLL/i
    };
    const contactInfoRegex = {
        phone: /Phone:\s*([\d-]+)/i,
        fax: /Fax:\s*([\d-]+)/i,
        email: /E-mail:\s*([\w.-]+@[\w.-]+)/i,
        website: /https?:\/\/([\w.-]+)/i
    };

    // Извлечение основной информации
    const companyNameMatch = text.match(companyNameRegex);
    if (companyNameMatch) result.companyName = companyNameMatch[1].trim();

    const referenceMatch = text.match(referenceRegex);
    if (referenceMatch) result.referenceNumber = referenceMatch[1].trim();

    const recipientMatch = text.match(recipientRegex);
    if (recipientMatch) result.recipient = recipientMatch[1].trim();

    // Проверяем, есть ли "Option" в тексте
    if (text.includes('Option')) {
        // Существующая логика для множества опций
        let optionBlockMatch;
        while ((optionBlockMatch = optionBlockRegex.exec(text)) !== null) {
            const optionText = optionBlockMatch[0];
            const option = extractOption(optionText, optionDetailsRegex);
            result.options.push(option);
        }
    } else {
        // Логика для одного предложения
        const option = extractOption(text, optionDetailsRegex);
        result.options.push(option);
    }

    // Извлечение дополнительных условий
    const processingFeeMatch = text.match(additionalTermsRegex.processingFee);
    if (processingFeeMatch) {
        result.additionalTerms.processingFee = {
            fee: parseFloat(processingFeeMatch[1]),
            threshold: parseFloat(processingFeeMatch[2])
        };
    }

    if (text.match(additionalTermsRegex.salesTerms)) {
        result.additionalTerms.salesTerms = true;
    }

    const hazmatFeeMatch = text.match(additionalTermsRegex.hazmatFee);
    if (hazmatFeeMatch) result.additionalTerms.hazmatFee = parseFloat(hazmatFeeMatch[1]);

    const warrantyMatch = text.match(additionalTermsRegex.warranty);
    if (warrantyMatch) result.additionalTerms.warrantyDays = parseInt(warrantyMatch[1]);

    if (text.match(additionalTermsRegex.estimatedLeadTime)) {
        result.additionalTerms.estimatedLeadTime = true;
    }

    // Извлечение контактной информации
    const phoneMatch = text.match(contactInfoRegex.phone);
    if (phoneMatch) result.contactInfo.phone = phoneMatch[1];

    const faxMatch = text.match(contactInfoRegex.fax);
    if (faxMatch) result.contactInfo.fax = faxMatch[1];

    const emailMatch = text.match(contactInfoRegex.email);
    if (emailMatch) result.contactInfo.email = emailMatch[1];

    const websiteMatch = text.match(contactInfoRegex.website);
    if (websiteMatch) result.contactInfo.website = `https://${websiteMatch[1]}`;

    return result.options;
};

// Выносим логику извлечения опции в отдельную функцию
function extractOption(text, optionDetailsRegex) {
    const option = {};
    let moqValue = 0;
    let stkQtyValue = 0;
    
    for (const [key, regex] of Object.entries(optionDetailsRegex)) {
        const match = text.match(regex);
        if (match) {
            if (key === 'lead_time') {
                const leadTimeText = match[1].trim().toLowerCase();
                
                if (leadTimeText.includes('same day') || leadTimeText.includes('stock')) {
                    option.lead_time = 1;
                    option.time_unit = 'D';
                    continue;
                }
                
                const numbers = leadTimeText.match(/\d+/g);
                const timeUnit = leadTimeText.match(/business\s*(days?|weeks?)|days?|weeks?/i);
                
                if (numbers) {
                    option.lead_time = Math.max(...numbers.map(Number));
                    option.time_unit = timeUnit && timeUnit[1] ? 
                        (timeUnit[1].toLowerCase().includes('week') ? 'W' : 'D') : 
                        'D';
                } else {
                    option.lead_time = 1;
                    option.time_unit = 'D';
                }
            } else if (key === 'moq') {
                moqValue = parseInt(match[1]);
                option.is_moq = moqValue > 0;
            } else if (key === 'stk_qty') {
                stkQtyValue = parseInt(match[1]);
                option.stk_qty = stkQtyValue;
            } else if (key === 'item_note') {
                option.item_note = match[1].trim();
                // Comments: Mfg Certs LEAD TIME 2WKS
                if (moqValue > 0) {
                    option.moq = moqValue;
                    option.item_note = `${option.item_note} | MOQ ${moqValue}`;
                }

                // Проверяем наличие LEAD TIME в комментарии
                const leadTimeMatch = option.item_note.match(/LEAD\s+TIME\s+(\d+)(?:\s*)(?:([A-Z]+)|$)/i);
                if (leadTimeMatch) {
                    const [, timeValue, timeUnit] = leadTimeMatch;
                    option.lead_time = parseInt(timeValue);
                    
                    if (timeUnit) {
                        // Если есть буквенное обозначение, берем первую букву
                        option.time_unit = timeUnit.charAt(0).toUpperCase();
                    } else {
                        // Если буквенного обозначения нет, проверяем контекст
                        const contextMatch = option.item_note.match(/LEAD\s+TIME\s+\d+\s*(?:days?|weeks?)/i);
                        if (contextMatch) {
                            // Если в тексте есть слово days или weeks
                            const unitMatch = contextMatch[0].match(/(?:days?|weeks?)/i);
                            if (unitMatch) {
                                option.time_unit = unitMatch[0].charAt(0).toUpperCase();
                            }
                        } else {
                            // Если нет никаких указаний единицы измерения, используем дни по умолчанию
                            option.time_unit = 'D';
                        }
                    }
                    console.log('Извлечено время поставки из комментария:', option.lead_time, option.time_unit);
                }
             
            } else {
                option[key] = key === 'price' || key === 'totalPrice' ? 
                    parseFloat(match[1].replace(/,/g, '')) :
                    key === 'qty' ?
                    parseInt(match[1]) :
                    match[1].trim();
            }
        }
    }

    option.supplier = 'BROOKS-MALDINI';
    option.delivery_place = 'US';
    option.delivery_condition = 'EXW';
    option.currency = 'USD';
    option.un = "EA"

    return option;
}

module.exports = {
  BMextractQuotationData
}
// // Пример использования
// const quotationText = `
// BROOKS & MALDINI CORPORATION TEXT QUOTATION

// Dear julian stevens

// REF# BMA 4179983

// Option 1
// part_number: S9026T154
// Description: PACKING
// Condition: NE      
// QTY Req.: 1
// QTY avail.: 1
// Price Each: $577.08      
// Total Price: $577.08      
// MOQ: 0
// Lead Time (unless different in Comments): 3-6 weeks      
// Comments: MFG C of C or EASA/FAA 8130-3

// Option 2
// part_number: S9026T154
// Description: PACKING
// Condition: NE      
// QTY Req.: 1
// QTY avail.: 800
// Price Each: $296.40      
// Total Price: $296.40      
// MOQ: 0
// Lead Time (unless different in Comments): 2-5 business days      
// Comments: Fresh Boeing FAA 8130-3

// Option 3
// part_number: S9026T154
// Description: PACKING    
// Condition: NE      
// QTY Req.: 1
// QTY avail.: 1600
// Price Each: $293.09      
// Total Price: $293.09      
// MOQ: 10
// Lead Time (unless different in Comments): 2-5 business days      
// Comments: Mfg Certs

// ...

// USA Headquarters:
// Phone: +1-954-761-7700
// Fax: +1-954-761-7799
// HUBzone
// ASA Member
// NBAA Member
// E-mail: Erika@brooks-maldini.net
// https://www.brooks-maldini.net
// `;

// const quotationText2 = `BROOKS & MALDINI CORPORATION TEXT QUOTATION

// Dear julian stevens

// REF# BMA 4181220

// part_number: 213A6404-1
// Description: FILTER
// Condition: NE      
// QTY Req.: 20
// QTY avail.: 5299
// Price Each: $50.65      
// Total Price: $1,013.04      
// MOQ: 0
// Lead Time (unless different in Comments): 2-5 business days      
// Comments: Fresh Boeing FAA 8130-3

// A processing $25 fee is added to any order under $200.
// The stock is reconfirmed at the time of this quote, we cannot hold any parts without a Purchase order and parts can be sold at moment's notice.
// All PURCHASES ARE NC/NR unless otherwise agreed upon.
// A HAZMAT fee of $ 500.00, and additional special crate cost might apply for HAZMAT items if needed for transportation.
// Warranty period!!!! All parts come with an industry standard 30 day warranty. A longer warranty period may be available, please consult your sales rep if this is needed.
// Estimated lead time is the time it takes for the part to arrive at our distribution center in FLL, Delays due to US customs procedures or other shipping related delays are not a accepted cause for order cancelation.
// By placing a purchase order you confirm that you accept and agree to Brooks &amp; Maldini sales terms, terms are posted on our website: www.brooks-maldini.com under the (Terms) section.

// USA Headquarters:
// Phone: +1-954-761-7700
// Fax: +1-954-761-7799
// HUBzone
// ASA Member
// NBAA Member
// E-mail: Erika@brooks-maldini.net
// https://www.brooks-maldini.net`


//const extractedData = BMextractQuotationData(quotationText);
//console.log(JSON.stringify(extractedData, null, 2));