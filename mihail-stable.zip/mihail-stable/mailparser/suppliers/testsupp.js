   
const { BMextractQuotationData } = require('./brooksmaldini');

const quotationText = `
BROOKS & MALDINI CORPORATION TEXT QUOTATION

Dear South Sea Solutions

REF# BMA 4226623

Option 1
Partnumber: 4557
Description: LAMP, SEALED BEAM
Condition: NE
QTY Req.: 2
QTY avail.: 274
Price Each: $41.28
Total Price: $4,127.50
MOQ: 100
Lead Time (unless different in Comments): 2-5 business days
Comments: Mfg Certs LEAD TIME 2WKS

Option 2
Partnumber: 4557
Description: LAMP: INCANDESCENT,SEALED BEAM,28V,1000W
Condition: NE
QTY Req.: 2
QTY avail.: 601
Price Each: $110.93
Total Price: $221.86
MOQ: 0
Lead Time (unless different in Comments): 1-4 business days
Comments: Manufacturer Certs



A processing $25 fee is added to any order under $200.
The stock is reconfirmed at the time of this quote, we cannot hold any parts without a Purchase order and parts can be sold at moment's notice.
All PURCHASES ARE NC/NR unless otherwise agreed upon.
A HAZMAT fee of $ 500.00, and additional special crate cost might apply for HAZMAT items if needed for transportation.
Warranty period!!!! All parts come with an industry standard 30 day warranty. A longer warranty period may be available, please consult your sales rep if this is needed.
Estimated lead time is the time it takes for the part to arrive at our distribution center in FLL, Delays due to US customs procedures or other shipping related delays are not a accepted cause for order cancelation.
By placing a purchase order you confirm that you accept and agree to Brooks & Maldini sales terms, terms are posted on our website: www.brooks-maldini.com under the (Terms) section.

USA Headquarters:
Phone: +1-954-761-7700
Fax: +1-954-761-7799
HUBzone
ASA Member
NBAA Member
E-mail: Erika@brooks-maldini.net
https://www.brooks-maldini.net
Закрыть
`;

console.log(BMextractQuotationData(quotationText));