const PBextractQuotationData = (text) => {
    const options = [];

    // Сначала найдем все секции, начинающиеся с Part No: и заканчивающиеся Comments:
    const sectionRegex = /Part No:[\s\S]*?Comments:[\s\S]*?(?=Part No:|$)/g;
    if (text === undefined) {
        console.log('text is undefined')
    }
    const sections = text.match(sectionRegex);
    if (!sections) return options;

    // Извлекаем данные о поставщике
    const supplierMatch = text.match(/Company:\s*(.+?)(?=ADDRESS|$)/i);
    const supplierName = supplierMatch ? supplierMatch[1].trim() : '';
    // Извлекаем данные о стране
    const countryMatch = text.match(/Country:\s*(.+?)(?=\n|$)/i);
    const country = countryMatch ? countryMatch[1].trim() : '';
    // Извлекаем email поставщика
    const emailMatch = text.match(/Email:\s*(.+?)(?=country|$)/i);
    const email = emailMatch ? emailMatch[1].trim() : '';
    // Извлекаем текст из NOTE TO BUYER
    const noteToBuyerMatch = text.match(/NOTE TO BUYER:([\s\S]*?)Disclaimer:/i);
    const noteToBuyerText = noteToBuyerMatch ? noteToBuyerMatch[1].trim() : '';
    // Для каждой секции извлекаем данные
    sections.forEach(section => {
        const option = {};

    // Регулярные выражения для извлечения данных
        const partNumberMatch = section.match(/Part No:\s*([\w-]+)/i);
        const descriptionMatch = section.match(/Description:\s*(.+?)(?=\s+Condition:|$)/i);
        const conditionMatch = section.match(/Condition:\s*(.+?)(?=\n)/i);
        const qtyMatch = section.match(/Quantity \| UoM:\s*(\d+)/i);
        const priceMatch = section.match(/Unit\s+Price:\s*([\d,.]+)/i);
        // const priceType = section.match(/Price\s+Type:\s*["']?([^"\'\s]+)/i);
        const priceType = section.match(/Price\s+Type:\s*([^\n]+?)(?=\s*Lead)/i);
        const leadTimeMatch = section.match(/Lead Time in Days:\s*(\d+)/i);
        const currencyMatch = section.match(/Currency:\s*(\w+)/i);
        const traceabilityMatch = section.match(/Traceability:\s*(.+?)(?=\n)/i);
        const commentsMatch = section.match(/Comments:\s*(.+?)(?=(?:\n\s*\n|\n\s*Part No:|$))/i);

        // Заполняем данные
        if (partNumberMatch) option.part_number = partNumberMatch[1].trim();
        if (descriptionMatch) option.description = descriptionMatch[1].trim();
        if (conditionMatch) option.condition = conditionMatch[1].trim().substring(0, 2);
        if (qtyMatch) option.qty = parseInt(qtyMatch[1]);
        if (priceMatch) option.price = parseFloat(priceMatch[1].replace(/,/g, ''));
        if (priceType) option.price_type = priceType[1].trim();
        if (leadTimeMatch) option.lead_time = parseInt(leadTimeMatch[1]);
        if (currencyMatch) {
            const curr = currencyMatch[1].trim().toLowerCase();
            option.currency = (curr === 'dollars' || curr === 'usd') ? 'USD' : currencyMatch[1].toUpperCase();
        }
        if (traceabilityMatch) option.traceability = traceabilityMatch[1].trim();
        if (commentsMatch) option.item_note = commentsMatch[1].trim();

        // Добавляем стандартные поля
        option.supplier = supplierName?.toUpperCase().trim();
        option.delivery_place = country.toUpperCase().includes('UNITED STATES') ? 'US' : country.substring(0, 10).trim();
        option.delivery_condition = 'EXW';
        option.time_unit = 'D';
        option.um = 'EA';
        option.is_moq = false;
        option.from = email?.toLowerCase();

        // Если нет валюты, устанавливаем USD по умолчанию
        if (!option.currency) option.currency = 'USD';

        // Извлекаем Comments
        const commentsText = commentsMatch ? commentsMatch[1].trim() : '';
        // Объединяем NOTE TO BUYER и Comments
        const notes = [noteToBuyerText, commentsText]
            .filter(note => note) // Убираем пустые строки
            .join('\n\n')
            .replace('Thank you for your RFQ', '')
            .replace('There is a minimum order $50 for US & $150 outside of the US.', '')
            .replace('Part sales Joey\nAllenger Sales@Piusparts.com 361-494-2333', '')
            .replace('All quotes good for 30 days unless otherwise indicated.', '')
            .replace(`Part availability is\nsubject to prior sale. Minimum order requirement is $250 DOM & $1,000 INT'L.\nCredit Cards accepted at no additional fee. For PO’s email:\nraul.castellano@vseaviation.com`, '')
            .replace('*** IN STOCK - SEND PO ***', '')
            .replace('IN STOCK - SEND PO\n', '')
            .replace('HANDLING FEES: USD 25 FOR ORDERS UNDER\n', '')
            
            
        option.item_note = option.traceability ? 'Trace: ' + option.traceability.replace('Comments:', '').trim() + ', ' + notes
                             : notes;
        option.item_note = option.item_note?.replace('NOTE TO BUYER:', '').trim();
        delete option.traceability;

        // Добавляем опцию только если есть основные поля
        console.log(option);
        if (option.part_number && option.price) {
            options.push(option);
        }
    });

    const validOptions = options
        //.map(validateAndRepairOption)
        .filter(option => option !== null);

    return validOptions;
};

// Функция для нормализации состояния
const normalizeCondition = (condition) => {
    if (!condition) return undefined;
    
    const conditionMap = {
        'NEW': 'NE',
        'OVERHAULED': 'OH',
        'SERVICEABLE': 'SV',
        'INSPECTED': 'IT',
        'INSPECTED TESTED': 'IT',
        'IN': 'IT',
        'FACTORY NEW': 'FN',
        'REPAIRED': 'RP',
        'NEW SURPLUS': 'NS',
    };

    // Приводим к верхнему регистру и убираем лишние пробелы
    const normalizedInput = condition.trim().toUpperCase();
    
    // Проверяем прямое соответствие допустимым значениям
    if (['NE', 'OH', 'SV', 'IT', 'FN', 'RP', 'NS'].includes(normalizedInput)) {
        return normalizedInput;
    }

    // Ищем соответствие в карте преобразований
    return conditionMap[normalizedInput];
}

// Функция для нормализации единиц измерения
const normalizeUM = (um) => {
    if (!um) return 'EA'; // По умолчанию Each

    const umMap = {
        'EACH': 'EA',
        'METER': 'M',
        'METRE': 'M',
        'FOOT': 'FT',
        'YARD': 'YD',
        'KILOGRAM': 'KG',
        'POUND': 'LB',
        'GRAM': 'G',
        'LITRE': 'L',
        'OUNCE': 'OZ',
        'ROLL': 'RO',
        'KIT': 'KT',
        'CAN': 'CA',
        'PAIR': 'PR',
        'PACK': 'PK',
        'MILLILITRE': 'ML',
        'INCH': 'IN'
    };

    // Приводим к верхнему регистру и убираем лишние пробелы
    const normalizedInput = um.trim().toUpperCase();

    // Проверяем прямое соответствие допустимым значениям
    const validUMs = ['EA', 'M', 'FT', 'YD', 'KG', 'LB', 'G', 'L', 'OZ', 'RO', 'KT', 'CA', 'PR', 'PK', 'ML', 'IN'];
    if (validUMs.includes(normalizedInput)) {
        return normalizedInput;
    }

    // Ищем соответствие в карте преобразований
    return umMap[normalizedInput] || 'EA';
};

// Функция валидации и исправления объекта
const validateAndRepairOption = (option) => {
    // Нормализуем состояние
    const validCondition = normalizeCondition(option.condition);
    if (!validCondition) {
        console.log('condition не подходит по условию', option.condition);
        //return null; // Если состояние не соответствует допустимым значениям, отбрасываем опцию
    }
    option.condition = validCondition;

    // Нормализуем единицы измерения
    option.um = normalizeUM(option.um);

    return option;
};

module.exports = {
    PBextractQuotationData
};


