// Загрузка переменных окружения из .env файла
require('dotenv').config();
require('dotenv').config({ path: '../.env' }); // загружает .env из родительской директории
const Imap = require('imap');
const { simpleParser } = require('mailparser');
const fs = require('fs');
const cheerio = require('cheerio');
const path = require('path');
const Anthropic = require('@anthropic-ai/sdk');
const promptTemplate = require('./prompt.js'); // Загружаем промпт из отдельного файла
const systemPrompt = require('./system.js');
const pdfParse = require('pdf-parse');
const PDFExtract = require('pdf.js-extract').PDFExtract; // Добавляем импорт для pdf.js-extract
const { PDFDocument } = require('pdf-lib'); // Добавляем импорт для работы с PDF
const { MongoClient } = require('mongodb');
const { HttpsProxyAgent } = require('https-proxy-agent');
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3'); // Добавляем импорт для работы с S3
const OpenAI = require('openai');

const { BMextractQuotationData } = require('./suppliers/brooksmaldini.js');
const { ABextractQuotationData } = require('./suppliers/aerobay.js');

// Конфигурация IMAP
const imapConfig = {
  user: process.env.EMAIL_USER,
  password: process.env.EMAIL_PASSWORD,
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT || 993,
  tls: true,
  tlsOptions: { rejectUnauthorized: false }
};
const DAYSBACK = 2;
const MAXDAYSBACK = 2;

const blacklist = require('./blacklist.js');
const proxyUrl = `http://${process.env.CLAUDE_PROXY}:${process.env.CLAUDE_PORT}`;
const proxyAgent = new HttpsProxyAgent(proxyUrl);
const mongourl = process.env.MONGODB_URL;
const dbName = process.env.MONGO_DB;



// Функция для проверки существования email в базе
async function checkIfEmailExists(message_id) {
  let client;
  try {
    client = await MongoClient.connect(mongourl);
    const db = client.db(dbName);
    const collection = db.collection('pantheon_quotes');
    
    const result = await collection.findOne({ message_id: message_id });
    return result;
  } catch (error) {
    console.error('Ошибка при проверке существования email:', error);
    return null;
  } finally {
    if (client) {
      await client.close();
    }
  }
}

// Функция для подключения к почтовому ящику
function connectToMailbox() {
  return new Promise((resolve, reject) => {
    const imap = new Imap(imapConfig);
    
    imap.once('ready', () => {
      imap.openBox('INBOX', false, (err, box) => { //PROCESSED
        if (err) {
          imap.end();
          return reject(err);
        }
        resolve(imap);
      });
    });
    
    imap.once('error', (err) => {
      reject(err);
    });
    
    imap.connect();
  });
}

// Функция для поиска писем по критериям
function searchEmails(imap, criteria) {
  return new Promise((resolve, reject) => {
    imap.search(criteria, (err, results) => {
      if (err) return reject(err);
      resolve(results);
    });
  });
}

// Функция для получения содержимого письма
function fetchEmail(imap, uid) {
  return new Promise((resolve, reject) => {
    const fetch = imap.fetch(uid, { bodies: '', markSeen: false });
    
    fetch.on('message', (msg) => {
      let buffer = '';
      
      msg.on('body', (stream) => {
        stream.on('data', (chunk) => {
          buffer += chunk.toString('utf8');
        });
        
        stream.on('end', () => {
          simpleParser(buffer)
            .then(parsed => {
              resolve({
                uid: uid,
                parsed: parsed,
                messageId: parsed.messageId
              });
            })
            .catch(err => reject(err));
        });
      });
      
      msg.on('error', (err) => {
        reject(err);
      });
    });
    
    fetch.on('error', (err) => {
      reject(err);
    });
    
    fetch.on('end', () => {
      // Завершение выборки
    });
  });
}

// Функция для удаления писем
function deleteEmails(imap, uids) {
  return new Promise((resolve, reject) => {
    if (uids.length === 0) {
      return resolve([]);
    }
    
    imap.addFlags(uids, '\\Deleted', (err) => {
      if (err) return reject(err);
      
      imap.expunge((err) => {
        if (err) return reject(err);
        resolve(uids);
      });
    });
  });
}

// Функция для получения последних писем (вместо одного)
 function getLatestEmails(imap, count = 30, daysBack = DAYSBACK) {

  return new Promise((resolve, reject) => {
    // Получаем дату N дней назад
    const pastDate = new Date();
    pastDate.setDate(pastDate.getDate() - daysBack);
    
    // Используем SINCE для поиска писем только за последние N дней
    imap.search([['SINCE', pastDate.toISOString()]], (err, results) => {
      if (err) return reject(err);
      if (!results || !results.length) {
        // Если писем нет, возвращаем пустой массив и флаг, что нужно увеличить период
        return resolve({ uids: [], isEmpty: true });
      }
      
      // Сортируем результаты по убыванию (сначала новые)
      results.sort((a, b) => b - a);
      
      // Берем только первые count писем
      const latestUIDs = results.slice(0, count);
      resolve({ uids: latestUIDs, isEmpty: false });
    });
  });
}

// Функция для перемещения письма в другую папку
function moveEmail(imap, uid, folder) {
  return new Promise((resolve, reject) => {
    imap.move(uid, folder, (err) => {
      if (err) {
        console.log(new Date(), `Ошибка  в названии папки при перемещении письма ${uid} в папку ${folder} - пробуем заменить точку на слэш:`);
        imap.move(uid, folder.replace('.', '/'), (err) => {
          if (err) {
            console.log(new Date(), `Ошибка  в названии папки при перемещении письма ${uid} в папку ${folder.replace('.', '/')} - пробуем заменить точку на слэш:`);
            return reject(err);
          }
        });
      }
      resolve(true);
    });
  });
}

// Функция для проверки письма на соответствие критериям удаления
function shouldDeleteEmail(email) {
  const { from, subject, text, html } = email.parsed;
  const fromAddress = from?.value?.[0]?.address || '';
  const subjectText = subject || '';
  const bodyText = text || (html ? html.replace(/<[^>]*>/g, ' ') : '');

  // Критерий 1: письма от stockmarket@componentcontrol.com
  if (
    fromAddress.toLowerCase() === 'stockmarket@componentcontrol.com' &&
    subjectText.includes('Confirmation for "RFQ from ')
  ) {
    return true;
  }
  
  // Критерий 2: письма от blacklisted vendors
  if (
    blacklist.some(item => fromAddress.toLowerCase().includes(item.toLowerCase())) ||
    blacklist.some(item => bodyText.toLowerCase().includes(item.toLowerCase()))
  ) {
    console.log(`Письмо от ${fromAddress} отправлено в черный список`);
    return true;
  }
    
  if (
    bodyText.toLowerCase().includes('dont have this in stock') ||
    bodyText.toLowerCase().includes('no quote') ||
    bodyText.toLowerCase().includes('noquote') ||
    bodyText.toLowerCase().includes('fill out the attached form and return to me for a quote') ||
    bodyText.toLowerCase().includes('i am writing to follow up on the quotation i provided') ||
    bodyText.includes('Please make your offer for the material below') ||
    bodyText.includes('Thank you for your inquiry. We are currently reviewing stock ') ||
    bodyText.toLowerCase().includes('make offer')
  ) {
    return true;
  }
  

  // Критерий 3: письма с темой "no quote"
  if (
    subjectText.toLowerCase().includes('no quote') ||
    subjectText.toLowerCase().includes('dont have this in stock') ||
    blacklist.some(item => subjectText.toLowerCase().includes(item.toLowerCase()))
  ) {
    return true;
  }

  return false;
}

// Функция для очистки текста от лишних элементов
function cleanEmailText(text) {
  return text
    .replace(/\[http:[^\]]+\]/g, '')
    // Удаляем встроенные изображения (base64)
    .replace(/data:image\/[^;]+;base64,[^\s]+/g, '')
    // Удаляем ссылки на изображения
    .replace(/https?:\/\/[^\s]+\.(jpg|jpeg|png|gif|bmp|svg)/gi, '')
    // Удаляем HTML-теги для изображений
    .replace(/<img[^>]+>/g, '')
    // Удаляем style-блоки вместе с содержимым
    .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
    // Удаляем любые URL в угловых скобках
    .replace(/<https?:\/\/[^>]+>/gi, '')
    // Удаляем всё после "Original Message"
    .replace(/Original Message[\s\S]*$/i, '')
    .replace(/This document may contain[\s\S]*$/i, '')
    .replace(/The stock is reconfirmed at the time[\s\S]*?www\.brooks-maldini\.com under the \(Terms\) section\./i, '')
    .replace(/PLEASE NOTE THE FOLLOWING TERMS OF SALE[\s\S]*?www\.brooks-maldini\.com under the \(Terms\) section\./i, '')
    // Удаляем множественные пробелы и переносы строк
    // .replace(/\s+/g, ' ')
    // Удаляем специальные символы Unicode
    .replace(/[\u0000-\u001F\u007F-\u009F]/g, '')
    .replace(/SOUTH SEA SOLUTIONS LIMITED/gi, ' ')
    .replace(/SOUTH SEA SOLUTIONS/gi, ' ')
    .replace(/SAFIRE PROCUREMENT (PTY) LTD/gi, ' ')
    .replace(/SAFIRE PROCUREMENT/gi, ' ')
    .replace(/aero-quoter@southsea.pro/gi, ' ')
    .replace(/rfq@saf-pro.com/gi, ' ')
    .replace(/southsea.pro/gi, ' ')
    .replace(/saf-pro.com/gi, ' ')
    .replace(/Julian Stevens/gi, ' ')
    .replace(/SAFIRE PROCUREMENT (PTY) LTD/gi, ' ')
    .replace(/UNIT G05 CENTURY GATE OFFICE PARK CNR BOSMANSDAM ROAD AND/gi, ' ')
    .replace(/CENTURY WAY/gi, ' ')
    .replace(/Cape Town/gi, ' ')
    .replace(/7441/gi, ' ')
    .replace(/South Africa/gi, ' ')
    .replace(/27-794655518/gi, ' ')
    .trim();
}




// // Функция для обработки текста письма через Claude API
// async function processEmailWithClaude(emailContent, subject) {

//   const anthropic = new Anthropic({
//     apiKey: process.env.ANTHROPIC_API_KEY,
//     httpAgent: proxyAgent
//   });

//   // Очищаем текст перед отправкой в API
//   const cleanedEmailContent = cleanEmailText(emailContent);

//   try {
//     const msg = await anthropic.messages.create({
//       model: process.env.ANTHROPIC_MODEL, 
//       max_tokens: 8000,
//       system: [
//         {
//         type : "text",
//         text :"Вы являетесь помощником по обработке коммерческих предложений (квотаций) для системы \
//        управления продажами. Ваша задача — извлечь и преобразовать данные из текста письма в JSON-модель, \
//        строго следуя указанным правилам.",
//       },
//        {
//         type : "text",
//         text : `Извлеки информацию из следующего предложения \
//          и верни её в JSON формате не прибавляя ни одного символа снаружи объекта JSON в предоставленной структуре:\n\n 
//          Используй следующую структуру (удали комментарии после полей, когда будешь подставлять значения)\
//          JSON:\n${promptTemplate}\
//          строго выполняй все указания: ${systemPrompt}`,
//          cache_control : { type : "ephemeral"}
//       },
//       ],

//       messages:  [
//         {
//           role: "user",
//           content: `Вот источник данных для заполнения полей в JSON темплейте - это тема и текст письма:\
//            Тема письма: ${subject}\n\n
//            Текст письма:\n${cleanedEmailContent}\n\n`
//         }
//       ]
      
//     });

//     // Парсим ответ от Claude в JSON
//     console.log(msg)
//     let responseText = msg.content[0].text;

//     if (responseText.substring(0, 1) != '['){
//       const bracketIndex = responseText.indexOf('[');
//       responseText = responseText.substring(bracketIndex);
//     }
    
//     // Проверяем, был ли ответ обрезан
//     if (msg.stop_reason === 'max_tokens') {
//       console.warn('Предупреждение: ответ от Claude был обрезан из-за ограничения max_tokens');
//       // Попытка исправить обрезанный JSON
//       if (responseText.trim().endsWith('"') || responseText.trim().endsWith(',')) {
//         responseText += ']}';
//       }
//     }
    
//     var parsedResponse = JSON.parse(responseText);

//     if (!Array.isArray(parsedResponse)) {
//       console.log('Ответ от Claude не является массивом, преобразуем в массив', parsedResponse);
//       parsedResponse = [parsedResponse];
//     }
//     for (const item of parsedResponse) {
//       item.email_subject = subject;
//       if(item.delivery_place.toUpperCase() === 'HONG KONG'){
//       item.delivery_place = '';
//       }
//     }
//     return parsedResponse;
//   } catch (error) {
//     console.error('Ошибка при обработке письма через Claude API:', error);
//     throw error;
//   }
// }

// Функция для извлечения текста из PDF
async function extractTextFromPDF(buffer) {
  try {
    // Создаем временный файл для обработки буфера
    const tempFilePath = path.join(__dirname, 'temp_pdf_' + Date.now() + '.pdf');
    fs.writeFileSync(tempFilePath, buffer);
    
    const pdfExtract = new PDFExtract();
    const options = {}; // Опции по умолчанию
    
    const data = await pdfExtract.extract(tempFilePath, options);
    let text = '';
    
    // Обрабатываем все страницы
    if (data && data.pages) {
      for (const page of data.pages) {
        if (page.content) {
          // Сортируем контент по y-координате для правильного порядка чтения
          const sortedContent = [...page.content].sort((a, b) => {
            // Группируем элементы по строкам (с небольшим допуском)
            const yDiff = Math.abs(a.y - b.y);
            if (yDiff < 5) { // Элементы на одной строке
              return a.x - b.x; // Сортируем по x-координате
            }
            return a.y - b.y; // Сортируем по y-координате
          });
          
          let lastY = -1;
          for (const item of sortedContent) {
            // Если это новая строка, добавляем перенос строки
            if (lastY !== -1 && Math.abs(item.y - lastY) > 5) {
              text += '\n';
            }
            text += item.str + ' ';
            lastY = item.y;
          }
          text += '\n\n';
        }
      }
    }
    
    // Удаляем временный файл
    fs.unlinkSync(tempFilePath);
    text = text?.replace(/SOUTH SEA SOLUTIONS LIMITED/gi, ' ')
              .replace(/SOUTH SEA SOLUTIONS/gi, ' ')
              .replace(/SAFIRE PROCUREMENT (PTY) LTD/gi, ' ')
              .replace(/SAFIRE PROCUREMENT/gi, ' ')
              .replace(/aero-quoter@southsea.pro/gi, ' ')
              .replace(/rfq@saf-pro.com/gi, ' ')
              .replace(/southsea.pro/gi, ' ')
              .replace(/saf-pro.com/gi, ' ')
   
    return text;
  } catch (error) {
    console.error('Ошибка при извлечении текста из PDF с помощью pdf.js-extract:', error);
    
    // Если pdf.js-extract не сработал, пробуем использовать pdf-parse как запасной вариант
    try {
      const data = await pdfParse(buffer);
      return data.text;
    } catch (fallbackError) {
      console.error('Ошибка при извлечении текста с помощью запасного метода pdf-parse:', fallbackError);
      return null;
    }
  }
}




// Функция для проверки, является ли PDF сертификатом
function isPdfCertificate(filename, pdfText) {
  // Проверяем имя файла на наличие ключевых слов
  const filenameCheck = (filename.toLowerCase().includes('cert') || 
                        filename.toLowerCase().includes('certificate') || 
                        filename.toLowerCase().includes('form8130')) 
                        &&
                        !(filename.toLowerCase().includes('quote') ||
                        filename.toLowerCase().includes('quotation') ||
                        filename.toLowerCase().includes('qt') ||
                        filename.toLowerCase().includes('qu'))
  
  // Если имя файла уже указывает на сертификат, возвращаем true
  if (filenameCheck) return true;
  
  // Проверяем содержимое PDF на наличие ключевых слов, указывающих на сертификат
  const textCheck = (pdfText.toLowerCase().includes('cert') || 
                   pdfText.toLowerCase().includes('certificate') || 
                   pdfText.toLowerCase().includes('form8130') ||
                   pdfText.toLowerCase().includes('easa form 1') ||
                   pdfText.toLowerCase().includes('faa 8130') ||
                   pdfText.toLowerCase().includes('airworthiness approval') ||
                   pdfText.length < 100 || pdfText === '')
                    &&
                  !(pdfText.toLowerCase().includes('quote') ||
                  pdfText.toLowerCase().includes('quotation') ||
                  pdfText.toLowerCase().includes('qt')||
                  pdfText.toLowerCase().includes('qu') )
  
  return textCheck;
}

// Функция для загрузки PDF в S3
async function uploadPdfToS3(pdfBuffer, messageId) {
  try {
    // Создаем клиент S3 с использованием переменных окружения
    const s3Client = new S3Client({
      region: process.env.S3_REGION,
      credentials: {
        accessKeyId: process.env.S3_ACCESS_KEY,
        secretAccessKey: process.env.S3_SECRET_KEY
      },
      endpoint: process.env.S3_ENDPOINT_URL,
      //httpAgent: proxyAgent
    });
    
    // Генерируем уникальное имя файла, используя messageId и оригинальное имя файла
    const sanitizedMessageId = messageId.replace(/[<>]/g, '').replace(/[^a-zA-Z0-9]/g, '_').replace(/\s+/g, '_').substring(0, 32);
    const uniqueFilename = `certificate_${sanitizedMessageId}.pdf`;
    
    // Загружаем файл в S3
    const command = new PutObjectCommand({
      Bucket: process.env.S3_BUCKET_NAME,
      Key: uniqueFilename,
      Body: pdfBuffer,
      ContentType: 'application/pdf'
    });
    
    const response = await s3Client.send(command);

    console.log('response$metadata', response.$metadata.httpStatusCode)
    if(response.$metadata.httpStatusCode !== 200){
      console.error('Ошибка при загрузке PDF в S3:', response);
      return {
        success: false,
        error: 'Ошибка при загрузке PDF в S3'
      };
    } else {
      // Формируем URL для доступа к файлу (для логирования)
      const fileUrl = `${process.env.S3_ENDPOINT_URL}/${process.env.S3_BUCKET_NAME}/${uniqueFilename}`;
      
      console.log(`PDF-сертификат успешно загружен в S3: ${fileUrl}`);
      return {
        success: true,
        url: uniqueFilename, // Возвращаем только имя файла вместо полного URL
        key: uniqueFilename
      };
    }
  } catch (error) {
    console.error('Ошибка при загрузке PDF в S3:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

/**
 * Сохраняет извлеченные данные в базу данных MongoDB
 * @param {Object} structuredData - Основные структурированные данные
 * @param {Object} pdfStructuredData - Структурированные данные из PDF
 * @param {string} from - Email отправителя
 * @param {string} messageId - Message-ID письма
 * @param {string} emailDate - Дата письма
 * @param {Array} certificateUrls - Массив URL сертификатов
 * @returns {Promise<boolean>} - Результат операции
 */
async function saveExtractedDataToDatabase(structuredData, pdfStructuredData, from, messageId, emailDate, certificateUrls = []) {
  let client;

  try {
    
    var dataArray = Array.isArray(structuredData) ? structuredData : [structuredData];
    
    // Фильтруем только записи с положительной ценой
    dataArray = dataArray.filter(item => item.price && parseFloat(item.price) > 0);
    
    let pdfSupplier = '';
    let pdfDeliveryPlace = '';
    let pdfItemNotes = '';
    if (pdfStructuredData && pdfStructuredData.length > 0) {
      console.log('pdfStructuredData', pdfStructuredData)
      pdfSupplier = pdfStructuredData[0].supplier;
      pdfDeliveryPlace = pdfStructuredData[0].delivery_place;
      pdfItemNotes = pdfStructuredData[0].item_note;
      
      // Фильтруем только записи с положительной ценой из PDF
      const validPdfData = pdfStructuredData.filter(item => item.price && parseFloat(item.price) > 0);
      console.log('validPdfData', validPdfData)

      if (dataArray.length === 0 && validPdfData.length === 0) {
        console.log("Цена отсутствует в обоих источниках данных");
        return false;
      } else if (dataArray.length === 0) {
        dataArray = validPdfData;
        console.log("Цена отсутствует в основном источнике данных, используем PDF");
      } else if (validPdfData.length > 0) {
        // Объединяем данные из основного источника и PDF
        console.log("Объединяем данные из основного источника и PDF");
        dataArray = [...dataArray, ...validPdfData];
      }
    }

    if (dataArray.length === 0) {
      console.log("Цена отсутствует в основном источнике данных");
      return true;
    }

    // Проверяем наличие цены в основном объекте
    let success = true;
    for (const item of dataArray) {
      
        if(item.price > process.env.MAXPRICE){
          console.log(`Цена ${item.price} превышает максимальную цену ${process.env.MAXPRICE}, пропускаем письмо`);
          success = false;
          continue;
        }
        // Проверяем наличие цены в основном объекте
        let dataToSave = item;
        dataToSave.quote_id = null
        dataToSave.customer_request_id = null
      
        // Добавляем поля из PDF, если они отсутствуют в email данных
        if (!dataToSave.supplier && pdfSupplier) {
          console.log('Добавляем supplier из PDF данных:', pdfSupplier);
          dataToSave.supplier = pdfSupplier;
        }
        if (!dataToSave.delivery_place && pdfDeliveryPlace) {
          console.log('Добавляем delivery_place из PDF данных:', pdfDeliveryPlace);
          dataToSave.delivery_place = pdfDeliveryPlace;
        }
        if (!dataToSave.item_note && pdfItemNotes) {
          console.log('Добавляем item_note из PDF данных:', pdfItemNotes);
          dataToSave.item_note = pdfItemNotes;
        }

        const fromAddress = from || '';
        console.log('fromAddress', fromAddress, 'dataToSave.from', dataToSave.from)
        
        if (fromAddress.includes('partsbase.com') || fromAddress.includes('ilsmart.com')) {
          dataToSave.from = null;
        } else if (!dataToSave.from || dataToSave.from.includes('southsea.pro') || dataToSave.from.includes('saf-pro.com')) {
          dataToSave.from = fromAddress;
        }
        if (!dataToSave.from){
          dataToSave.from = fromAddress;
        }


        console.log('final dataToSave.from', dataToSave.from)
        // Добавляем поле message_id вместо email_uid
        dataToSave.message_id = messageId;
        
        //if (!dataToSave.date || dataToSave.date === "") {
          // Преобразуем дату в формат строки YYYY-MM-DD
          const emailDateObj = new Date(emailDate);
          const year = emailDateObj.getFullYear();
          const month = String(emailDateObj.getMonth() + 1).padStart(2, '0');
          const day = String(emailDateObj.getDate()).padStart(2, '0');
          dataToSave.date = `${year}-${month}-${day}`;
          
          // Добавляем 21 день к дате письма для поля valid_to
          const validToDate = new Date(emailDateObj);
          validToDate.setDate(validToDate.getDate() + 21);
          const validToYear = validToDate.getFullYear();
          const validToMonth = String(validToDate.getMonth() + 1).padStart(2, '0');
          const validToDay = String(validToDate.getDate()).padStart(2, '0');
          dataToSave.valid_to = `${validToYear}-${validToMonth}-${validToDay}`;
          // делаем запись для статистики
          dataToSave.received_at = emailDate;
        //}
        dataToSave.quote_id = null;
        dataToSave.customer_request_id = null;
        
        // Добавляем ссылки на сертификаты, если они есть
        if (certificateUrls && certificateUrls.length > 0) {
          dataToSave.certificates = certificateUrls;
        }
                
        if(dataToSave.item_notes?.toLowerCase().includes('exchange only')){
          console.log('item_notes содержит Exchange Only, пропускаем письмо');
          await moveEmail(imap, uid, 'INBOX.MANUAL');
          continue;
        }

        dataToSave.delivery_condition = dataToSave.delivery_condition 
                                        ? dataToSave.delivery_condition : 'EXW';
        dataToSave.delivery_condition = dataToSave.delivery_condition === 'FOB' 
                                        ? 'EXW' : dataToSave.delivery_condition;
        
        //  if (dataToSave.part_number?.includes('/')) {
        //   dataToSave.item_note = dataToSave.item_note + ' | Part number ' + dataToSave.part_number
        //   dataToSave.part_number = dataToSave.part_number//?.replace('/', '-')  
        // }
        // Если нашли запись, обновляем данные
        
        if(dataToSave.qty > dataToSave.stk_qty && dataToSave.stk_qty > 0 ){
          console.log('qty available меньше qty required, пропускаем письмо');
          continue;
        }
        if (['AR', 'GR', 'AI', 'AS', 'BR', 'UN', 'EX'].some(condition => 
            dataToSave.condition.toUpperCase().includes(condition.toUpperCase()))
        ) {
          console.log('condition не подходит по условию, пропускаем письмо');
          continue;
        }
        if(dataToSave.price === 0){
          console.log('цена равна 0, пропускаем письмо');
          continue;
        }
        
        if(dataToSave.condition === 'IN'){
          dataToSave.condition = 'IT';
        }
        
        console.log('---------------------------Saving To Pantheon------------------------------------------', dataToSave)
        // Записываем данные в коллекцию pantheon_quotes

        try {
          const response = await fetch(
            `http://api:3000/send-to-pantheon/0`, 
            {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(dataToSave)
            }
          );
          
          const respObject = await response.json();
          console.log('Данные отправлены в Pantheon API:', respObject);
          
          // Проверяем результат от Pantheon
          if (!respObject.ok) {
            let respError = [];
            try {
              respError = JSON.parse(respObject.results);
              console.log('respError', respError);
            } catch (error) {
              console.log('Ошибка при парсинге ответа от Pantheon API:', error);
            }
            if (respError && respError.some(item => item.result.error === "duplicate_proposals")) {
              success = true;
              console.log('Найдены дубликаты предложений, пропускаем письмо');
            } else {
              throw new Error(`Ошибка от Pantheon API: ${respObject.message || JSON.stringify(respObject.pantheon_response)}`);
            }
          }
          
        } catch (error) {
          console.error('Ошибка при отправке данных в Pantheon API:', error);
          success = false;
        }
    }
    
    return success;
  } catch (error) {
 
    return false;
  } 
}

async function processEmailsWithDeepseek(emailContent, subject) {
    console.log('Обрабатываем письмо с Deepseek API');
    //console.log('emailContent', emailContent);
    //console.log('subject', subject);
    // Создаем прокси агент
  
    const openai = new OpenAI({
        baseURL: process.env.DEEPSEEK_API_URL,
        apiKey: process.env.DEEPSEEK_API_KEY,
        //httpAgent: proxyAgent // Добавляем прокси агент
    });

    // Очищаем текст перед отправкой в API
    const cleanedEmailContent = cleanEmailText(emailContent);

    try {
        const completion = await openai.chat.completions.create({
            model: "deepseek-chat", //deepseek-reasoner
            messages: [
                {
                    role: "system",
                    content: systemPrompt
                },
                {
                    role: "user",
                    content: `Extract information from the following sentence and return it in JSON format without adding any characters outside the JSON object in the provided structure:\n\n
                    Use the following structure (remove comments after fields, when substituting values):\n\n${promptTemplate}.\n\n
                    Here is the source data for filling the fields in the JSON template - this is the subject and text of the email:
                    Subject of the email: ${subject}\n\n
                    Text of the email:\n${cleanedEmailContent}\n\n`
                }
            ],
            temperature: 1, // Low temperature for more predictable results
            max_tokens: 8000,
            response_format: { type: "json_object" }
        });

        console.log(completion.choices[0].message.content);
        let responseText = completion.choices[0].message.content;

        // Обработка ответа аналогично Claude
        // if (responseText.substring(0, 1) != '[') {
        //     const bracketIndex = responseText.indexOf('[');
        //     responseText = responseText.substring(bracketIndex).replace('```', '');
        // }
        var parsedResponse = JSON.parse(responseText);
        
        if (!Array.isArray(parsedResponse)) {
            console.log('Ответ от Deepseek не является массивом, преобразуем в массив');
            parsedResponse = [parsedResponse];
        }
        
        for (const item of parsedResponse) {
            item.email_subject = subject;
            if (item.delivery_place?.toUpperCase() === 'HONG KONG') {
                item.delivery_place = '';
            }
        }
        
        //console.log(parsedResponse);
        return parsedResponse;

    } catch (error) {
        console.error('Ошибка при обработке письма через Deepseek API:', error);
        throw error;
    }
}

// Функция для объединения PDF файлов
async function mergePDFs(pdfBuffers) {
  try {
    const mergedPdf = await PDFDocument.create();
    
    for (const pdfBuffer of pdfBuffers) {
      const pdf = await PDFDocument.load(pdfBuffer);
      const copiedPages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
      copiedPages.forEach((page) => {
        mergedPdf.addPage(page);
      });
    }
    
    return await mergedPdf.save();
  } catch (error) {
    console.error('Ошибка при объединении PDF файлов:', error);
    throw error;
  }
}

// Обновленная основная функция
async function processLatestEmails(count = 30, maxDaysBack = MAXDAYSBACK) {
  let imap;
  try {
    console.log(new Date(), 'Подключение к почтовому ящику...');
    imap = await connectToMailbox();
    console.log(new Date(), 'Подключение успешно установлено');

    // // Проверяем существование папки PROCESSED с префиксом INBOX
    // imap.getBoxes((err, boxes) => {
    //   if (!boxes['INBOX.PROCESSED']) {
    //     imap.addBox('INBOX.PROCESSED', (err) => {
    //       if (err) console.error('Ошибка создания папки:', err.message);
    //     });
    //   }
    // });
    
    // Пытаемся получить письма, постепенно увеличивая период поиска
    let daysBack = 1;
    let latestUIDs = [];
    let isEmpty = true;
    
    console.log(new Date(), `Поиск писем`);
    while (isEmpty && daysBack <= maxDaysBack) {
      const result = await getLatestEmails(imap, count, daysBack);
      latestUIDs = result.uids;
      isEmpty = result.isEmpty;
      
      if (isEmpty) {
        // Увеличиваем период поиска
        daysBack = Math.min(daysBack * 2, maxDaysBack);
      }
    }
    
    if (latestUIDs.length === 0) {
      console.log(new Date(), `Почтовый ящик пуст за последние ${maxDaysBack} дней`);
      imap.end();
      return;
    }

    console.log(new Date(), `Найдено ${latestUIDs.length} писем для проверки за последние ${daysBack} дней`);

    // Сначала проверяем все письма на критерии удаления
    const emailsToDelete = [];
    const emailsToProcess = [];
    
    for (const uid of latestUIDs) {
      try {
        // Получаем содержимое письма
        const email = await fetchEmail(imap, uid);
        
        // Проверяем, нужно ли удалить письмо
        if (shouldDeleteEmail(email)) {
          emailsToDelete.push(uid);
        } else {
          emailsToProcess.push({ uid, email });
        }
          // В функции saveExtractedDataToDatabase
        
      } catch (err) {
        console.error(`Ошибка при проверке письма ${uid}:`, err);
      }
    }
    
    // Удаляем письма, которые соответствуют критериям удаления
    if (emailsToDelete.length > 0) {
      await deleteEmails(imap, emailsToDelete);
      console.log(new Date(), `Удалено ${emailsToDelete.length} писем согласно критериям фильтрации`);
    }
    
     // Обрабатываем только первое письмо из оставшихся
    if (emailsToProcess.length > 0) {
      
      const { uid, email } = emailsToProcess[0];
      console.log(new Date(), `Обрабатываем письмо ${email.parsed.subject} (1 из ${emailsToProcess.length} доступных)`);
      
      const existingMessage = await checkIfEmailExists(email.parsed.messageId);
      if (existingMessage) {
          console.log('Письмо уже было обработано ранее');
          if (existingMessage.sent_to_pantheon === true) {
            await moveEmail(imap, uid, 'INBOX.PROCESSED');
          } else {
            await moveEmail(imap, uid, 'INBOX.MANUAL');
          }
          return;
      } 

      // if (email.parsed.text?.toLowerCase().includes('exchange') 
      //   || (email.parsed.html && email.parsed.html.toLowerCase().includes('exchange'))) {
      //   console.log('Письмо содержит Exchange, перемещаем в папку INBOX.MANUAL');
      //   await moveEmail(imap, uid, 'INBOX.MANUAL');
      //   return;
      // }


      const { from, subject, text, html, attachments, messageId } = email.parsed;
      
      let allPdfStructuredData = [];
      let certificateUrls = []; // Массив для хранения URL сертификатов
      let structuredData = []; // Инициализируем structuredData как пустой массив
      let certificateBuffers = []; // Массив для хранения буферов PDF-сертификатов

      if (attachments?.length) {
        for (const attachment of attachments) {
          console.log(`- Вложение в письме ${uid}:`, attachment.filename);
          if (attachment?.filename?.toLowerCase().includes('pdf') && !attachment?.filename?.includes('General Terms')) {
            const pdfText = await extractTextFromPDF(attachment.content);

            if (pdfText) {
              console.log(`Текст из PDF в письме ${uid} извлечен`);

              // if (pdfText.toLowerCase().includes('exchange')) {
              //   console.log('PDF содержит Exchange, перемещаем письмо в папку INBOX.MANUAL');
              //   await moveEmail(imap, uid, 'INBOX.MANUAL');
              //   return;
              // }
              
              // Проверяем, является ли PDF сертификатом
              console.log('Проверяем, является ли PDF сертификатом');
              if (isPdfCertificate(attachment.filename, pdfText)) {
                console.log(`PDF-файл ${attachment.filename} определен как сертификат`);
                certificateBuffers.push(attachment.content);
              } else {
                console.log('PDF не является сертификатом, длина текста:', pdfText.length);
                // Обработка текста из PDF через Claude только если это не сертификат
                try {
                  
                  const pdfData = await processEmailsWithDeepseek(pdfText, subject);
                  console.log(`\nСтруктурированные данные из PDF в письме ${uid}:`);
                  console.log(JSON.stringify(pdfData, null, 2));
                  
                  // Добавляем данные из текущего PDF в общий массив вместо перезаписи
                  if (Array.isArray(pdfData)) {
                    allPdfStructuredData = [...allPdfStructuredData, ...pdfData];
                  } else if (pdfData) {
                    allPdfStructuredData.push(pdfData);
                  }
                } catch (error) {
                  console.error(`Ошибка при обработке PDF в письме ${uid}:`, error);
                  await moveEmail(imap, uid, 'INBOX.MANUAL');
                  console.log(new Date(), `Письмо ${uid} перемещено в папку INBOX.MANUAL из-за ошибки обработки PDF`);
                  continue;
                }
              }
            }
          }
        }
      }

      // Если есть сертификаты, объединяем их в один файл
      if (certificateBuffers.length > 0) {
        console.log(`Объединяем ${certificateBuffers.length} сертификатов в один файл`);
        try {
          const mergedPdfBuffer = await mergePDFs(certificateBuffers);
          const uploadResult = await uploadPdfToS3(mergedPdfBuffer, messageId);
          
          if (uploadResult.success) {
            certificateUrls.push(uploadResult.key);
            console.log('Объединенный сертификат успешно загружен в S3');
          }
        } catch (error) {
          console.error('Ошибка при объединении и загрузке сертификатов:', error);
        }
      }

      // Добавляем обработку текста письма через Claude
      let emailText = text || (html ? html.replace(/<[^>]*>/g, ' ') : '');
      emailText = cleanEmailText(emailText);
      const fromAddress = from?.value?.[0]?.address//
  
      // if (emailText.toUpperCase().includes('BROOKS') && emailText.toUpperCase().includes('MALDINI')) {
      //     console.log('Найден текст письма с BROOKS & MALDINI');
      //     structuredData = BMextractQuotationData(emailText);
      //     for (const item of structuredData) {
      //       item.email_subject = subject;
      //       item.from = fromAddress;
      //       item.message_id = messageId;
      //       item.date = email.parsed.date;
      //     }
      // }   
      if (emailText.toUpperCase().includes('AEROBAY')) {
        console.log('Найден текст письма с AEROBAY');
        structuredData = await ABextractQuotationData(emailText);

        let uploadResult;
        let certificateBuffers = [];
        if ((email.attachments?.length > 0)  
            && (email.attachments.some(attachment => attachment.filename.toLowerCase().includes('pdf')))) {
          console.log('Найден PDF в письме');
          
          for (const attachment of email.attachments) {
            
            if (attachment.filename.toLowerCase().includes('directquote')) {
              let pdfText = await extractTextFromPDF(attachment.content);
              if (pdfText) {
                structuredData = await processEmailsWithDeepseek(pdfText, subject);
              }
            }

            if (isPdfCertificate(attachment.filename, pdfText)) {
              certificateBuffers.push(attachment.content);
            }
          }
          if (certificateBuffers.length > 0) {
            const mergedPdfBuffer = await mergePDFs(certificateBuffers);
            uploadResult = await uploadPdfToS3(mergedPdfBuffer, messageId);
          }
        }
        for (const item of structuredData) {
          item.email_subject = subject;
          item.from = fromAddress;
          item.message_id = messageId;
          item.date = email.parsed.date;
          item.cert_file_name = uploadResult?.key;
        }
      } else {
          structuredData = await processEmailsWithDeepseek(emailText, subject);
      }

    //TODO - убрать костыль
      if(fromAddress.includes('vseaviation.com')){
        structuredData.forEach(item => {
          item.delivery_place = 'US';
        });
      }
      
      // Добавляем URL сертификата в structuredData
      if (certificateUrls.length > 0) {
          structuredData = structuredData.map(item => ({
              ...item,
              cert_file_name: certificateUrls[0] // Берем первый сертификат, если их несколько
          }));
      }

      //TODO проверить по тексту письма наличие значения поля condition с пробелами по краям 
      // Выводим структурированные данные
      console.log(`\nСтруктурированные данные из письма ${uid}:`);
      console.log(JSON.stringify(structuredData, null, 2));

      // Выводим информацию о письме
      console.log(`\nИнформация о письме ${uid}:`);
      console.log('От:', fromAddress);
      console.log('Тема:', subject);
      //console.log('Текст:', text ? text.substring(0, 100) + '...' : 'Нет текста');
      console.log('Вложения:', attachments?.length || 0);

      // Сохраняем данные в базу данных, передавая также ссылки на сертификаты
      const saveResult = await saveExtractedDataToDatabase(
        structuredData, 
        allPdfStructuredData, 
        fromAddress, 
        messageId, 
        email.parsed.date,
        certificateUrls
      );
      if (!saveResult) {
        console.error(`Письмо ${uid} не сохранено в базу данных`);
	await moveEmail(imap, uid, 'INBOX.MANUAL');
        console.log(new Date(), `Письмо ${uid} перемещено в папку INBOX.MANUAL`)
      } else {
	await moveEmail(imap, uid, 'INBOX.PROCESSED');
        console.log(new Date(), `Письмо ${uid} перемещено в папку INBOX.PROCESSED`)
      }
    } else {
      console.log(new Date(), 'Нет писем для обработки после фильтрации');
    }

  } catch (err) {
    console.error('Произошла ошибка:', err);
  } finally {
    if (imap && imap.state !== 'disconnected') {
      imap.end();
      console.log(new Date(), 'Соединение закрыто');
      setTimeout(() => {
        console.log(new Date(), 'Перезапуск скрипта');
      }, 10000);
    }
  }
}

// Запуск скрипта с проверкой 30 писем, но обработкой только одного
processLatestEmails(30);

// Экспорт функций для тестирования
module.exports = {
  connectToMailbox,
  getLatestEmails,
  fetchEmail,
  moveEmail,
  processLatestEmails,
  processEmailsWithDeepseek,
  extractTextFromPDF,
  saveExtractedDataToDatabase,
};



